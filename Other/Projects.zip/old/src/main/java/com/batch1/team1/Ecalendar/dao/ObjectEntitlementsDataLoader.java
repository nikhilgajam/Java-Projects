package com.batch1.team1.Ecalendar.dao;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Component;

import com.batch1.team1.Ecalendar.model.dto.ObjectEntitlementDTO;
import com.batch1.team1.Ecalendar.utils.FailedToReadJsonException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

@Component
public class ObjectEntitlementsDataLoader {
	
	public static List<ObjectEntitlementDTO> readJsonAndGetManagerDetails() throws FailedToReadJsonException {
    	
	   	 
   	 	ObjectMapper objectMapper = new ObjectMapper();
   	 
   	 	List<ObjectEntitlementDTO> Managers = new ArrayList<>();
	   	JsonNode json;

       try (InputStream inputStream = TypeReference.class.getResourceAsStream("/data/Object_Entitlements_Sample_Response.json")) {
       	json = objectMapper.readValue(inputStream, JsonNode.class);
       } catch (IOException e) {
           throw new FailedToReadJsonException("Failed to read JSON data");
       }

       JsonNode managers = getManagers(json);
       for (JsonNode manager : managers) {
    	   Managers.addAll(getObjectfromArray(manager));
       } 
       
       return Managers;
    }
    
    
    private static JsonNode getManagers(JsonNode json) {
        return Optional.ofNullable(json)
                .map(j -> j.get("objectEntitlements"))
                .orElseThrow(() -> new IllegalArgumentException("Invalid JSON Object"));
    }

private static List<ObjectEntitlementDTO> getObjectfromArray(JsonNode manager) {
        JsonNode managerIdnode=manager.get("itemID");
        String managerId=managerIdnode.asText();
        JsonNode employees = Optional.ofNullable(manager)
                .map(j -> j.get("objectIdentifiers"))
                .orElseThrow(() -> new IllegalArgumentException("Invalid JSON Object"));
        
        List<ObjectEntitlementDTO> Employees = new ArrayList<>();
        JsonNode employeeIdnode;
        JsonNode associateOIdnode;
        String employeeId = null;
        String associateOId=null;
        for(JsonNode emp : employees)
        {
        	JsonNode objidset = Optional.ofNullable(emp)
                    .map(j -> j.get("objectIDSet"))
                    .orElseThrow(() -> new IllegalArgumentException("Invalid JSON Object"));
        	JsonNode employeeNamenode=emp.get("formattedName");
        	String employeeName=employeeNamenode.asText();
        	employeeId="-";
        	associateOId="-";
        	for (JsonNode objid:objidset)
        	{
        	String cond=objid.get("schemeID").asText();
        	boolean cond1=cond.equals("employeeID");
        	boolean cond2=cond.equals("associateOID");
        	if(cond1)
        	{
        		employeeIdnode=objid.get("idValue");
        		employeeId=employeeIdnode.asText();
        	}        	
        	else if(cond2)
			{
        		associateOIdnode=objid.get("idValue");
        		associateOId=associateOIdnode.asText();
			}  
        	}
        	
        	Employees.add(new ObjectEntitlementDTO(managerId, employeeId, associateOId, employeeName));
        }

        return Employees;
    }

}
