package com.batch1.team1.Ecalendar.dao;
import java.io.IOException;
import java.io.InputStream;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Component;

import com.batch1.team1.Ecalendar.model.dto.EmployeeDTO;
import com.batch1.team1.Ecalendar.utils.FailedToReadJsonException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;


@Component
public class EmployeeDataLoader {

	public static List<EmployeeDTO> readJsonAndGetEmployees() throws FailedToReadJsonException {
    	
		List<EmployeeDTO> employees = new ArrayList<>();
   	 	/*ObjectMapper objectMapper = new ObjectMapper();
   	 
	   	JsonNode json;

       try (InputStream inputStream = TypeReference.class.getResourceAsStream("/data/Worker-details-response.json")) {
       	json = objectMapper.readValue(inputStream, JsonNode.class);
       } catch (IOException e) {
           throw new FailedToReadJsonException("Failed to read JSON data");
       }

       JsonNode workers = getWorkers(json);
       for (JsonNode worker : workers) {
       	employees.add(getEmployeeFromArray(worker));
       }*/
       
       employees.add(new EmployeeDTO("473742", "LITE045", "Helen Ward", "associate", LocalDate.parse("1993-09-05", DateTimeFormatter.ofPattern("yyyy-MM-dd")), "dharrison-f68", "Dharrison", "helenward@adp.com", LocalDate.parse("2022-09-05", DateTimeFormatter.ofPattern("yyyy-MM-dd"))));
       employees.add(new EmployeeDTO("435628", "ARP1293", "Aaron Baker", "associate", LocalDate.parse("1983-06-25", DateTimeFormatter.ofPattern("yyyy-MM-dd")), "dharrison-f68", "Dharrison", "aaronbaker@adp.com", LocalDate.parse("2022-08-05", DateTimeFormatter.ofPattern("yyyy-MM-dd"))));
       employees.add(new EmployeeDTO("837483", "LITE290", "Maria Newman", "associate", LocalDate.parse("1982-09-28", DateTimeFormatter.ofPattern("yyyy-MM-dd")), "dharrison-f68", "Dharrison", "marianewman@adp.com", LocalDate.parse("2022-06-05", DateTimeFormatter.ofPattern("yyyy-MM-dd"))));
       employees.add(new EmployeeDTO("237867", "LITE190", "Shirley Booth", "associate", LocalDate.parse("2001-09-26", DateTimeFormatter.ofPattern("yyyy-MM-dd")), "dharrison-f68", "Dharrison", "shirleybooth@adp.com", LocalDate.parse("2022-09-05", DateTimeFormatter.ofPattern("yyyy-MM-dd"))));
       employees.add(new EmployeeDTO("237865", "LITE299", "Michael Harwood", "associate", LocalDate.parse("1997-05-26", DateTimeFormatter.ofPattern("yyyy-MM-dd")), "dharrison-f68", "Dharrison", "michaelharwood@adp.com", LocalDate.parse("2022-09-25", DateTimeFormatter.ofPattern("yyyy-MM-dd"))));
       employees.add(new EmployeeDTO("237866", "LITE270", "Alecia Moore", "associate", LocalDate.parse("1991-09-27", DateTimeFormatter.ofPattern("yyyy-MM-dd")), "dharrison-f68", "Dharrison", "aleciamoore@adp.com", LocalDate.parse("2022-09-26", DateTimeFormatter.ofPattern("yyyy-MM-dd"))));
       employees.add(new EmployeeDTO("237870", "LITE298", "Jean Scott", "associate", LocalDate.parse("1998-10-27", DateTimeFormatter.ofPattern("yyyy-MM-dd")), "dharrison-f68", "Dharrison", "jeanscott@adp.com", LocalDate.parse("2022-09-28", DateTimeFormatter.ofPattern("yyyy-MM-dd"))));
       return employees;
    }
    
    
    private static JsonNode getWorkers(JsonNode json) {
        return Optional.ofNullable(json)
                .map(j -> j.get("workers"))
                .orElseThrow(() -> new IllegalArgumentException("Invalid JSON Object"));
    }

    private static EmployeeDTO getEmployeeFromArray(JsonNode worker) {
    	
    	String associateId = worker.get("associateOID").asText();
        String name = worker.get("person").get("legalName").get("formattedName").asText();
    	
        String workerId = worker.get("workerID").get("idValue").asText();
        
        JsonNode designationnode = worker.get("workAssignments").get(0).get("jobTitle");
        String designation = designationnode.asText();
        
        
        JsonNode dateOfJoiningnode = worker.get("workAssignments").get(0).get("jobCode").get("effectiveDate");
        String dateOfJoining = dateOfJoiningnode.asText();
        
        String dob = worker.get("person").get("birthDate").asText();
        
        JsonNode managerIDnode = worker.get("workAssignments").get(0).get("reportsTo").get(0).get("associateOID");
        String managerID = managerIDnode.asText();

        JsonNode managerNamenode = worker.get("workAssignments").get(0).get("reportsTo").get(0).get("reportsToWorkerName").get("formattedName");
        String managerName = managerNamenode.asText();
        
        JsonNode emailnode = worker.get("businessCommunication").get("emails").get(0).get("emailUri");
        String email = emailnode.asText();
        
        String DATE_PATTERN = "yyyy-MM-dd";

        return new EmployeeDTO(associateId, workerId, name, designation, LocalDate.parse(dob, DateTimeFormatter.ofPattern(DATE_PATTERN)), managerID, managerName, email, LocalDate.parse(dateOfJoining, DateTimeFormatter.ofPattern(DATE_PATTERN)));
    }

        
     	
     

}