package com.batch1.team1.Ecalendar.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.batch1.team1.Ecalendar.dao.EmployeeDao;
import com.batch1.team1.Ecalendar.model.dto.EmployeeDTO;
import com.batch1.team1.Ecalendar.model.dto.EmployeeLeaveDTO;
import com.batch1.team1.Ecalendar.model.dto.LeaveCountbyDayDTO;
import com.batch1.team1.Ecalendar.model.dto.LeaveTransactionDTO;
import com.batch1.team1.Ecalendar.model.dto.LoginDetailsDTO;
import com.batch1.team1.Ecalendar.model.dto.ObjectEntitlementDTO;
import com.batch1.team1.Ecalendar.model.dto.WorkScheduleDTO;
import com.batch1.team1.Ecalendar.utils.FailedToReadJsonException;

@Service
public class EmployeeServiceImpl implements EmployeeService{
	
	@Autowired
	EmployeeDao dao;
	
	@Override
	public List<EmployeeDTO> getEmployeeDetailsById(String empId) throws FailedToReadJsonException {
		
		return dao.getEmployeeDetailsById(empId);
	}

	@Override
	public List<WorkScheduleDTO> getWorkSchedulesById(String empId) throws FailedToReadJsonException {
		
		return dao.getWorkSchedulesById(empId);
	}

	@Override
	public List<LeaveTransactionDTO> getLeaveTransactionsById(String empId) throws FailedToReadJsonException {
		
		return dao.getLeaveTransactionsById(empId);
	}


	@Override
	public List<EmployeeDTO> getEmployeeDetailsByManagerIdFromEmployeeData(String managerId) throws FailedToReadJsonException {
		return dao.getEmployeeDetailsByManagerIdFromEmployeeData(managerId);
	}

	@Override
	public List<ObjectEntitlementDTO> getEmployeeDetailsByManagerIdFromManagerData(String managerId) throws FailedToReadJsonException {
		return dao.getEmployeeDetailsByManagerIdFromManagerData(managerId);
	}

	@Override
	public List<EmployeeLeaveDTO> getEmployeeLeaveDetailsById(String managerId) throws FailedToReadJsonException {
		return dao.getEmployeeLeaveDetailsById(managerId);
	}

	@Override
	public List<String> frequentSickLeave(String managerId) throws FailedToReadJsonException {
		return dao.frequentSickLeave(managerId);
	}

	@Override
	public List<String> noLeaveOf3months(String managerId) throws FailedToReadJsonException {
		return dao.noLeaveOf3months(managerId);
	}

	@Override
	public List<String> consec3NightShifts(String managerId) throws FailedToReadJsonException {
		return dao.consec3NightShifts(managerId);
	}

	@Override
	public List<EmployeeDTO> EmpsBirthday(String managerId) throws FailedToReadJsonException {
		return dao.EmpsBirthday(managerId);
	}

	@Override
	public boolean LoginValidate(LoginDetailsDTO lddto) {
		if(lddto.getUsername().equals("dharrison-f68") && lddto.getPassword().equals("admin123"))
			return true;
		else
		return false;
	}

	@Override
	public List<LeaveTransactionDTO> leavesOfEmpOfManager(String managerId) throws FailedToReadJsonException {
		return dao.leavesOfEmpOfManager(managerId);
	}

	@Override
	public List<WorkScheduleDTO> workSchedOfEmpsUnderManager(String managerId) throws FailedToReadJsonException {
		return dao.workSchedOfEmpsUnderManager(managerId);
	}

	@Override
	public int[] leaveCountOfEverydayMonth(String managerId) throws FailedToReadJsonException {
		return dao.leaveCountOfEverydayMonth(managerId);
	}

	@Override
	public int[] workingCountOfEverydayMonth(String managerId) throws FailedToReadJsonException {
		return dao.workingCountOfEverydayMonth(managerId);
	}

	@Override
	public int[] nonWorkingCountOfEverydayMonth(String managerId) throws FailedToReadJsonException {
		return dao.nonWorkingCountOfEverydayMonth(managerId);
	}	
	
	@Override
	public List<EmployeeDTO> workAnniversaryToday(String managerId) throws FailedToReadJsonException {
		return dao.workAnniversaryToday(managerId);
	}
	
	public LeaveCountbyDayDTO[] leaveCountOfEverydayMonthbyDay(String managerId) throws FailedToReadJsonException
	{
		return dao.leaveCountOfEverydayMonthbyDay(managerId);
	}
	
	@Override
    public List<EmployeeDTO> EmpsBirthdayUpcoming(String managerId) throws FailedToReadJsonException {
        return dao.EmpsBirthdayUpcoming(managerId);
    }    
	
}
