package com.batch1.team1.Ecalendar.model.dto;

import java.time.LocalDate;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor

public class LeaveTransactionDTO{
	private String associateId;
    private String workerId;
    private String employeeName;
    private String leaveId;
    private LocalDate leaveFromDate;
    private LocalDate leaveToDate;
    private String startTime;
    private String endTime;
    private int totalHours;
    private String leaveType;
    private String leaveStatus;
}