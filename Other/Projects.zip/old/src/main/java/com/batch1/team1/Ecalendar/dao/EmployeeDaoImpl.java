package com.batch1.team1.Ecalendar.dao;

import java.time.LocalDate;
import java.time.temporal.TemporalAdjusters;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.stereotype.Component;

import com.batch1.team1.Ecalendar.model.dto.EmployeeDTO;
import com.batch1.team1.Ecalendar.model.dto.EmployeeLeaveDTO;
import com.batch1.team1.Ecalendar.model.dto.LeaveCountbyDayDTO;
import com.batch1.team1.Ecalendar.model.dto.LeaveTransactionDTO;
import com.batch1.team1.Ecalendar.model.dto.ObjectEntitlementDTO;
import com.batch1.team1.Ecalendar.model.dto.WorkScheduleDTO;
import com.batch1.team1.Ecalendar.utils.FailedToReadJsonException;

@Component
public class EmployeeDaoImpl implements EmployeeDao {

	@Override
	public List<WorkScheduleDTO> getWorkSchedulesById(String empId) throws FailedToReadJsonException {
		List<WorkScheduleDTO> allSchedules = WorkSchedulesDataLoader.readJsonAndGetWorkSchedules();
		List<WorkScheduleDTO> SchedulesOfEmp = allSchedules.stream()
		        .filter(schedule -> (schedule.getAssociateId()).equals(empId))
		        .collect(Collectors.toList());
		
		return SchedulesOfEmp;
	}

	@Override
	public List<EmployeeDTO> getEmployeeDetailsById(String empId) throws FailedToReadJsonException {		
		List<EmployeeDTO> allEmployees = EmployeeDataLoader.readJsonAndGetEmployees();
		List<EmployeeDTO> employee = allEmployees.stream()
		        .filter(emp -> (emp.getAssociateId()).equals(empId))
		        .collect(Collectors.toList());
		
		return employee;
	}

	@Override
	public List<LeaveTransactionDTO> getLeaveTransactionsById(String empId) throws FailedToReadJsonException {
		List<LeaveTransactionDTO> allLeaveTransactions = LeaveTransactionsDataLoader.readJsonAndGetLeaveDetails();
		List<LeaveTransactionDTO> LeavesOfEmp = allLeaveTransactions.stream()
		        .filter(leave -> (leave.getAssociateId()).equals(empId))
		        .collect(Collectors.toList());
		
		return LeavesOfEmp;
	}


	@Override
	public List<EmployeeDTO> getEmployeeDetailsByManagerIdFromEmployeeData(String managerId) throws FailedToReadJsonException {
		List<EmployeeDTO> allEmployees = EmployeeDataLoader.readJsonAndGetEmployees();
		List<EmployeeDTO> employee = allEmployees.stream()
		        .filter(emp -> (emp.getManagerId()).equals(managerId))
		        .collect(Collectors.toList());
		
		return employee;
	}

	@Override
	public List<ObjectEntitlementDTO> getEmployeeDetailsByManagerIdFromManagerData(String managerId) throws FailedToReadJsonException {
		List<ObjectEntitlementDTO> allManagers = ObjectEntitlementsDataLoader.readJsonAndGetManagerDetails();
		List<ObjectEntitlementDTO> manager = allManagers.stream()
		        .filter(m -> (m.getManagerId()).equals(managerId))
		        .collect(Collectors.toList());
		
		return manager;
	}

	@Override
	public List<EmployeeLeaveDTO> getEmployeeLeaveDetailsById(String associateId) throws FailedToReadJsonException {
		List<EmployeeDTO> allEmployees = EmployeeDataLoader.readJsonAndGetEmployees();
		List<EmployeeDTO> employeelist = allEmployees.stream()
		        .filter(emp -> (emp.getAssociateId()).equals(associateId))
		        .collect(Collectors.toList());
		EmployeeDTO employee = employeelist.get(0);
		List<LeaveTransactionDTO> allLeaveTransactions = LeaveTransactionsDataLoader.readJsonAndGetLeaveDetails();
		List<LeaveTransactionDTO> LeavesOfEmp = allLeaveTransactions.stream()
		        .filter(leave -> (leave.getAssociateId()).equals(associateId))
		        .collect(Collectors.toList());
		List<EmployeeLeaveDTO> empLeaveDetails = new ArrayList<>();
		for (LeaveTransactionDTO leave: LeavesOfEmp) {
			empLeaveDetails.add(new EmployeeLeaveDTO(associateId, leave.getLeaveType(), leave.getLeaveFromDate(), leave.getLeaveToDate(), leave.getLeaveStatus(), employee.getEmployeeName(), employee.getEmployeeDesignation(), "-", employee.getManagerName(), "wfo", "-"));
		}
		return empLeaveDetails;
	}

	@Override
	public List<String> frequentSickLeave(String managerId) throws FailedToReadJsonException {
		List<ObjectEntitlementDTO> allManagers = ObjectEntitlementsDataLoader.readJsonAndGetManagerDetails();
		List<ObjectEntitlementDTO> manager = allManagers.stream()
		        .filter(m -> (m.getManagerId()).equals(managerId))
		        .collect(Collectors.toList());
		List<LeaveTransactionDTO> allLeaveTransactions = LeaveTransactionsDataLoader.readJsonAndGetLeaveDetails();
		List<LeaveTransactionDTO> sickLeaves=allLeaveTransactions.stream()
		        .filter(m -> (m.getLeaveType()).equals("Sick Leave"))
		        .filter(m -> (m.getLeaveStatus()).equals("Approved"))
		        .collect(Collectors.toList());
		List<String> freqSickemps=new ArrayList<>();
		int count;
		List<LeaveTransactionDTO> LeaveTransactionsOfEmp=new ArrayList<LeaveTransactionDTO>();
		for(ObjectEntitlementDTO emp : manager)
		{
			count=0;
			LeaveTransactionsOfEmp.removeAll(LeaveTransactionsOfEmp);
			for(LeaveTransactionDTO singleLeave: sickLeaves)
			{
				boolean cond=emp.getEmployeeName().equals(singleLeave.getEmployeeName());
				if(cond)
				{
					LeaveTransactionsOfEmp.add(singleLeave);
				}
			}
			LocalDate todayDate=LocalDate.now();
			for(int i=0;i<LeaveTransactionsOfEmp.size();i++)
			{
				if(todayDate.getMonth().equals(LeaveTransactionsOfEmp.get(i).getLeaveFromDate().getMonth()))
				{
					count=count+(LeaveTransactionsOfEmp.get(i).getLeaveToDate().getDayOfMonth()-
							LeaveTransactionsOfEmp.get(i).getLeaveFromDate().getDayOfMonth())+1;
				}
			}
			if(count>=2)
			{
				String ret=emp.getEmployeeName()+" has taken "+count+" sick leaves";
				freqSickemps.add(ret);
			}
		}
		
		
		return freqSickemps;
	}

	@Override
	public List<String> noLeaveOf3months(String managerId) throws FailedToReadJsonException {
		List<ObjectEntitlementDTO> allManagers = ObjectEntitlementsDataLoader.readJsonAndGetManagerDetails();
		List<ObjectEntitlementDTO> manager = allManagers.stream()
		        .filter(m -> (m.getManagerId()).equals(managerId))
		        .collect(Collectors.toList());
		List<LeaveTransactionDTO> allLeaveTransactions = LeaveTransactionsDataLoader.readJsonAndGetLeaveDetails();
		List<String> Noleaveemps=new ArrayList<>();
		List<LeaveTransactionDTO> LeaveTransactionsOfEmp= new ArrayList<>();
		for(ObjectEntitlementDTO emp : manager)
		{
			LeaveTransactionsOfEmp.removeAll(LeaveTransactionsOfEmp);
			for(LeaveTransactionDTO singleLeave: allLeaveTransactions)
			{
				if(emp.getEmployeeName().equals(singleLeave.getEmployeeName()))
				{
					LeaveTransactionsOfEmp.add(singleLeave);
				}
			}
			int count=0;
			LocalDate todayDate=LocalDate.now();
			for(int i=0;i<LeaveTransactionsOfEmp.size();i++)
			{
				if(LeaveTransactionsOfEmp.get(i).getLeaveFromDate().getMonth().equals(todayDate.getMonth())
				||LeaveTransactionsOfEmp.get(i).getLeaveFromDate().getMonth().equals(todayDate.with(TemporalAdjusters.firstDayOfMonth()).minusMonths(1).getMonth())
				||LeaveTransactionsOfEmp.get(i).getLeaveFromDate().getMonth().equals(todayDate.with(TemporalAdjusters.firstDayOfMonth()).minusMonths(2).getMonth()))
				{
					count++;
				}
			}
			if(count==0)
			{
				String ret=emp.getEmployeeName()+" has not taken any leaves in three months";
				Noleaveemps.add(ret);
			}
		}
		
		
		return Noleaveemps;
	}

	@Override
	public List<String> consec3NightShifts(String managerId) throws FailedToReadJsonException {
		List<ObjectEntitlementDTO> allManagers = ObjectEntitlementsDataLoader.readJsonAndGetManagerDetails();
		List<ObjectEntitlementDTO> manager = allManagers.stream()
		        .filter(m -> (m.getManagerId()).equals(managerId))
		        .collect(Collectors.toList());
		List<WorkScheduleDTO> allSchedules = WorkSchedulesDataLoader.readJsonAndGetWorkSchedules();
		List<String> str=new ArrayList<>();
		for(ObjectEntitlementDTO emp:manager)
		{
			List<LocalDate> NightShiftEmp=new ArrayList<>();
			List<WorkScheduleDTO> EmpSchedulesOfNightShift=new ArrayList<>();
			List<WorkScheduleDTO> SchedulesOfEmp = allSchedules.stream()
					.filter(m -> (m.getEmpName()).equals(emp.getEmployeeName()))
					.collect(Collectors.toList());
				for(WorkScheduleDTO wsEmp: SchedulesOfEmp)
				{
					if(wsEmp.getShifttype().equals("Night Shift"))
					{
						NightShiftEmp.add(wsEmp.getDate());
						EmpSchedulesOfNightShift.add(wsEmp);
					}
				}
				Collections.sort(NightShiftEmp);
				for(int i=1;i<EmpSchedulesOfNightShift.size()-1;i++)
				{
					LocalDate currdate=EmpSchedulesOfNightShift.get(i).getDate();
					LocalDate prevdate=currdate.minusDays(1);
					LocalDate nextdate=currdate.plusDays(1);
					if(EmpSchedulesOfNightShift.get(i-1).getDate().equals(prevdate) && EmpSchedulesOfNightShift.get(i+1).getDate().equals(nextdate)
							&& !(str.contains(EmpSchedulesOfNightShift.get(i).getEmpName()+" has had more than 2 consecutive night shifts")))
					{
						str.add(EmpSchedulesOfNightShift.get(i).getEmpName()+" has had more than 2 consecutive night shifts");
					}
				}
		}
		
		return str;
	}
	
	@Override
	public LeaveCountbyDayDTO[] leaveCountOfEverydayMonthbyDay(String managerId) throws FailedToReadJsonException
	{
	LeaveCountbyDayDTO[] array = new LeaveCountbyDayDTO[30];
	for(int k=0;k<30;k++)
	{
	array[k]=new LeaveCountbyDayDTO(0,0);
	}
	LocalDate date=LocalDate.now();
	List<ObjectEntitlementDTO> allManagers = ObjectEntitlementsDataLoader.readJsonAndGetManagerDetails();
	List<ObjectEntitlementDTO> manager = allManagers.stream()
	.filter(m -> (m.getManagerId()).equals(managerId))
	.collect(Collectors.toList());
	List<LeaveTransactionDTO> allLeaveTransactions = LeaveTransactionsDataLoader.readJsonAndGetLeaveDetails();
	List<LeaveTransactionDTO> leaves=allLeaveTransactions.stream()
	.filter(m -> (m.getLeaveFromDate().getMonth()).equals(date.getMonth()))
	.filter(m -> (m.getLeaveStatus()).equals("Approved"))
	.collect(Collectors.toList());
	for(ObjectEntitlementDTO emp:manager)
	{
	for(LeaveTransactionDTO leave:leaves)
	{
	if(leave.getEmployeeName().equals(emp.getEmployeeName()))
	{
	for(int i=0;i<30;i++)
	{
	array[i].day=i+1;
	System.out.println(array[i].day);
	if(leave.getLeaveToDate().getDayOfMonth()-leave.getLeaveFromDate().getDayOfMonth()>=1 &&
	leave.getLeaveFromDate().getDayOfMonth()-1==i)
	{
	for(int j=leave.getLeaveFromDate().getDayOfMonth()-1;j<leave.getLeaveToDate().getDayOfMonth();j++)
	{
	array[j].leaveCountByDay+=1;
	}
	}
	else if(leave.getLeaveToDate().getDayOfMonth()-leave.getLeaveFromDate().getDayOfMonth()==0 &&
	leave.getLeaveFromDate().getDayOfMonth()-1==i)
	{
	array[i].leaveCountByDay+=1;
	}
	}
	}
	}
	}

	return array;
	}

	@Override
	public List<EmployeeDTO> EmpsBirthday(String managerId) throws FailedToReadJsonException {
		LocalDate date=LocalDate.now();
		List<EmployeeDTO> birthdayList=new ArrayList<>();
		List<ObjectEntitlementDTO> allManagers = ObjectEntitlementsDataLoader.readJsonAndGetManagerDetails();
		List<ObjectEntitlementDTO> manager = allManagers.stream()
		        .filter(m -> (m.getManagerId()).equals(managerId))
		        .collect(Collectors.toList());
		for(ObjectEntitlementDTO em:manager)
		{
		List<EmployeeDTO> allEmployees = EmployeeDataLoader.readJsonAndGetEmployees();
		List<EmployeeDTO> employee = allEmployees.stream()
		        .filter(emp -> (emp.getEmployeeName().equals(em.getEmployeeName())))
		        .collect(Collectors.toList());
		for(EmployeeDTO emps: employee)
		{
			if(emps.getEmployeeDOB().getDayOfMonth()==date.getDayOfMonth() && emps.getEmployeeDOB().getMonth().equals(date.getMonth()))
			{
				birthdayList.add(emps);
			}
		}
		}
		return birthdayList;
	}

	@Override
	public List<LeaveTransactionDTO> leavesOfEmpOfManager(String managerId) throws FailedToReadJsonException {
		List<ObjectEntitlementDTO> allManagers = ObjectEntitlementsDataLoader.readJsonAndGetManagerDetails();
		List<ObjectEntitlementDTO> manager = allManagers.stream()
		        .filter(m -> (m.getManagerId()).equals(managerId))
		        .collect(Collectors.toList());
		List<LeaveTransactionDTO> allLeaveTransactions = LeaveTransactionsDataLoader.readJsonAndGetLeaveDetails();
		List<LeaveTransactionDTO> leavesOfEmpUnderManager=new ArrayList<>(); 
		for(ObjectEntitlementDTO emp:manager)
		{
			for(LeaveTransactionDTO leave:allLeaveTransactions)
			{
				if(emp.getEmployeeName().equals(leave.getEmployeeName()))
				{
					leavesOfEmpUnderManager.add(leave);
				}
			}
		}
		return leavesOfEmpUnderManager;
	}

	@Override
	public List<WorkScheduleDTO> workSchedOfEmpsUnderManager(String managerId) throws FailedToReadJsonException {
		List<ObjectEntitlementDTO> allManagers = ObjectEntitlementsDataLoader.readJsonAndGetManagerDetails();
		List<ObjectEntitlementDTO> manager = allManagers.stream()
		        .filter(m -> (m.getManagerId()).equals(managerId))
		        .collect(Collectors.toList());
		List<WorkScheduleDTO> allSchedules = WorkSchedulesDataLoader.readJsonAndGetWorkSchedules();
		List<WorkScheduleDTO> TodaySchedulesOfEmp=new ArrayList<>();
		for(ObjectEntitlementDTO emp:manager)
		{
			for(WorkScheduleDTO ws:allSchedules)
				{
					if(ws.getEmpName().equals(emp.getEmployeeName()) && ws.getDate().equals(LocalDate.now()))
					{
						TodaySchedulesOfEmp.add(ws);
					}
				}
		}
		return TodaySchedulesOfEmp;
	}

	@Override
	public int[] leaveCountOfEverydayMonth(String managerId) throws FailedToReadJsonException {
		int[] dayCount=new int[30];
		LocalDate date=LocalDate.now();
		List<ObjectEntitlementDTO> allManagers = ObjectEntitlementsDataLoader.readJsonAndGetManagerDetails();
		List<ObjectEntitlementDTO> manager = allManagers.stream()
		        .filter(m -> (m.getManagerId()).equals(managerId))
		        .collect(Collectors.toList());
		List<LeaveTransactionDTO> allLeaveTransactions = LeaveTransactionsDataLoader.readJsonAndGetLeaveDetails();
		List<LeaveTransactionDTO> leaves=allLeaveTransactions.stream()
				 .filter(m -> (m.getLeaveFromDate().getMonth()).equals(date.getMonth()))
		        .filter(m -> (m.getLeaveStatus()).equals("Approved"))
		        .collect(Collectors.toList());
		for(ObjectEntitlementDTO emp:manager)
		{
			for(LeaveTransactionDTO leave:leaves)
			{
				if(leave.getEmployeeName().equals(emp.getEmployeeName()))
				{
					for(int i=0;i<30;i++)
					{
						if(leave.getLeaveToDate().getDayOfMonth()-leave.getLeaveFromDate().getDayOfMonth()>=1 &&
								leave.getLeaveFromDate().getDayOfMonth()-1==i)
						{
							for(int j=leave.getLeaveFromDate().getDayOfMonth()-1;j<leave.getLeaveToDate().getDayOfMonth();j++)
							{
								dayCount[j]+=1;
							}
						}
						else if(leave.getLeaveToDate().getDayOfMonth()-leave.getLeaveFromDate().getDayOfMonth()==0 &&
								leave.getLeaveFromDate().getDayOfMonth()-1==i)
						{
							dayCount[i]+=1;
						}
					}
				}
			}
		}
		return dayCount;
	}

	@Override
	public int[] workingCountOfEverydayMonth(String managerId) throws FailedToReadJsonException {
		int[] dayCount=new int[30];
		LocalDate date=LocalDate.now();
		List<ObjectEntitlementDTO> allManagers = ObjectEntitlementsDataLoader.readJsonAndGetManagerDetails();
		List<ObjectEntitlementDTO> manager = allManagers.stream()
		        .filter(m -> (m.getManagerId()).equals(managerId))
		        .collect(Collectors.toList());
		List<WorkScheduleDTO> allWorkSchedules = WorkSchedulesDataLoader.readJsonAndGetWorkSchedules();
		List<WorkScheduleDTO> workScheds=allWorkSchedules.stream()
				 .filter(w -> (w.getDate().getMonth()).equals(date.getMonth()))
				 .filter(w -> (w.getDayStatus()).equals("Working Day"))
		        .collect(Collectors.toList());
		for(ObjectEntitlementDTO emp:manager)
		{
			for(WorkScheduleDTO ws:workScheds)
			{
				if(ws.getEmpName().equals(emp.getEmployeeName()))
				{
					for(int i=0;i<30;i++)
					{
						if(ws.getDate().getDayOfMonth()-1==i)
						{
							dayCount[i]+=1;
						}
					}
				}
			}
		}
		return dayCount;
	}

	@Override
	public int[] nonWorkingCountOfEverydayMonth(String managerId) throws FailedToReadJsonException {
		int[] dayCount=new int[30];
		LocalDate date=LocalDate.now();
		List<ObjectEntitlementDTO> allManagers = ObjectEntitlementsDataLoader.readJsonAndGetManagerDetails();
		List<ObjectEntitlementDTO> manager = allManagers.stream()
		        .filter(m -> (m.getManagerId()).equals(managerId))
		        .collect(Collectors.toList());
		List<WorkScheduleDTO> allWorkSchedules = WorkSchedulesDataLoader.readJsonAndGetWorkSchedules();
		List<WorkScheduleDTO> workScheds=allWorkSchedules.stream()
				 .filter(w -> (w.getDate().getMonth()).equals(date.getMonth()))
				 .filter(w -> (w.getDayStatus()).equals("Non-Working Day"))
		        .collect(Collectors.toList());
		for(ObjectEntitlementDTO emp:manager)
		{
			for(WorkScheduleDTO ws:workScheds)
			{
				if(ws.getEmpName().equals(emp.getEmployeeName()))
				{
					for(int i=0;i<30;i++)
					{
						if(ws.getDate().getDayOfMonth()-1==i)
						{
							dayCount[i]+=1;
						}
					}
				}
			}
		}
		return dayCount;
	}
	
	@Override
    public List<EmployeeDTO> EmpsBirthdayUpcoming(String managerId) throws FailedToReadJsonException {
        LocalDate date=LocalDate.now();
        List<EmployeeDTO> birthdayList=new ArrayList<>();
        List<ObjectEntitlementDTO> allManagers = ObjectEntitlementsDataLoader.readJsonAndGetManagerDetails();
        List<ObjectEntitlementDTO> manager = allManagers.stream()
                .filter(m -> (m.getManagerId()).equals(managerId))
                .collect(Collectors.toList());
        for(ObjectEntitlementDTO em:manager)
        {
        List<EmployeeDTO> allEmployees = EmployeeDataLoader.readJsonAndGetEmployees();
        List<EmployeeDTO> employee = allEmployees.stream()
                .filter(emp -> (emp.getEmployeeName().equals(em.getEmployeeName())))
                .collect(Collectors.toList());
        for(EmployeeDTO emps: employee)
        {
            if(emps.getEmployeeDOB().getDayOfMonth()>date.getDayOfMonth() && emps.getEmployeeDOB().getMonth().equals(date.getMonth()))
            {
                birthdayList.add(emps);
            }
        }
        }
        return birthdayList;
    }
	
	@Override
	public List<EmployeeDTO> workAnniversaryToday(String managerId) throws FailedToReadJsonException {
		List<EmployeeDTO> todayAnniversariesList = new ArrayList();
		List<EmployeeDTO> allEmployees = EmployeeDataLoader.readJsonAndGetEmployees();
		List<EmployeeDTO> employeesUnderManager = allEmployees.stream()
		        .filter(emp -> (emp.getManagerId()).equals(managerId))
		        .collect(Collectors.toList());
		for(EmployeeDTO emp: employeesUnderManager) {
			if(emp.getDoj().getMonthValue()==LocalDate.now().getMonthValue() && emp.getDoj().getDayOfMonth()==LocalDate.now().getDayOfMonth()) {
				todayAnniversariesList.add(emp);
			}
		}
		return todayAnniversariesList;
	}
}
