package com.batch1.team1.Ecalendar.model.dto;
import java.time.LocalDate;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class EmployeeDTO {
	
	String associateId;
	String workerId;
	String employeeName;
	String employeeDesignation;
	LocalDate employeeDOB;
	String managerId;
	String managerName;
	String emailId;
	LocalDate doj;
	
}
