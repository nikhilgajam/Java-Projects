package com.batch1.team1.Ecalendar.aop;

import org.springframework.stereotype.Component;

import java.util.Date;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;

@Aspect
@Component
public class EClaendarAspect {
	
	@Pointcut("execution(* com.batch1.team1.Ecalendar.controller.ECalenderController.*(..))")
	public void ECalenderControllerPointcut() {
		
	}
	
	@Before("ECalenderControllerPointcut()")
	public void after1(JoinPoint joinPoint)
	{
		System.out.println("Request to "+ joinPoint.getSignature().getName()+" started at "+ new Date());
	}
	
	@After("ECalenderControllerPointcut()")
	public void before1(JoinPoint joinPoint)
	{
		System.out.println("Request to "+ joinPoint.getSignature().getName()+" ended at "+ new Date());
	}
	
	
	
	@Pointcut("execution(* com.batch1.team1.Ecalendar.dao.EmployeeDao.*(..))")
	public void EmployeeDaoPointcut() {
		
	}
	
	@Before("EmployeeDaoPointcut()")
	public void after2(JoinPoint joinPoint)
	{
		System.out.println("Request to "+ joinPoint.getSignature().getName()+" started at "+ new Date());
	}
	
	@After("ECalenderControllerPointcut()")
	public void before2(JoinPoint joinPoint)
	{
		System.out.println("Request to "+ joinPoint.getSignature().getName()+" ended at "+ new Date());
	}
	
	
	
	@Pointcut("execution(* com.batch1.team1.Ecalendar.dao.EmployeeDaoImpl.*(..))")
	public void EmployeeDaoImplPointcut() {
		
	}
	
	@Before("EmployeeDaoImplPointcut()")
	public void after3(JoinPoint joinPoint)
	{
		System.out.println("Request to "+ joinPoint.getSignature().getName()+" started at "+ new Date());
	}
	
	@After("EmployeeDaoImplPointcut()")
	public void before3(JoinPoint joinPoint)
	{
		System.out.println("Request to "+ joinPoint.getSignature().getName()+" ended at "+ new Date());
	}
	
	
	
	@Pointcut("execution(* com.batch1.team1.Ecalendar.dao.EmployeeDataLoader.*(..))")
	public void EmployeeDataLoaderPointcut() {
		
	}
	
	@Before("EmployeeDataLoaderPointcut()")
	public void after4(JoinPoint joinPoint)
	{
		System.out.println("Request to "+ joinPoint.getSignature().getName()+" started at "+ new Date());
	}
	
	@After("EmployeeDataLoaderPointcut()")
	public void before4(JoinPoint joinPoint)
	{
		System.out.println("Request to "+ joinPoint.getSignature().getName()+" ended at "+ new Date());
	}
	
	
	
	@Pointcut("execution(* com.batch1.team1.Ecalendar.dao.LeaveTransactionsDataLoader.*(..))")
	public void LeaveTransactionsDataLoaderPointcut() {
		
	}
	
	@Before("LeaveTransactionsDataLoaderPointcut()")
	public void after5(JoinPoint joinPoint)
	{
		System.out.println("Request to "+ joinPoint.getSignature().getName()+" started at "+ new Date());
	}
	
	@After("LeaveTransactionsDataLoaderPointcut()")
	public void before5(JoinPoint joinPoint)
	{
		System.out.println("Request to "+ joinPoint.getSignature().getName()+" ended at "+ new Date());
	}
	
	
	
	@Pointcut("execution(* com.batch1.team1.Ecalendar.dao.ObjectEntitlementsDataLoader.*(..))")
	public void ObjectEntitlementsDataLoaderPointcut() {
		
	}
	
	@Before("ObjectEntitlementsDataLoaderPointcut()")
	public void after6(JoinPoint joinPoint)
	{
		System.out.println("Request to "+ joinPoint.getSignature().getName()+" started at "+ new Date());
	}
	
	@After("ObjectEntitlementsDataLoaderPointcut()")
	public void before6(JoinPoint joinPoint)
	{
		System.out.println("Request to "+ joinPoint.getSignature().getName()+" ended at "+ new Date());
	}
	
	
	
	@Pointcut("execution(* com.batch1.team1.Ecalendar.dao.WorkSchedulesDataLoader.*(..))")
	public void WorkSchedulesDataLoaderPointcut() {
		
	}
	
	@Before("WorkSchedulesDataLoaderPointcut()")
	public void after7(JoinPoint joinPoint)
	{
		System.out.println("Request to "+ joinPoint.getSignature().getName()+" started at "+ new Date());
	}
	
	@After("WorkSchedulesDataLoaderPointcut()")
	public void before7(JoinPoint joinPoint)
	{
		System.out.println("Request to "+ joinPoint.getSignature().getName()+" ended at "+ new Date());
	}
	
	
	
	@Pointcut("execution(* com.batch1.team1.Ecalendar.model.dto.EmployeeDTO.*(..))")
	public void DTOPointcut1() {
		
	}
	
	
	@Before("DTOPointcut1()")
	public void after8(JoinPoint joinPoint)
	{
		System.out.println("Request to "+ joinPoint.getSignature().getName()+" started at "+ new Date());
	}
	
	@After("DTOPointcut1()")
	public void before8(JoinPoint joinPoint)
	{
		System.out.println("Request to "+ joinPoint.getSignature().getName()+" ended at "+ new Date());
	}
	
	
	@Pointcut("execution(* com.batch1.team1.Ecalendar.model.dto.EmployeeLeaveDTO.*(..))")
	public void DTOPointcut2() {
		
	}
	
	@Before("DTOPointcut2()")
	public void after9(JoinPoint joinPoint)
	{
		System.out.println("Request to "+ joinPoint.getSignature().getName()+" started at "+ new Date());
	}
	
	@After("DTOPointcut2()")
	public void before9(JoinPoint joinPoint)
	{
		System.out.println("Request to "+ joinPoint.getSignature().getName()+" ended at "+ new Date());
	}
	
	
	@Pointcut("execution(* com.batch1.team1.Ecalendar.model.dto.LeaveTransactionDTO.*(..))")
	public void DTOPointcut3() {
		
	}
	
	@Before("DTOPointcut3()")
	public void after10(JoinPoint joinPoint)
	{
		System.out.println("Request to "+ joinPoint.getSignature().getName()+" started at "+ new Date());
	}
	
	@After("DTOPointcut3()")
	public void before10(JoinPoint joinPoint)
	{
		System.out.println("Request to "+ joinPoint.getSignature().getName()+" ended at "+ new Date());
	}
	
	
	@Pointcut("execution(* com.batch1.team1.Ecalendar.model.dto.ObjectEntitlementDTO.*(..))")
	public void DTOPointcut4() {
		
	}
	
	@Before("DTOPointcut4()")
	public void after11(JoinPoint joinPoint)
	{
		System.out.println("Request to "+ joinPoint.getSignature().getName()+" started at "+ new Date());
	}
	
	@After("DTOPointcut4()")
	public void before11(JoinPoint joinPoint)
	{
		System.out.println("Request to "+ joinPoint.getSignature().getName()+" ended at "+ new Date());
	}
	
	
	
	@Pointcut("execution(* com.batch1.team1.Ecalendar.model.dto.WorkScheduleDTO.*(..))")
	public void DTOPointcut5() {
		
	}
	
	@Before("DTOPointcut5()")
	public void after12(JoinPoint joinPoint)
	{
		System.out.println("Request to "+ joinPoint.getSignature().getName()+" started at "+ new Date());
	}
	
	@After("DTOPointcut5()")
	public void before12(JoinPoint joinPoint)
	{
		System.out.println("Request to "+ joinPoint.getSignature().getName()+" ended at "+ new Date());
	}
	
	
	@Pointcut("execution(* com.batch1.team1.Ecalendar.service.EmployeeService.*(..))")
	public void servicePointcut1() {
		
	}
	
	@Before("servicePointcut1()")
	public void after13(JoinPoint joinPoint)
	{
		System.out.println("Request to "+ joinPoint.getSignature().getName()+" started at "+ new Date());
	}
	
	@After("servicePointcut1()")
	public void before13(JoinPoint joinPoint)
	{
		System.out.println("Request to "+ joinPoint.getSignature().getName()+" ended at "+ new Date());
	}
	
	
	@Pointcut("execution(* com.batch1.team1.Ecalendar.service.EmployeeServiceImpl.*(..))")
	public void servicePointcut2() {
		
	}
	
	@Before("servicePointcut2()")
	public void after14(JoinPoint joinPoint)
	{
		System.out.println("Request to "+ joinPoint.getSignature().getName()+" started at "+ new Date());
	}
	
	@After("servicePointcut2()")
	public void before14(JoinPoint joinPoint)
	{
		System.out.println("Request to "+ joinPoint.getSignature().getName()+" ended at "+ new Date());
	}
    
}
