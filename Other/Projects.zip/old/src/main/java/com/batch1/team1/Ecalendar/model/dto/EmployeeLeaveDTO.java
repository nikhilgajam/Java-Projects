package com.batch1.team1.Ecalendar.model.dto;
import java.time.LocalDate;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class EmployeeLeaveDTO {
	
	String associateId;
	String title;
	LocalDate start;
	LocalDate end;
	String status;
	String name;
	String designation;
	String employmentType;
	String reportingTo;
	String wfh_wfo;
	String workLocation;
	
}
