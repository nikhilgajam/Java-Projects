package com.batch1.team1.Ecalendar.utils;

public class FailedToReadJsonException extends Exception
{ 
           public FailedToReadJsonException(String errorMessage) {
               super(errorMessage);
           }
}
