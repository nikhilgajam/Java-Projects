package com.batch1.team1.Ecalendar.model.dto;
import java.time.LocalDate;

import lombok.Getter;
import lombok.Setter;
import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class WorkScheduleDTO {
	
	String empName;
	String associateId;
	LocalDate date;
	String weekDay;
	String dayStatus;
	int totalHours;
	String startTime;
	String endTime;
	String shifttype;
	
}
