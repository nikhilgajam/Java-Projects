package com.batch1.team1.Ecalendar.dao;

import java.util.List;

import com.batch1.team1.Ecalendar.model.dto.EmployeeDTO;
import com.batch1.team1.Ecalendar.model.dto.EmployeeLeaveDTO;
import com.batch1.team1.Ecalendar.model.dto.LeaveCountbyDayDTO;
import com.batch1.team1.Ecalendar.model.dto.LeaveTransactionDTO;
import com.batch1.team1.Ecalendar.model.dto.ObjectEntitlementDTO;
import com.batch1.team1.Ecalendar.model.dto.WorkScheduleDTO;
import com.batch1.team1.Ecalendar.utils.FailedToReadJsonException;

public interface EmployeeDao {
	
	public List<WorkScheduleDTO> getWorkSchedulesById(String empId) throws FailedToReadJsonException;

	public List<EmployeeDTO> getEmployeeDetailsById(String empId) throws FailedToReadJsonException;

	public List<LeaveTransactionDTO> getLeaveTransactionsById(String empId) throws FailedToReadJsonException;

	List<EmployeeDTO> getEmployeeDetailsByManagerIdFromEmployeeData(String managerId) throws FailedToReadJsonException;

	List<ObjectEntitlementDTO> getEmployeeDetailsByManagerIdFromManagerData(String managerId) throws FailedToReadJsonException;

	public List<EmployeeLeaveDTO> getEmployeeLeaveDetailsById(String associateId) throws FailedToReadJsonException;
	
	public List<String> frequentSickLeave(String managerId) throws FailedToReadJsonException;
	
	public List<String> noLeaveOf3months(String managerId) throws FailedToReadJsonException;
	
	public List<String> consec3NightShifts(String managerId) throws FailedToReadJsonException;
	
	public List<EmployeeDTO> EmpsBirthday(String managerId) throws FailedToReadJsonException;
	
	public List<LeaveTransactionDTO> leavesOfEmpOfManager(String managerId) throws FailedToReadJsonException;
	
	public List<WorkScheduleDTO> workSchedOfEmpsUnderManager(String managerId) throws FailedToReadJsonException;
	
	public int[] leaveCountOfEverydayMonth(String managerId) throws FailedToReadJsonException;
	
	public int[] workingCountOfEverydayMonth(String managerId) throws FailedToReadJsonException;
	
	public int[] nonWorkingCountOfEverydayMonth(String managerId) throws FailedToReadJsonException;

	List<EmployeeDTO> workAnniversaryToday(String managerId) throws FailedToReadJsonException;

	List<EmployeeDTO> EmpsBirthdayUpcoming(String managerId) throws FailedToReadJsonException;

	LeaveCountbyDayDTO[] leaveCountOfEverydayMonthbyDay(String managerId) throws FailedToReadJsonException;


}
