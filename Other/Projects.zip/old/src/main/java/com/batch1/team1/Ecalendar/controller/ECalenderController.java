package com.batch1.team1.Ecalendar.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.batch1.team1.Ecalendar.dao.EmployeeDataLoader;
import com.batch1.team1.Ecalendar.dao.LeaveTransactionsDataLoader;
import com.batch1.team1.Ecalendar.dao.WorkSchedulesDataLoader;
import com.batch1.team1.Ecalendar.model.dto.EmployeeDTO;
import com.batch1.team1.Ecalendar.model.dto.EmployeeLeaveDTO;
import com.batch1.team1.Ecalendar.model.dto.LeaveCountbyDayDTO;
import com.batch1.team1.Ecalendar.model.dto.LeaveTransactionDTO;
import com.batch1.team1.Ecalendar.model.dto.LoginDetailsDTO;
import com.batch1.team1.Ecalendar.model.dto.ObjectEntitlementDTO;
import com.batch1.team1.Ecalendar.model.dto.WorkScheduleDTO;
import com.batch1.team1.Ecalendar.service.EmployeeService;
import com.batch1.team1.Ecalendar.utils.FailedToReadJsonException;

@RestController
@RequestMapping
@CrossOrigin("*")
public class ECalenderController {
	
	@Autowired
	EmployeeService service;

	
	@GetMapping("/getAllEmployees")
	public List<EmployeeDTO> getEmployees() throws FailedToReadJsonException{
		return EmployeeDataLoader.readJsonAndGetEmployees();
	}
	
	@GetMapping("/getAllWorkSchedules")
	public List<WorkScheduleDTO> getWorkSchedules() throws FailedToReadJsonException{
		return WorkSchedulesDataLoader.readJsonAndGetWorkSchedules();
	}
	
	@GetMapping("/getAllLeaveTransactions")
	public List<LeaveTransactionDTO> getLeaveTransactions() throws FailedToReadJsonException{
		return LeaveTransactionsDataLoader.readJsonAndGetLeaveDetails();
	}
	
	@GetMapping(value="/getEmployeeDetailsById/{empId}")
	public ResponseEntity<List<EmployeeDTO>> getEmployeeDetailsById(@PathVariable String empId) throws FailedToReadJsonException{
		List<EmployeeDTO> employeeList= service.getEmployeeDetailsById(empId);
		
		for(EmployeeDTO emp:employeeList)
		{
		if(emp.getAssociateId().equals(empId))
		{
			return new ResponseEntity<>(employeeList,HttpStatus.OK);
		}
		}
			return ResponseEntity.badRequest().build();
	}
	
	@GetMapping("/getWorkschedulesById/{empId}")
	public ResponseEntity<List<WorkScheduleDTO>> getWorkSchedulesById(@PathVariable String empId) throws FailedToReadJsonException{
		List<WorkScheduleDTO> workScheduleList = service.getWorkSchedulesById(empId);
		for(WorkScheduleDTO work:workScheduleList)
		{
		if(work.getAssociateId().equals(empId))
		{
			return new ResponseEntity<>(workScheduleList,HttpStatus.OK);
		}
		}
			return ResponseEntity.badRequest().build();
		
	}
	
	@GetMapping("/getLeaveTransactionsById/{empId}")
	public ResponseEntity<List<LeaveTransactionDTO>> getLeaveTransactionsById(@PathVariable String empId) throws FailedToReadJsonException{
		List<LeaveTransactionDTO> leaveTransactionList = service.getLeaveTransactionsById(empId);
		
		for(LeaveTransactionDTO leave:leaveTransactionList)
		{
		if(leave.getAssociateId().equals(empId))
		{
			return new ResponseEntity<>(leaveTransactionList,HttpStatus.OK);
		}
		}
			return ResponseEntity.badRequest().build();
		
	}
	
	
	@GetMapping("/getEmployeeDetailsByManagerIdFromEmployeeData/{managerId}")
	public ResponseEntity<List<EmployeeDTO>> getEmployeeDetailsByManagerIdFromEmployeeData(@PathVariable String managerId) throws FailedToReadJsonException{
		List<EmployeeDTO> employeeBymanagerIdList = service.getEmployeeDetailsByManagerIdFromEmployeeData(managerId);
	
		for(EmployeeDTO empByManagerEmpDTO:employeeBymanagerIdList)
		{
		if(empByManagerEmpDTO.getManagerId().equals(managerId))
		{
			return new ResponseEntity<>(employeeBymanagerIdList,HttpStatus.OK);
		}
		}
			return ResponseEntity.badRequest().build();
		
	}
	
	@GetMapping("/getEmployeeDetailsByManagerIdFromManagerData/{managerId}")
	public ResponseEntity<List<ObjectEntitlementDTO>> getEmployeeDetailsByManagerIdFromManagerData(@PathVariable String managerId) throws FailedToReadJsonException{
		List<ObjectEntitlementDTO> employeeDetailsByManagerIdFromManagerDataList = service.getEmployeeDetailsByManagerIdFromManagerData(managerId);
		
		for(ObjectEntitlementDTO empByManager:employeeDetailsByManagerIdFromManagerDataList)
		{
		if(empByManager.getManagerId().equals(managerId))
		{
			return new ResponseEntity<>(employeeDetailsByManagerIdFromManagerDataList,HttpStatus.OK);
		}
		}
			return ResponseEntity.badRequest().build();
	}
	
	
	@GetMapping("/getEmployeeLeaveDetailsById/{associateId}")
	public ResponseEntity<List<EmployeeLeaveDTO>> getEmployeeLeaveDetailsById(@PathVariable String associateId) throws FailedToReadJsonException{
		List<EmployeeLeaveDTO> employeeLeaveDetailsByIdList = service.getEmployeeLeaveDetailsById(associateId);
		
		for(EmployeeLeaveDTO empLeave:employeeLeaveDetailsByIdList)
		{
		if(empLeave.getAssociateId().equals(associateId))
		{
			return new ResponseEntity<>(employeeLeaveDetailsByIdList,HttpStatus.OK);
		}
		}
			return ResponseEntity.badRequest().build();
		
	}
	
	@GetMapping("/ManagerInsight1/{managerId}")
	public ResponseEntity<List<String>> frequentSickLeave(@PathVariable String managerId) throws FailedToReadJsonException{
		List<String> managerInsight1 = service.frequentSickLeave(managerId);
			return new ResponseEntity<>(managerInsight1,HttpStatus.OK);
	}
	
	@GetMapping("/ManagerInsight2/{managerId}")
	public ResponseEntity<List<String>> noLeaveOf3months(@PathVariable String managerId) throws FailedToReadJsonException{
		List<String> managerInsight2 = service.noLeaveOf3months(managerId);
		return new ResponseEntity<>(managerInsight2,HttpStatus.OK);
	}

	@GetMapping("/ManagerInsight3/{managerId}")
	public ResponseEntity<List<String>> consec3NightShifts(@PathVariable String managerId) throws FailedToReadJsonException{
		List<String> managerInsight3 = service.consec3NightShifts(managerId);
		return new ResponseEntity<>(managerInsight3,HttpStatus.OK);
	}
	
	@GetMapping("/ManagerInsight4/{managerId}")
	public ResponseEntity<List<EmployeeDTO>> EmpsBirthday(@PathVariable String managerId) throws FailedToReadJsonException{
		List<EmployeeDTO> empsBirthday = service.EmpsBirthday(managerId);
		for(EmployeeDTO emp:empsBirthday)
		{
		if(emp.getManagerId().equals(managerId))
		{
			return new ResponseEntity<>(empsBirthday,HttpStatus.OK);
		}
		}
			return ResponseEntity.badRequest().build();
	}
	
	@PostMapping("/login")
	public ResponseEntity<String> loginValidate(@RequestBody LoginDetailsDTO dto) {
	String msg;
	if (service.LoginValidate(dto)) {
	msg = "Success";
	return new ResponseEntity<>(msg, HttpStatus.OK);
	} else {
	msg = "Failed";
	return new ResponseEntity<>(msg, HttpStatus.UNAUTHORIZED);
	}
	}
	
	@GetMapping("/leavesOfEmpOfManager/{managerId}")
	ResponseEntity<List<LeaveTransactionDTO>> leavesOfEmpOfManager(@PathVariable String managerId) throws FailedToReadJsonException{
		List<LeaveTransactionDTO> leavesOfEmpOfManagerList = service.leavesOfEmpOfManager(managerId); 
			return new ResponseEntity<>(leavesOfEmpOfManagerList,HttpStatus.OK);
	}
	
	@GetMapping("/workSchedOfEmpsUnderManager/{managerId}")
	ResponseEntity<List<WorkScheduleDTO>> workSchedOfEmpsUnderManager(@PathVariable String managerId) throws FailedToReadJsonException
	{
		List<WorkScheduleDTO> workScheduleList = service.workSchedOfEmpsUnderManager(managerId);
		return new ResponseEntity<>(workScheduleList,HttpStatus.OK);
	}
	
	
	@GetMapping("/leaveCountOfEverydayMonthbyDay/{managerId}")
	public ResponseEntity<LeaveCountbyDayDTO[]> leaveCountOfEverydayMonthbyDay(@PathVariable String managerId) throws FailedToReadJsonException
	{
		return new ResponseEntity<>(service.leaveCountOfEverydayMonthbyDay(managerId),HttpStatus.OK);
	}
	
	@GetMapping("/workingCountOfEverydayMonth/{managerId}")
    public ResponseEntity<int[]> workingCountOfEverydayMonth(@PathVariable String managerId) throws FailedToReadJsonException
    {
        return new ResponseEntity<>(service.workingCountOfEverydayMonth(managerId),HttpStatus.OK);
    }
    
    @GetMapping("/nonWorkingCountOfEverydayMonth/{managerId}")
    public ResponseEntity<int[]> nonWorkingCountOfEverydayMonth(@PathVariable String managerId) throws FailedToReadJsonException
    {
        return new ResponseEntity<>(service.nonWorkingCountOfEverydayMonth(managerId),HttpStatus.OK);
    }
    
    @GetMapping("/workAnniversariesByManagerId/{managerId}")
    public ResponseEntity<List<EmployeeDTO>> workAnniversaryToday(@PathVariable String managerId) throws FailedToReadJsonException {        
        List<EmployeeDTO> empsWorkAnniversary = service.workAnniversaryToday(managerId);
        for(EmployeeDTO emp:empsWorkAnniversary)
        {
        if(emp.getManagerId().equals(managerId))
        {
            return new ResponseEntity<>(empsWorkAnniversary,HttpStatus.OK);
        }
        }
            return ResponseEntity.badRequest().build();
    }
    
    @GetMapping("/ManagerInsight5/{managerId}")
    public ResponseEntity<List<EmployeeDTO>> EmpsBirthdayUpcoming(@PathVariable String managerId) throws FailedToReadJsonException{        
        List<EmployeeDTO> empsBirthdayComing = service.EmpsBirthdayUpcoming(managerId);
        for(EmployeeDTO emp:empsBirthdayComing)
        {
        if(emp.getManagerId().equals(managerId))
        {
            return new ResponseEntity<>(empsBirthdayComing,HttpStatus.OK);
        }
        }
            return ResponseEntity.badRequest().build();
    }


}
