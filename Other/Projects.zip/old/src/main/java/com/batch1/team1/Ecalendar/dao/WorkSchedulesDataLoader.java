package com.batch1.team1.Ecalendar.dao;

import java.io.IOException;
import java.io.InputStream;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Component;

import com.batch1.team1.Ecalendar.model.dto.WorkScheduleDTO;
import com.batch1.team1.Ecalendar.utils.FailedToReadJsonException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;


@Component
public class WorkSchedulesDataLoader {
	
	public static List<WorkScheduleDTO> readJsonAndGetWorkSchedules() throws FailedToReadJsonException {
    	
		String DATE_PATTERN = "yyyy-MM-dd"; 
   	 	ObjectMapper objectMapper = new ObjectMapper();
   	 
   	 	List<WorkScheduleDTO> WorkSchedules = new ArrayList<>();
	   	JsonNode json;

       try (InputStream inputStream = TypeReference.class.getResourceAsStream("/data/work-schedules-response.json")) {
       	json = objectMapper.readValue(inputStream, JsonNode.class);
       } catch (IOException e) {
           throw new FailedToReadJsonException("Failed to read JSON data");
       }

       JsonNode workSchedules = getWorkSchedules(json);
       for (JsonNode workSchedule : workSchedules) {
    	   WorkSchedules.addAll(getDaysFromSchedulePeriods(workSchedule));
       } 
       
       
       WorkSchedules.add(new WorkScheduleDTO("Aaron Baker","435628",LocalDate.parse("2023-09-01",
    		   DateTimeFormatter.ofPattern(DATE_PATTERN)),"Friday","Working Day",8,"08:30:00Z",
    		   "17:00:00Z","Day Shift"));
       WorkSchedules.add(new WorkScheduleDTO("Helen Ward","473742",LocalDate.parse("2023-09-01",
    		   DateTimeFormatter.ofPattern(DATE_PATTERN)),"Friday","Non-Working Day",0,"-",
    		   "-","-"));
       WorkSchedules.add(new WorkScheduleDTO("Maria Newman", "837483",LocalDate.parse("2023-09-01",
    		   DateTimeFormatter.ofPattern(DATE_PATTERN)),"Friday","Working Day",8,"08:30:00Z",
    		   "17:00:00Z","Day Shift"));
       WorkSchedules.add(new WorkScheduleDTO("Shirley Booth", "237867",LocalDate.parse("2023-09-01",
    		   DateTimeFormatter.ofPattern(DATE_PATTERN)),"Friday","Working Day",8,"08:30:00Z",
    		   "17:00:00Z","Day Shift"));
       WorkSchedules.add(new WorkScheduleDTO("Michael Harwood", "237865",LocalDate.parse("2023-09-01",
    		   DateTimeFormatter.ofPattern(DATE_PATTERN)),"Friday","Working Day",8,"08:30:00Z",
    		   "17:00:00Z","Day Shift"));
       WorkSchedules.add(new WorkScheduleDTO("Alecia Moore", "237866",LocalDate.parse("2023-09-01",
    		   DateTimeFormatter.ofPattern(DATE_PATTERN)),"Friday","Working Day",8,"08:30:00Z",
    		   "17:00:00Z","Day Shift"));
       WorkSchedules.add(new WorkScheduleDTO("Jean Scott", "237870",LocalDate.parse("2023-09-01",
    		   DateTimeFormatter.ofPattern(DATE_PATTERN)),"Friday","Working Day",8,"08:30:00Z",
    		   "17:00:00Z","Day Shift"));
       
       
       WorkSchedules.add(new WorkScheduleDTO("Aaron Baker","435628",LocalDate.parse("2023-09-02",
    		   DateTimeFormatter.ofPattern(DATE_PATTERN)),"Saturday","Non-Working Day",0,"-","-","-"));
       
       WorkSchedules.add(new WorkScheduleDTO("Helen Ward", "473742",LocalDate.parse("2023-09-02",
    		   DateTimeFormatter.ofPattern(DATE_PATTERN)),"Saturday","Non-Working Day",0,"-","-","-"));
       
       WorkSchedules.add(new WorkScheduleDTO("Maria Newman", "837483",LocalDate.parse("2023-09-02",
    		   DateTimeFormatter.ofPattern(DATE_PATTERN)),"Saturday","Non-Working Day",0,"-","-","-"));
       
       WorkSchedules.add(new WorkScheduleDTO("Shirley Booth", "237867",LocalDate.parse("2023-09-02",
    		   DateTimeFormatter.ofPattern(DATE_PATTERN)),"Saturday","Non-Working Day",0,"-","-","-"));
       
       WorkSchedules.add(new WorkScheduleDTO("Michael Harwood", "237865",LocalDate.parse("2023-09-02",
    		   DateTimeFormatter.ofPattern(DATE_PATTERN)),"Saturday","Non-Working Day",0,"-","-","-"));
       
       WorkSchedules.add(new WorkScheduleDTO("Alecia Moore", "237866",LocalDate.parse("2023-09-02",
    		   DateTimeFormatter.ofPattern(DATE_PATTERN)),"Saturday","Non-Working Day",0,"-","-","-"));
       
       WorkSchedules.add(new WorkScheduleDTO("Jean Scott", "237870",LocalDate.parse("2023-09-02",
    		   DateTimeFormatter.ofPattern(DATE_PATTERN)),"Saturday","Non-Working Day",0,"-","-","-"));
       
       
       
       
       WorkSchedules.add(new WorkScheduleDTO("Aaron Baker","435628",LocalDate.parse("2023-09-03",
    		   DateTimeFormatter.ofPattern(DATE_PATTERN)),"Sunday","Non-Working Day",0,"-","-","-"));
       
       WorkSchedules.add(new WorkScheduleDTO("Aaron Baker","435628",LocalDate.parse("2023-09-03",
    		   DateTimeFormatter.ofPattern(DATE_PATTERN)),"Sunday","Non-Working Day",0,"-","-","-"));
       
       WorkSchedules.add(new WorkScheduleDTO("Helen Ward", "473742",LocalDate.parse("2023-09-03",
    		   DateTimeFormatter.ofPattern(DATE_PATTERN)),"Sunday","Non-Working Day",0,"-","-","-"));
       
       WorkSchedules.add(new WorkScheduleDTO("Maria Newman", "837483",LocalDate.parse("2023-09-03",
    		   DateTimeFormatter.ofPattern(DATE_PATTERN)),"Sunday","Non-Working Day",0,"-","-","-"));
       
       WorkSchedules.add(new WorkScheduleDTO("Shirley Booth", "237867",LocalDate.parse("2023-09-03",
    		   DateTimeFormatter.ofPattern(DATE_PATTERN)),"Sunday","Non-Working Day",0,"-","-","-"));
       
       WorkSchedules.add(new WorkScheduleDTO("Michael Harwood", "237865",LocalDate.parse("2023-09-03",
    		   DateTimeFormatter.ofPattern(DATE_PATTERN)),"Sunday","Non-Working Day",0,"-","-","-"));
       
       WorkSchedules.add(new WorkScheduleDTO("Alecia Moore", "237866",LocalDate.parse("2023-09-03",
    		   DateTimeFormatter.ofPattern(DATE_PATTERN)),"Sunday","Non-Working Day",0,"-","-","-"));
       
       WorkSchedules.add(new WorkScheduleDTO("Jean Scott", "237870",LocalDate.parse("2023-09-03",
    		   DateTimeFormatter.ofPattern(DATE_PATTERN)),"Sunday","Non-Working Day",0,"-","-","-"));
       
       
       
       WorkSchedules.add(new WorkScheduleDTO("Aaron Baker","435628",LocalDate.parse("2023-09-04",
    		   DateTimeFormatter.ofPattern(DATE_PATTERN)),"Monday","Working Day",8,"08:30:00Z",
    		   "17:00:00Z","Day Shift"));
       
       WorkSchedules.add(new WorkScheduleDTO("Helen Ward","473742",LocalDate.parse("2023-09-04",
    		   DateTimeFormatter.ofPattern(DATE_PATTERN)),"Monday","Working Day",8,"17:30:00Z",
    		   "02:00:00Z","Night Shift"));
       
       WorkSchedules.add(new WorkScheduleDTO("Maria Newman", "837483",LocalDate.parse("2023-09-04",
    		   DateTimeFormatter.ofPattern(DATE_PATTERN)),"Monday","Working Day",8,"08:30:00Z",
    		   "17:00:00Z","Day Shift"));
       
       WorkSchedules.add(new WorkScheduleDTO("Shirley Booth", "237867",LocalDate.parse("2023-09-04",
    		   DateTimeFormatter.ofPattern(DATE_PATTERN)),"Monday","Working Day",8,"08:30:00Z",
    		   "17:00:00Z","Day Shift"));
       
       WorkSchedules.add(new WorkScheduleDTO("Michael Harwood", "237865",LocalDate.parse("2023-09-04",
    		   DateTimeFormatter.ofPattern(DATE_PATTERN)),"Monday","Working Day",8,"08:30:00Z",
    		   "17:00:00Z","Day Shift"));
       
       WorkSchedules.add(new WorkScheduleDTO("Alecia Moore", "237866",LocalDate.parse("2023-09-04",
    		   DateTimeFormatter.ofPattern(DATE_PATTERN)),"Monday","Working Day",8,"08:30:00Z",
    		   "17:00:00Z","Day Shift"));
       
       WorkSchedules.add(new WorkScheduleDTO("Jean Scott", "237870",LocalDate.parse("2023-09-04",
    		   DateTimeFormatter.ofPattern(DATE_PATTERN)),"Monday","Working Day",8,"08:30:00Z",
    		   "17:00:00Z","Day Shift"));
       
       
       
       WorkSchedules.add(new WorkScheduleDTO("Aaron Baker","435628",LocalDate.parse("2023-09-05",
    		   DateTimeFormatter.ofPattern(DATE_PATTERN)),"Tuesday","Working Day",8,"08:30:00Z",
    		   "17:00:00Z","Day Shift"));
       
       WorkSchedules.add(new WorkScheduleDTO("Helen Ward","473742",LocalDate.parse("2023-09-05",
    		   DateTimeFormatter.ofPattern(DATE_PATTERN)),"Tuesday","Working Day",8,"17:30:00Z",
    		   "02:00:00Z","Night Shift"));
       
       WorkSchedules.add(new WorkScheduleDTO("Maria Newman", "837483",LocalDate.parse("2023-09-05",
    		   DateTimeFormatter.ofPattern(DATE_PATTERN)),"Tuesday","Working Day",8,"08:30:00Z",
    		   "17:00:00Z","Day Shift"));
       
       WorkSchedules.add(new WorkScheduleDTO("Shirley Booth", "237867",LocalDate.parse("2023-09-05",
    		   DateTimeFormatter.ofPattern(DATE_PATTERN)),"Tuesday","Working Day",8,"08:30:00Z",
    		   "17:00:00Z","Day Shift"));
       
       WorkSchedules.add(new WorkScheduleDTO("Michael Harwood", "237865",LocalDate.parse("2023-09-05",
    		   DateTimeFormatter.ofPattern(DATE_PATTERN)),"Tuesday","Working Day",8,"08:30:00Z",
    		   "17:00:00Z","Day Shift"));
       
       WorkSchedules.add(new WorkScheduleDTO("Alecia Moore", "237866",LocalDate.parse("2023-09-05",
    		   DateTimeFormatter.ofPattern(DATE_PATTERN)),"Tuesday","Working Day",8,"08:30:00Z",
    		   "17:00:00Z","Day Shift"));
       
       WorkSchedules.add(new WorkScheduleDTO("Jean Scott", "237870",LocalDate.parse("2023-09-05",
    		   DateTimeFormatter.ofPattern(DATE_PATTERN)),"Tuesday","Working Day",8,"08:30:00Z",
    		   "17:00:00Z","Day Shift"));
       
       
       WorkSchedules.add(new WorkScheduleDTO("Aaron Baker","435628",LocalDate.parse("2023-09-06",
    		   DateTimeFormatter.ofPattern(DATE_PATTERN)),"Wednesday","Non-Working Day",0,"-",
    		   "-","-"));
       WorkSchedules.add(new WorkScheduleDTO("Helen Ward","473742",LocalDate.parse("2023-09-06",
    		   DateTimeFormatter.ofPattern(DATE_PATTERN)),"Wednesday","Working Day",8,"17:30:00Z",
    		   "02:00:00Z","Night Shift"));
       WorkSchedules.add(new WorkScheduleDTO("Maria Newman", "837483",LocalDate.parse("2023-09-06",
    		   DateTimeFormatter.ofPattern(DATE_PATTERN)),"Wednesday","Working Day",8,"08:30:00Z",
    		   "17:00:00Z","Day Shift"));
       WorkSchedules.add(new WorkScheduleDTO("Shirley Booth", "237867",LocalDate.parse("2023-09-06",
    		   DateTimeFormatter.ofPattern(DATE_PATTERN)),"Wednesday","Working Day",8,"08:30:00Z",
    		   "17:00:00Z","Day Shift"));
       WorkSchedules.add(new WorkScheduleDTO("Michael Harwood", "237865",LocalDate.parse("2023-09-06",
    		   DateTimeFormatter.ofPattern(DATE_PATTERN)),"Wednesday","Working Day",8,"08:30:00Z",
    		   "17:00:00Z","Day Shift"));
       WorkSchedules.add(new WorkScheduleDTO("Alecia Moore", "237866",LocalDate.parse("2023-09-06",
    		   DateTimeFormatter.ofPattern(DATE_PATTERN)),"Wednesday","Working Day",8,"08:30:00Z",
    		   "17:00:00Z","Day Shift"));
       WorkSchedules.add(new WorkScheduleDTO("Jean Scott", "237870",LocalDate.parse("2023-09-06",
    		   DateTimeFormatter.ofPattern(DATE_PATTERN)),"Wednesday","Working Day",8,"08:30:00Z",
    		   "17:00:00Z","Day Shift"));
       
       
       
       WorkSchedules.add(new WorkScheduleDTO("Aaron Baker","435628",LocalDate.parse("2023-09-07",
    		   DateTimeFormatter.ofPattern(DATE_PATTERN)),"Thursday","Non-Working Day",0,"-",
    		   "-","-"));
       WorkSchedules.add(new WorkScheduleDTO("Helen Ward","473742",LocalDate.parse("2023-09-07",
    		   DateTimeFormatter.ofPattern(DATE_PATTERN)),"Thursday","Working Day",8,"08:30:00Z",
    		   "17:00:00Z","Day Shift"));
       WorkSchedules.add(new WorkScheduleDTO("Maria Newman", "837483",LocalDate.parse("2023-09-07",
    		   DateTimeFormatter.ofPattern(DATE_PATTERN)),"Thursday","Non-Working Day",0,"-",
    		   "-","-"));
       WorkSchedules.add(new WorkScheduleDTO("Shirley Booth", "237867",LocalDate.parse("2023-09-07",
    		   DateTimeFormatter.ofPattern(DATE_PATTERN)),"Thursday","Working Day",8,"17:30:00Z",
    		   "02:00:00Z","Day Shift"));
       WorkSchedules.add(new WorkScheduleDTO("Michael Harwood", "237865",LocalDate.parse("2023-09-07",
    		   DateTimeFormatter.ofPattern(DATE_PATTERN)),"Thursday","Working Day",8,"17:30:00Z",
    		   "02:00:00Z","Day Shift"));
       WorkSchedules.add(new WorkScheduleDTO("Alecia Moore", "237866",LocalDate.parse("2023-09-07",
    		   DateTimeFormatter.ofPattern(DATE_PATTERN)),"Thursday","Working Day",8,"17:30:00Z",
    		   "02:00:00Z","Day Shift"));
       WorkSchedules.add(new WorkScheduleDTO("Jean Scott", "237870",LocalDate.parse("2023-09-07",
    		   DateTimeFormatter.ofPattern(DATE_PATTERN)),"Thursday","Working Day",8,"17:30:00Z",
    		   "02:00:00Z","Day Shift"));
       
       
       
       WorkSchedules.add(new WorkScheduleDTO("Aaron Baker","435628",LocalDate.parse("2023-09-08",
    		   DateTimeFormatter.ofPattern(DATE_PATTERN)),"Friday","Non-Working Day",0,"-",
    		   "-","-"));
       WorkSchedules.add(new WorkScheduleDTO("Helen Ward","473742",LocalDate.parse("2023-09-08",
    		   DateTimeFormatter.ofPattern(DATE_PATTERN)),"Friday","Working Day",8,"08:30:00Z",
    		   "17:00:00Z","Day Shift"));
       WorkSchedules.add(new WorkScheduleDTO("Maria Newman", "837483",LocalDate.parse("2023-09-08",
    		   DateTimeFormatter.ofPattern(DATE_PATTERN)),"Friday","Non-Working Day",0,"-",
    		   "-","-"));
       WorkSchedules.add(new WorkScheduleDTO("Shirley Booth", "237867",LocalDate.parse("2023-09-08",
    		   DateTimeFormatter.ofPattern(DATE_PATTERN)),"Friday","Working Day",8,"08:30:00Z",
    		   "17:00:00Z","Day Shift"));
       WorkSchedules.add(new WorkScheduleDTO("Michael Harwood", "237865",LocalDate.parse("2023-09-08",
    		   DateTimeFormatter.ofPattern(DATE_PATTERN)),"Friday","Working Day",8,"08:30:00Z",
    		   "17:00:00Z","Day Shift"));
       WorkSchedules.add(new WorkScheduleDTO("Alecia Moore", "237866",LocalDate.parse("2023-09-08",
    		   DateTimeFormatter.ofPattern(DATE_PATTERN)),"Friday","Working Day",8,"08:30:00Z",
    		   "17:00:00Z","Day Shift"));
       WorkSchedules.add(new WorkScheduleDTO("Jean Scott", "237870",LocalDate.parse("2023-09-08",
    		   DateTimeFormatter.ofPattern(DATE_PATTERN)),"Friday","Working Day",8,"08:30:00Z",
    		   "17:00:00Z","Day Shift"));
       
       
       WorkSchedules.add(new WorkScheduleDTO("Aaron Baker","435628",LocalDate.parse("2023-09-09",
    		   DateTimeFormatter.ofPattern(DATE_PATTERN)),"Saturday","Non-Working Day",0,"-","-","-"));
       
       WorkSchedules.add(new WorkScheduleDTO("Helen Ward", "473742",LocalDate.parse("2023-09-09",
    		   DateTimeFormatter.ofPattern(DATE_PATTERN)),"Saturday","Non-Working Day",0,"-","-","-"));
       
       WorkSchedules.add(new WorkScheduleDTO("Maria Newman", "837483",LocalDate.parse("2023-09-09",
    		   DateTimeFormatter.ofPattern(DATE_PATTERN)),"Saturday","Non-Working Day",0,"-","-","-"));
       
       WorkSchedules.add(new WorkScheduleDTO("Shirley Booth", "237867",LocalDate.parse("2023-09-09",
    		   DateTimeFormatter.ofPattern(DATE_PATTERN)),"Saturday","Non-Working Day",0,"-","-","-"));
       
       WorkSchedules.add(new WorkScheduleDTO("Michael Harwood", "237865",LocalDate.parse("2023-09-09",
    		   DateTimeFormatter.ofPattern(DATE_PATTERN)),"Saturday","Non-Working Day",0,"-","-","-"));
       
       WorkSchedules.add(new WorkScheduleDTO("Alecia Moore", "237866",LocalDate.parse("2023-09-09",
    		   DateTimeFormatter.ofPattern(DATE_PATTERN)),"Saturday","Non-Working Day",0,"-","-","-"));
       
       WorkSchedules.add(new WorkScheduleDTO("Jean Scott", "237870",LocalDate.parse("2023-09-09",
    		   DateTimeFormatter.ofPattern(DATE_PATTERN)),"Saturday","Non-Working Day",0,"-","-","-"));
       
       
       
       
       WorkSchedules.add(new WorkScheduleDTO("Aaron Baker","435628",LocalDate.parse("2023-09-10",
    		   DateTimeFormatter.ofPattern(DATE_PATTERN)),"Sunday","Non-Working Day",0,"-","-","-"));
       
       WorkSchedules.add(new WorkScheduleDTO("Helen Ward", "473742",LocalDate.parse("2023-09-10",
    		   DateTimeFormatter.ofPattern(DATE_PATTERN)),"Sunday","Non-Working Day",0,"-","-","-"));
       
       WorkSchedules.add(new WorkScheduleDTO("Maria Newman", "837483",LocalDate.parse("2023-09-10",
    		   DateTimeFormatter.ofPattern(DATE_PATTERN)),"Sunday","Non-Working Day",0,"-","-","-"));
       
       WorkSchedules.add(new WorkScheduleDTO("Shirley Booth", "237867",LocalDate.parse("2023-09-10",
    		   DateTimeFormatter.ofPattern(DATE_PATTERN)),"Sunday","Non-Working Day",0,"-","-","-"));
       
       WorkSchedules.add(new WorkScheduleDTO("Michael Harwood", "237865",LocalDate.parse("2023-09-10",
    		   DateTimeFormatter.ofPattern(DATE_PATTERN)),"Sunday","Non-Working Day",0,"-","-","-"));
       
       WorkSchedules.add(new WorkScheduleDTO("Alecia Moore", "237866",LocalDate.parse("2023-09-10",
    		   DateTimeFormatter.ofPattern(DATE_PATTERN)),"Sunday","Non-Working Day",0,"-","-","-"));
       
       WorkSchedules.add(new WorkScheduleDTO("Jean Scott", "237870",LocalDate.parse("2023-09-10",
    		   DateTimeFormatter.ofPattern(DATE_PATTERN)),"Sunday","Non-Working Day",0,"-","-","-"));
       
       
       
       WorkSchedules.add(new WorkScheduleDTO("Aaron Baker","435628",LocalDate.parse("2023-09-11",
    		   DateTimeFormatter.ofPattern(DATE_PATTERN)),"Monday","Non-Working Day",0,"-",
    		   "-","-"));
       
       WorkSchedules.add(new WorkScheduleDTO("Helen Ward","473742",LocalDate.parse("2023-09-11",
    		   DateTimeFormatter.ofPattern(DATE_PATTERN)),"Monday","Working Day",8,"17:30:00Z",
    		   "02:00:00Z","Night Shift"));
       
       WorkSchedules.add(new WorkScheduleDTO("Maria Newman", "837483",LocalDate.parse("2023-09-11",
    		   DateTimeFormatter.ofPattern(DATE_PATTERN)),"Monday","Non-Working Day",0,"-",
    		   "-","-"));
       WorkSchedules.add(new WorkScheduleDTO("Shirley Booth", "237867",LocalDate.parse("2023-09-11",
    		   DateTimeFormatter.ofPattern(DATE_PATTERN)),"Monday","Working Day",8,"08:30:00Z",
    		   "17:00:00Z","Day Shift"));
       WorkSchedules.add(new WorkScheduleDTO("Michael Harwood", "237865",LocalDate.parse("2023-09-11",
    		   DateTimeFormatter.ofPattern(DATE_PATTERN)),"Monday","Working Day",8,"08:30:00Z",
    		   "17:00:00Z","Day Shift"));
       WorkSchedules.add(new WorkScheduleDTO("Alecia Moore", "237866",LocalDate.parse("2023-09-11",
    		   DateTimeFormatter.ofPattern(DATE_PATTERN)),"Monday","Working Day",8,"08:30:00Z",
    		   "17:00:00Z","Day Shift"));
       WorkSchedules.add(new WorkScheduleDTO("Jean Scott", "237870",LocalDate.parse("2023-09-11",
    		   DateTimeFormatter.ofPattern(DATE_PATTERN)),"Monday","Working Day",8,"08:30:00Z",
    		   "17:00:00Z","Day Shift"));
       
       
       
       WorkSchedules.add(new WorkScheduleDTO("Aaron Baker","435628",LocalDate.parse("2023-09-12",
    		   DateTimeFormatter.ofPattern(DATE_PATTERN)),"Tuesday","Non-Working Day",0,"-",
    		   "-","-"));
       WorkSchedules.add(new WorkScheduleDTO("Helen Ward","473742",LocalDate.parse("2023-09-12",
    		   DateTimeFormatter.ofPattern(DATE_PATTERN)),"Tuesday","Working Day",8,"17:30:00Z",
    		   "02:00:00Z","Night Shift"));
       WorkSchedules.add(new WorkScheduleDTO("Maria Newman", "837483",LocalDate.parse("2023-09-12",
    		   DateTimeFormatter.ofPattern(DATE_PATTERN)),"Tuesday","Non-Working Day",0,"-",
    		   "-","-"));
       WorkSchedules.add(new WorkScheduleDTO("Shirley Booth", "237867",LocalDate.parse("2023-09-12",
    		   DateTimeFormatter.ofPattern(DATE_PATTERN)),"Tuesday","Working Day",8,"08:30:00Z",
    		   "17:00:00Z","Day Shift"));
       WorkSchedules.add(new WorkScheduleDTO("Michael Harwood", "237865",LocalDate.parse("2023-09-12",
    		   DateTimeFormatter.ofPattern(DATE_PATTERN)),"Tuesday","Working Day",8,"08:30:00Z",
    		   "17:00:00Z","Day Shift"));
       WorkSchedules.add(new WorkScheduleDTO("Alecia Moore", "237866",LocalDate.parse("2023-09-12",
    		   DateTimeFormatter.ofPattern(DATE_PATTERN)),"Tuesday","Working Day",8,"08:30:00Z",
    		   "17:00:00Z","Day Shift"));
       WorkSchedules.add(new WorkScheduleDTO("Jean Scott", "237870",LocalDate.parse("2023-09-12",
    		   DateTimeFormatter.ofPattern(DATE_PATTERN)),"Tuesday","Working Day",8,"08:30:00Z",
    		   "17:00:00Z","Day Shift"));
       
       
       WorkSchedules.add(new WorkScheduleDTO("Aaron Baker","435628",LocalDate.parse("2023-09-13",
    		   DateTimeFormatter.ofPattern(DATE_PATTERN)),"Wednesday","Non-Working Day",0,"-",
    		   "-","-"));
       WorkSchedules.add(new WorkScheduleDTO("Helen Ward","473742",LocalDate.parse("2023-09-13",
    		   DateTimeFormatter.ofPattern(DATE_PATTERN)),"Wednesday","Working Day",8,"17:30:00Z",
    		   "02:00:00Z","Night Shift"));
       WorkSchedules.add(new WorkScheduleDTO("Maria Newman", "837483",LocalDate.parse("2023-09-13",
    		   DateTimeFormatter.ofPattern(DATE_PATTERN)),"Wednesday","Non-Working Day",0,"-",
    		   "-","-"));
       WorkSchedules.add(new WorkScheduleDTO("Shirley Booth", "237867",LocalDate.parse("2023-09-13",
    		   DateTimeFormatter.ofPattern(DATE_PATTERN)),"Wednesday","Working Day",8,"08:30:00Z",
    		   "17:00:00Z","Day Shift"));
       WorkSchedules.add(new WorkScheduleDTO("Michael Harwood", "237865",LocalDate.parse("2023-09-13",
    		   DateTimeFormatter.ofPattern(DATE_PATTERN)),"Wednesday","Working Day",8,"08:30:00Z",
    		   "17:00:00Z","Day Shift"));
       WorkSchedules.add(new WorkScheduleDTO("Alecia Moore", "237866",LocalDate.parse("2023-09-13",
    		   DateTimeFormatter.ofPattern(DATE_PATTERN)),"Wednesday","Working Day",8,"08:30:00Z",
    		   "17:00:00Z","Day Shift"));
       WorkSchedules.add(new WorkScheduleDTO("Jean Scott", "237870",LocalDate.parse("2023-09-13",
    		   DateTimeFormatter.ofPattern(DATE_PATTERN)),"Wednesday","Working Day",8,"08:30:00Z",
    		   "17:00:00Z","Day Shift"));
       
       
       
       WorkSchedules.add(new WorkScheduleDTO("Aaron Baker","435628",LocalDate.parse("2023-09-14",
    		   DateTimeFormatter.ofPattern(DATE_PATTERN)),"Thursday","Non-Working Day",0,"-",
    		   "-","-"));
       WorkSchedules.add(new WorkScheduleDTO("Helen Ward","473742",LocalDate.parse("2023-09-14",
    		   DateTimeFormatter.ofPattern(DATE_PATTERN)),"Thursday","Working Day",8,"08:30:00Z",
    		   "17:00:00Z","Day Shift"));
       WorkSchedules.add(new WorkScheduleDTO("Maria Newman", "837483",LocalDate.parse("2023-09-14",
    		   DateTimeFormatter.ofPattern(DATE_PATTERN)),"Thursday","Working Day",8,"17:30:00Z",
    		   "02:00:00Z","Day Shift"));
       WorkSchedules.add(new WorkScheduleDTO("Shirley Booth", "237867",LocalDate.parse("2023-09-14",
    		   DateTimeFormatter.ofPattern(DATE_PATTERN)),"Thursday","Working Day",8,"17:30:00Z",
    		   "02:00:00Z","Day Shift"));
       WorkSchedules.add(new WorkScheduleDTO("Michael Harwood", "237865",LocalDate.parse("2023-09-14",
    		   DateTimeFormatter.ofPattern(DATE_PATTERN)),"Thursday","Working Day",8,"17:30:00Z",
    		   "02:00:00Z","Day Shift"));
       WorkSchedules.add(new WorkScheduleDTO("Alecia Moore", "237866",LocalDate.parse("2023-09-14",
    		   DateTimeFormatter.ofPattern(DATE_PATTERN)),"Thursday","Working Day",8,"17:30:00Z",
    		   "02:00:00Z","Day Shift"));
       WorkSchedules.add(new WorkScheduleDTO("Jean Scott", "237870",LocalDate.parse("2023-09-14",
    		   DateTimeFormatter.ofPattern(DATE_PATTERN)),"Thursday","Working Day",8,"17:30:00Z",
    		   "02:00:00Z","Day Shift"));
       
       
       
       WorkSchedules.add(new WorkScheduleDTO("Aaron Baker","435628",LocalDate.parse("2023-09-15",
    		   DateTimeFormatter.ofPattern(DATE_PATTERN)),"Friday","Non-Working Day",0,"-",
    		   "-","-"));
       WorkSchedules.add(new WorkScheduleDTO("Helen Ward","473742",LocalDate.parse("2023-09-15",
    		   DateTimeFormatter.ofPattern(DATE_PATTERN)),"Friday","Working Day",8,"08:30:00Z",
    		   "17:00:00Z","Day Shift"));
       WorkSchedules.add(new WorkScheduleDTO("Maria Newman", "837483",LocalDate.parse("2023-09-15",
    		   DateTimeFormatter.ofPattern(DATE_PATTERN)),"Friday","Working Day",8,"08:30:00Z",
    		   "17:00:00Z","Day Shift"));
       WorkSchedules.add(new WorkScheduleDTO("Shirley Booth", "237867",LocalDate.parse("2023-09-15",
    		   DateTimeFormatter.ofPattern(DATE_PATTERN)),"Friday","Working Day",8,"08:30:00Z",
    		   "17:00:00Z","Day Shift"));
       WorkSchedules.add(new WorkScheduleDTO("Michael Harwood", "237865",LocalDate.parse("2023-09-15",
    		   DateTimeFormatter.ofPattern(DATE_PATTERN)),"Friday","Working Day",8,"08:30:00Z",
    		   "17:00:00Z","Day Shift"));
       WorkSchedules.add(new WorkScheduleDTO("Alecia Moore", "237866",LocalDate.parse("2023-09-15",
    		   DateTimeFormatter.ofPattern(DATE_PATTERN)),"Friday","Working Day",8,"08:30:00Z",
    		   "17:00:00Z","Day Shift"));
       WorkSchedules.add(new WorkScheduleDTO("Jean Scott", "237870",LocalDate.parse("2023-09-15",
    		   DateTimeFormatter.ofPattern(DATE_PATTERN)),"Friday","Working Day",8,"08:30:00Z",
    		   "17:00:00Z","Day Shift"));
       
       
       WorkSchedules.add(new WorkScheduleDTO("Aaron Baker","435628",LocalDate.parse("2023-09-16",
    		   DateTimeFormatter.ofPattern(DATE_PATTERN)),"Saturday","Non-Working Day",0,"-","-","-"));
       WorkSchedules.add(new WorkScheduleDTO("Helen Ward", "473742",LocalDate.parse("2023-09-16",
    		   DateTimeFormatter.ofPattern(DATE_PATTERN)),"Saturday","Non-Working Day",0,"-","-","-"));
       
       WorkSchedules.add(new WorkScheduleDTO("Maria Newman", "837483",LocalDate.parse("2023-09-16",
    		   DateTimeFormatter.ofPattern(DATE_PATTERN)),"Saturday","Non-Working Day",0,"-","-","-"));
       
       WorkSchedules.add(new WorkScheduleDTO("Shirley Booth", "237867",LocalDate.parse("2023-09-16",
    		   DateTimeFormatter.ofPattern(DATE_PATTERN)),"Saturday","Non-Working Day",0,"-","-","-"));
       
       WorkSchedules.add(new WorkScheduleDTO("Michael Harwood", "237865",LocalDate.parse("2023-09-16",
    		   DateTimeFormatter.ofPattern(DATE_PATTERN)),"Saturday","Non-Working Day",0,"-","-","-"));
       
       WorkSchedules.add(new WorkScheduleDTO("Alecia Moore", "237866",LocalDate.parse("2023-09-16",
    		   DateTimeFormatter.ofPattern(DATE_PATTERN)),"Saturday","Non-Working Day",0,"-","-","-"));
       
       WorkSchedules.add(new WorkScheduleDTO("Jean Scott", "237870",LocalDate.parse("2023-09-16",
    		   DateTimeFormatter.ofPattern(DATE_PATTERN)),"Saturday","Non-Working Day",0,"-","-","-"));
       
       
       
       
       WorkSchedules.add(new WorkScheduleDTO("Helen Ward", "473742",LocalDate.parse("2023-09-17",
    		   DateTimeFormatter.ofPattern(DATE_PATTERN)),"Sunday","Non-Working Day",0,"-","-","-"));
       
       WorkSchedules.add(new WorkScheduleDTO("Maria Newman", "837483",LocalDate.parse("2023-09-17",
    		   DateTimeFormatter.ofPattern(DATE_PATTERN)),"Sunday","Non-Working Day",0,"-","-","-"));
       
       WorkSchedules.add(new WorkScheduleDTO("Shirley Booth", "237867",LocalDate.parse("2023-09-17",
    		   DateTimeFormatter.ofPattern(DATE_PATTERN)),"Sunday","Non-Working Day",0,"-","-","-"));
       
       WorkSchedules.add(new WorkScheduleDTO("Michael Harwood", "237865",LocalDate.parse("2023-09-17",
    		   DateTimeFormatter.ofPattern(DATE_PATTERN)),"Sunday","Non-Working Day",0,"-","-","-"));
       
       WorkSchedules.add(new WorkScheduleDTO("Alecia Moore", "237866",LocalDate.parse("2023-09-17",
    		   DateTimeFormatter.ofPattern(DATE_PATTERN)),"Sunday","Non-Working Day",0,"-","-","-"));
       
       WorkSchedules.add(new WorkScheduleDTO("Jean Scott", "237870",LocalDate.parse("2023-09-17",
    		   DateTimeFormatter.ofPattern(DATE_PATTERN)),"Sunday","Non-Working Day",0,"-","-","-"));
       
       
       
       WorkSchedules.add(new WorkScheduleDTO("Helen Ward","473742",LocalDate.parse("2023-09-18",
    		   DateTimeFormatter.ofPattern(DATE_PATTERN)),"Monday","Working Day",8,"17:30:00Z",
    		   "02:00:00Z","Night Shift"));
       
       WorkSchedules.add(new WorkScheduleDTO("Maria Newman", "837483",LocalDate.parse("2023-09-18",
    		   DateTimeFormatter.ofPattern(DATE_PATTERN)),"Monday","Working Day",8,"08:30:00Z",
    		   "17:00:00Z","Day Shift"));
       WorkSchedules.add(new WorkScheduleDTO("Shirley Booth", "237867",LocalDate.parse("2023-09-18",
    		   DateTimeFormatter.ofPattern(DATE_PATTERN)),"Monday","Working Day",8,"08:30:00Z",
    		   "17:00:00Z","Day Shift"));
       WorkSchedules.add(new WorkScheduleDTO("Michael Harwood", "237865",LocalDate.parse("2023-09-18",
    		   DateTimeFormatter.ofPattern(DATE_PATTERN)),"Monday","Working Day",8,"08:30:00Z",
    		   "17:00:00Z","Day Shift"));
       WorkSchedules.add(new WorkScheduleDTO("Alecia Moore", "237866",LocalDate.parse("2023-09-18",
    		   DateTimeFormatter.ofPattern(DATE_PATTERN)),"Monday","Working Day",8,"08:30:00Z",
    		   "17:00:00Z","Day Shift"));
       WorkSchedules.add(new WorkScheduleDTO("Jean Scott", "237870",LocalDate.parse("2023-09-18",
    		   DateTimeFormatter.ofPattern(DATE_PATTERN)),"Monday","Working Day",8,"08:30:00Z",
    		   "17:00:00Z","Day Shift"));
       
       
       
       WorkSchedules.add(new WorkScheduleDTO("Helen Ward","473742",LocalDate.parse("2023-09-19",
    		   DateTimeFormatter.ofPattern(DATE_PATTERN)),"Tuesday","Working Day",8,"17:30:00Z",
    		   "02:00:00Z","Night Shift"));
       WorkSchedules.add(new WorkScheduleDTO("Maria Newman", "837483",LocalDate.parse("2023-09-19",
    		   DateTimeFormatter.ofPattern(DATE_PATTERN)),"Tuesday","Working Day",8,"08:30:00Z",
    		   "17:00:00Z","Day Shift"));
       WorkSchedules.add(new WorkScheduleDTO("Shirley Booth", "237867",LocalDate.parse("2023-09-19",
    		   DateTimeFormatter.ofPattern(DATE_PATTERN)),"Tuesday","Working Day",8,"08:30:00Z",
    		   "17:00:00Z","Day Shift"));
       WorkSchedules.add(new WorkScheduleDTO("Michael Harwood", "237865",LocalDate.parse("2023-09-19",
    		   DateTimeFormatter.ofPattern(DATE_PATTERN)),"Tuesday","Working Day",8,"08:30:00Z",
    		   "17:00:00Z","Day Shift"));
       WorkSchedules.add(new WorkScheduleDTO("Alecia Moore", "237866",LocalDate.parse("2023-09-19",
    		   DateTimeFormatter.ofPattern(DATE_PATTERN)),"Tuesday","Working Day",8,"08:30:00Z",
    		   "17:00:00Z","Day Shift"));
       WorkSchedules.add(new WorkScheduleDTO("Jean Scott", "237870",LocalDate.parse("2023-09-19",
    		   DateTimeFormatter.ofPattern(DATE_PATTERN)),"Tuesday","Working Day",8,"08:30:00Z",
    		   "17:00:00Z","Day Shift"));
       
       
       WorkSchedules.add(new WorkScheduleDTO("Helen Ward","473742",LocalDate.parse("2023-09-20",
    		   DateTimeFormatter.ofPattern(DATE_PATTERN)),"Wednesday","Working Day",8,"17:30:00Z",
    		   "02:00:00Z","Night Shift"));
       WorkSchedules.add(new WorkScheduleDTO("Maria Newman", "837483",LocalDate.parse("2023-09-20",
    		   DateTimeFormatter.ofPattern(DATE_PATTERN)),"Wednesday","Working Day",8,"08:30:00Z",
    		   "17:00:00Z","Day Shift"));
       WorkSchedules.add(new WorkScheduleDTO("Shirley Booth", "237867",LocalDate.parse("2023-09-20",
    		   DateTimeFormatter.ofPattern(DATE_PATTERN)),"Wednesday","Working Day",8,"08:30:00Z",
    		   "17:00:00Z","Day Shift"));
       WorkSchedules.add(new WorkScheduleDTO("Michael Harwood", "237865",LocalDate.parse("2023-09-20",
    		   DateTimeFormatter.ofPattern(DATE_PATTERN)),"Wednesday","Working Day",8,"08:30:00Z",
    		   "17:00:00Z","Day Shift"));
       WorkSchedules.add(new WorkScheduleDTO("Alecia Moore", "237866",LocalDate.parse("2023-09-20",
    		   DateTimeFormatter.ofPattern(DATE_PATTERN)),"Wednesday","Working Day",8,"08:30:00Z",
    		   "17:00:00Z","Day Shift"));
       WorkSchedules.add(new WorkScheduleDTO("Jean Scott", "237870",LocalDate.parse("2023-09-20",
    		   DateTimeFormatter.ofPattern(DATE_PATTERN)),"Wednesday","Working Day",8,"08:30:00Z",
    		   "17:00:00Z","Day Shift"));
       
       
       
       WorkSchedules.add(new WorkScheduleDTO("Helen Ward","473742",LocalDate.parse("2023-09-21",
    		   DateTimeFormatter.ofPattern(DATE_PATTERN)),"Thursday","Working Day",8,"08:30:00Z",
    		   "17:00:00Z","Day Shift"));
       WorkSchedules.add(new WorkScheduleDTO("Maria Newman", "837483",LocalDate.parse("2023-09-21",
    		   DateTimeFormatter.ofPattern(DATE_PATTERN)),"Thursday","Working Day",8,"17:30:00Z",
    		   "02:00:00Z","Day Shift"));
       WorkSchedules.add(new WorkScheduleDTO("Shirley Booth", "237867",LocalDate.parse("2023-09-21",
    		   DateTimeFormatter.ofPattern(DATE_PATTERN)),"Thursday","Working Day",8,"17:30:00Z",
    		   "02:00:00Z","Day Shift"));
       WorkSchedules.add(new WorkScheduleDTO("Michael Harwood", "237865",LocalDate.parse("2023-09-21",
    		   DateTimeFormatter.ofPattern(DATE_PATTERN)),"Thursday","Working Day",8,"17:30:00Z",
    		   "02:00:00Z","Day Shift"));
       WorkSchedules.add(new WorkScheduleDTO("Alecia Moore", "237866",LocalDate.parse("2023-09-21",
    		   DateTimeFormatter.ofPattern(DATE_PATTERN)),"Thursday","Working Day",8,"17:30:00Z",
    		   "02:00:00Z","Day Shift"));
       WorkSchedules.add(new WorkScheduleDTO("Jean Scott", "237870",LocalDate.parse("2023-09-21",
    		   DateTimeFormatter.ofPattern(DATE_PATTERN)),"Thursday","Working Day",8,"17:30:00Z",
    		   "02:00:00Z","Day Shift"));
       
       
       
       WorkSchedules.add(new WorkScheduleDTO("Helen Ward","473742",LocalDate.parse("2023-09-22",
    		   DateTimeFormatter.ofPattern(DATE_PATTERN)),"Friday","Working Day",8,"08:30:00Z",
    		   "17:00:00Z","Day Shift"));
       WorkSchedules.add(new WorkScheduleDTO("Maria Newman", "837483",LocalDate.parse("2023-09-22",
    		   DateTimeFormatter.ofPattern(DATE_PATTERN)),"Friday","Working Day",8,"08:30:00Z",
    		   "17:00:00Z","Day Shift"));
       WorkSchedules.add(new WorkScheduleDTO("Shirley Booth", "237867",LocalDate.parse("2023-09-22",
    		   DateTimeFormatter.ofPattern(DATE_PATTERN)),"Friday","Working Day",8,"08:30:00Z",
    		   "17:00:00Z","Day Shift"));
       WorkSchedules.add(new WorkScheduleDTO("Michael Harwood", "237865",LocalDate.parse("2023-09-22",
    		   DateTimeFormatter.ofPattern(DATE_PATTERN)),"Friday","Working Day",8,"08:30:00Z",
    		   "17:00:00Z","Day Shift"));
       WorkSchedules.add(new WorkScheduleDTO("Alecia Moore", "237866",LocalDate.parse("2023-09-22",
    		   DateTimeFormatter.ofPattern(DATE_PATTERN)),"Friday","Working Day",8,"08:30:00Z",
    		   "17:00:00Z","Day Shift"));
       WorkSchedules.add(new WorkScheduleDTO("Jean Scott", "237870",LocalDate.parse("2023-09-22",
    		   DateTimeFormatter.ofPattern(DATE_PATTERN)),"Friday","Working Day",8,"08:30:00Z",
    		   "17:00:00Z","Day Shift"));
       
       WorkSchedules.add(new WorkScheduleDTO("Helen Ward", "473742",LocalDate.parse("2023-09-23",
    		   DateTimeFormatter.ofPattern(DATE_PATTERN)),"Saturday","Non-Working Day",0,"-","-","-"));
       
       WorkSchedules.add(new WorkScheduleDTO("Maria Newman", "837483",LocalDate.parse("2023-09-23",
    		   DateTimeFormatter.ofPattern(DATE_PATTERN)),"Saturday","Non-Working Day",0,"-","-","-"));
       
       WorkSchedules.add(new WorkScheduleDTO("Shirley Booth", "237867",LocalDate.parse("2023-09-23",
    		   DateTimeFormatter.ofPattern(DATE_PATTERN)),"Saturday","Non-Working Day",0,"-","-","-"));
       
       WorkSchedules.add(new WorkScheduleDTO("Michael Harwood", "237865",LocalDate.parse("2023-09-23",
    		   DateTimeFormatter.ofPattern(DATE_PATTERN)),"Saturday","Non-Working Day",0,"-","-","-"));
       
       WorkSchedules.add(new WorkScheduleDTO("Alecia Moore", "237866",LocalDate.parse("2023-09-23",
    		   DateTimeFormatter.ofPattern(DATE_PATTERN)),"Saturday","Non-Working Day",0,"-","-","-"));
       
       WorkSchedules.add(new WorkScheduleDTO("Jean Scott", "237870",LocalDate.parse("2023-09-23",
    		   DateTimeFormatter.ofPattern(DATE_PATTERN)),"Saturday","Non-Working Day",0,"-","-","-"));
       
       
       
       
       WorkSchedules.add(new WorkScheduleDTO("Helen Ward", "473742",LocalDate.parse("2023-09-24",
    		   DateTimeFormatter.ofPattern(DATE_PATTERN)),"Sunday","Non-Working Day",0,"-","-","-"));
       
       WorkSchedules.add(new WorkScheduleDTO("Maria Newman", "837483",LocalDate.parse("2023-09-24",
    		   DateTimeFormatter.ofPattern(DATE_PATTERN)),"Sunday","Non-Working Day",0,"-","-","-"));
       
       WorkSchedules.add(new WorkScheduleDTO("Shirley Booth", "237867",LocalDate.parse("2023-09-24",
    		   DateTimeFormatter.ofPattern(DATE_PATTERN)),"Sunday","Non-Working Day",0,"-","-","-"));
       
       WorkSchedules.add(new WorkScheduleDTO("Michael Harwood", "237865",LocalDate.parse("2023-09-24",
    		   DateTimeFormatter.ofPattern(DATE_PATTERN)),"Sunday","Non-Working Day",0,"-","-","-"));
       
       WorkSchedules.add(new WorkScheduleDTO("Alecia Moore", "237866",LocalDate.parse("2023-09-24",
    		   DateTimeFormatter.ofPattern(DATE_PATTERN)),"Sunday","Non-Working Day",0,"-","-","-"));
       
       WorkSchedules.add(new WorkScheduleDTO("Jean Scott", "237870",LocalDate.parse("2023-09-24",
    		   DateTimeFormatter.ofPattern(DATE_PATTERN)),"Sunday","Non-Working Day",0,"-","-","-"));
       
       
       
       WorkSchedules.add(new WorkScheduleDTO("Helen Ward","473742",LocalDate.parse("2023-09-25",
    		   DateTimeFormatter.ofPattern(DATE_PATTERN)),"Monday","Working Day",8,"17:30:00Z",
    		   "02:00:00Z","Night Shift"));
       
       WorkSchedules.add(new WorkScheduleDTO("Maria Newman", "837483",LocalDate.parse("2023-09-25",
    		   DateTimeFormatter.ofPattern(DATE_PATTERN)),"Monday","Working Day",8,"08:30:00Z",
    		   "17:00:00Z","Day Shift"));
       WorkSchedules.add(new WorkScheduleDTO("Shirley Booth", "237867",LocalDate.parse("2023-09-25",
    		   DateTimeFormatter.ofPattern(DATE_PATTERN)),"Monday","Working Day",8,"08:30:00Z",
    		   "17:00:00Z","Day Shift"));
       WorkSchedules.add(new WorkScheduleDTO("Michael Harwood", "237865",LocalDate.parse("2023-09-25",
    		   DateTimeFormatter.ofPattern(DATE_PATTERN)),"Monday","Working Day",8,"08:30:00Z",
    		   "17:00:00Z","Day Shift"));
       WorkSchedules.add(new WorkScheduleDTO("Alecia Moore", "237866",LocalDate.parse("2023-09-25",
    		   DateTimeFormatter.ofPattern(DATE_PATTERN)),"Monday","Working Day",8,"08:30:00Z",
    		   "17:00:00Z","Day Shift"));
       WorkSchedules.add(new WorkScheduleDTO("Jean Scott", "237870",LocalDate.parse("2023-09-25",
    		   DateTimeFormatter.ofPattern(DATE_PATTERN)),"Monday","Working Day",8,"08:30:00Z",
    		   "17:00:00Z","Day Shift"));
       
       
       
       WorkSchedules.add(new WorkScheduleDTO("Helen Ward","473742",LocalDate.parse("2023-09-26",
    		   DateTimeFormatter.ofPattern(DATE_PATTERN)),"Tuesday","Working Day",8,"17:30:00Z",
    		   "02:00:00Z","Night Shift"));
       WorkSchedules.add(new WorkScheduleDTO("Maria Newman", "837483",LocalDate.parse("2023-09-26",
    		   DateTimeFormatter.ofPattern(DATE_PATTERN)),"Tuesday","Working Day",8,"08:30:00Z",
    		   "17:00:00Z","Day Shift"));
       WorkSchedules.add(new WorkScheduleDTO("Shirley Booth", "237867",LocalDate.parse("2023-09-26",
    		   DateTimeFormatter.ofPattern(DATE_PATTERN)),"Tuesday","Working Day",8,"08:30:00Z",
    		   "17:00:00Z","Day Shift"));
       WorkSchedules.add(new WorkScheduleDTO("Michael Harwood", "237865",LocalDate.parse("2023-09-26",
    		   DateTimeFormatter.ofPattern(DATE_PATTERN)),"Tuesday","Working Day",8,"08:30:00Z",
    		   "17:00:00Z","Day Shift"));
       WorkSchedules.add(new WorkScheduleDTO("Alecia Moore", "237866",LocalDate.parse("2023-09-26",
    		   DateTimeFormatter.ofPattern(DATE_PATTERN)),"Tuesday","Non-Working Day",0,"-",
    		   "-","-"));
       WorkSchedules.add(new WorkScheduleDTO("Jean Scott", "237870",LocalDate.parse("2023-09-26",
    		   DateTimeFormatter.ofPattern(DATE_PATTERN)),"Tuesday","Working Day",8,"08:30:00Z",
    		   "17:00:00Z","Day Shift"));
       
       
       WorkSchedules.add(new WorkScheduleDTO("Helen Ward","473742",LocalDate.parse("2023-09-27",
    		   DateTimeFormatter.ofPattern(DATE_PATTERN)),"Wednesday","Working Day",8,"17:30:00Z",
    		   "02:00:00Z","Night Shift"));
       WorkSchedules.add(new WorkScheduleDTO("Maria Newman", "837483",LocalDate.parse("2023-09-27",
    		   DateTimeFormatter.ofPattern(DATE_PATTERN)),"Wednesday","Working Day",8,"08:30:00Z",
    		   "17:00:00Z","Day Shift"));
       WorkSchedules.add(new WorkScheduleDTO("Shirley Booth", "237867",LocalDate.parse("2023-09-27",
    		   DateTimeFormatter.ofPattern(DATE_PATTERN)),"Wednesday","Non-Working Day",0,"-",
    		   "-","-"));
       WorkSchedules.add(new WorkScheduleDTO("Michael Harwood", "237865",LocalDate.parse("2023-09-27",
    		   DateTimeFormatter.ofPattern(DATE_PATTERN)),"Wednesday","Working Day",8,"08:30:00Z",
    		   "17:00:00Z","Day Shift"));
       WorkSchedules.add(new WorkScheduleDTO("Alecia Moore", "237866",LocalDate.parse("2023-09-27",
    		   DateTimeFormatter.ofPattern(DATE_PATTERN)),"Wednesday","Working Day",8,"08:30:00Z",
    		   "17:00:00Z","Day Shift"));
       WorkSchedules.add(new WorkScheduleDTO("Jean Scott", "237870",LocalDate.parse("2023-09-27",
    		   DateTimeFormatter.ofPattern(DATE_PATTERN)),"Wednesday","Working Day",8,"08:30:00Z",
    		   "17:00:00Z","Day Shift"));
       
       
       
       WorkSchedules.add(new WorkScheduleDTO("Helen Ward","473742",LocalDate.parse("2023-09-28",
    		   DateTimeFormatter.ofPattern(DATE_PATTERN)),"Thursday","Working Day",8,"08:30:00Z",
    		   "17:00:00Z","Day Shift"));
       WorkSchedules.add(new WorkScheduleDTO("Maria Newman", "837483",LocalDate.parse("2023-09-28",
    		   DateTimeFormatter.ofPattern(DATE_PATTERN)),"Thursday","Working Day",8,"17:30:00Z",
    		   "02:00:00Z","Day Shift"));
       WorkSchedules.add(new WorkScheduleDTO("Shirley Booth", "237867",LocalDate.parse("2023-09-28",
    		   DateTimeFormatter.ofPattern(DATE_PATTERN)),"Thursday","Working Day",8,"17:30:00Z",
    		   "02:00:00Z","Day Shift"));
       WorkSchedules.add(new WorkScheduleDTO("Michael Harwood", "237865",LocalDate.parse("2023-09-28",
    		   DateTimeFormatter.ofPattern(DATE_PATTERN)),"Thursday","Non-Working Day",0,"-",
    		   "-","-"));
       WorkSchedules.add(new WorkScheduleDTO("Alecia Moore", "237866",LocalDate.parse("2023-09-28",
    		   DateTimeFormatter.ofPattern(DATE_PATTERN)),"Thursday","Working Day",8,"17:30:00Z",
    		   "02:00:00Z","Day Shift"));
       WorkSchedules.add(new WorkScheduleDTO("Jean Scott", "237870",LocalDate.parse("2023-09-28",
    		   DateTimeFormatter.ofPattern(DATE_PATTERN)),"Thursday","Working Day",8,"17:30:00Z",
    		   "02:00:00Z","Day Shift"));
       
       
       
       WorkSchedules.add(new WorkScheduleDTO("Helen Ward","473742",LocalDate.parse("2023-09-29",
    		   DateTimeFormatter.ofPattern(DATE_PATTERN)),"Friday","Working Day",8,"08:30:00Z",
    		   "17:00:00Z","Day Shift"));
       WorkSchedules.add(new WorkScheduleDTO("Maria Newman", "837483",LocalDate.parse("2023-09-29",
    		   DateTimeFormatter.ofPattern(DATE_PATTERN)),"Friday","Working Day",8,"08:30:00Z",
    		   "17:00:00Z","Day Shift"));
       WorkSchedules.add(new WorkScheduleDTO("Shirley Booth", "237867",LocalDate.parse("2023-09-29",
    		   DateTimeFormatter.ofPattern(DATE_PATTERN)),"Friday","Working Day",8,"08:30:00Z",
    		   "17:00:00Z","Day Shift"));
       WorkSchedules.add(new WorkScheduleDTO("Michael Harwood", "237865",LocalDate.parse("2023-09-29",
    		   DateTimeFormatter.ofPattern(DATE_PATTERN)),"Friday","Working Day",8,"08:30:00Z",
    		   "17:00:00Z","Day Shift"));
       WorkSchedules.add(new WorkScheduleDTO("Alecia Moore", "237866",LocalDate.parse("2023-09-29",
    		   DateTimeFormatter.ofPattern(DATE_PATTERN)),"Friday","Working Day",8,"08:30:00Z",
    		   "17:00:00Z","Day Shift"));
       WorkSchedules.add(new WorkScheduleDTO("Jean Scott", "237870",LocalDate.parse("2023-09-29",
    		   DateTimeFormatter.ofPattern(DATE_PATTERN)),"Friday","Working Day",8,"08:30:00Z",
    		   "17:00:00Z","Day Shift"));
       
       
       
       WorkSchedules.add(new WorkScheduleDTO("Helen Ward", "473742",LocalDate.parse("2023-09-30",
    		   DateTimeFormatter.ofPattern(DATE_PATTERN)),"Saturday","Non-Working Day",0,"-","-","-"));
       
       WorkSchedules.add(new WorkScheduleDTO("Maria Newman", "837483",LocalDate.parse("2023-09-30",
    		   DateTimeFormatter.ofPattern(DATE_PATTERN)),"Saturday","Non-Working Day",0,"-","-","-"));
       
       WorkSchedules.add(new WorkScheduleDTO("Shirley Booth", "237867",LocalDate.parse("2023-09-30",
    		   DateTimeFormatter.ofPattern(DATE_PATTERN)),"Saturday","Non-Working Day",0,"-","-","-"));
       
       WorkSchedules.add(new WorkScheduleDTO("Michael Harwood", "237865",LocalDate.parse("2023-09-30",
    		   DateTimeFormatter.ofPattern(DATE_PATTERN)),"Saturday","Non-Working Day",0,"-","-","-"));
       
       WorkSchedules.add(new WorkScheduleDTO("Alecia Moore", "237866",LocalDate.parse("2023-09-30",
    		   DateTimeFormatter.ofPattern(DATE_PATTERN)),"Saturday","Non-Working Day",0,"-","-","-"));
       
       WorkSchedules.add(new WorkScheduleDTO("Jean Scott", "237870",LocalDate.parse("2023-09-30",
    		   DateTimeFormatter.ofPattern(DATE_PATTERN)),"Saturday","Non-Working Day",0,"-","-","-"));
       
       
       return WorkSchedules;
    }
    
    
    private static JsonNode getWorkSchedules(JsonNode json) {
        return Optional.ofNullable(json)
                .map(j -> j.get("workSchedules"))
                .orElseThrow(() -> new IllegalArgumentException("Invalid JSON Object"));
    }

    private static List<WorkScheduleDTO> getDaysFromSchedulePeriods(JsonNode workSchedule) {
        
    	String DATE_PATTERN = "yyyy-MM-dd";
    	String empName=workSchedule.get("workerName").get("formattedName").asText();
    	
    	JsonNode scheduleDays = Optional.ofNullable(workSchedule)
        .map(j -> j.get("scheduleDays"))
        .orElseThrow(() -> new IllegalArgumentException("Invalid JSON Object"));
    	
    	String associateId = workSchedule.get("associateOID").asText();
    	
    	List<WorkScheduleDTO> workschedulesarray = new ArrayList<>();
    	
        for (JsonNode day : scheduleDays) {
        	
        	String date = day.get("scheduleDayDate").asText();
        	String weekday = day.get("dayOfWeekCode").get("name").asText();
        	String dayStatus = day.get("dayStatusCode").get("name").asText();
        	
        	int totalHours;
        	String startTime;
        	String endTime;
        	String shiftType;

        	
        	if(dayStatus.equals("Working Day")) {
            	totalHours = day.get("scheduledHours").get("hoursQuantity").asInt();
            	JsonNode shiftSegmentsnode = day.get("workShifts").get(0).get("shiftSegments");
            	JsonNode shiftTypeNode=day.get("workShifts").get(0).get("shiftDescription");
            	shiftType=shiftTypeNode.asText();
            	JsonNode startTimenode = shiftSegmentsnode.get(0).get("segmentDateTimePeriod").get("startDateTime");
            	JsonNode endTimenode = shiftSegmentsnode.get(shiftSegmentsnode.size()-1).get("segmentDateTimePeriod").get("endDateTime");
            	startTime = startTimenode.asText();
            	endTime = endTimenode.asText();
        	}
        	else {
        		totalHours = 0;
        		startTime = "-";
        		endTime = "-";
        		shiftType= "-";
        	}
        	
        	workschedulesarray.add(new WorkScheduleDTO(empName, associateId, LocalDate.parse(date, DateTimeFormatter.ofPattern(DATE_PATTERN)), weekday, dayStatus, totalHours, startTime, endTime,shiftType));
        	
        }
        
		return workschedulesarray; 

    }

}
