package com.batch1.team1.Ecalendar.dao;

import java.io.IOException;
import java.io.InputStream;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Component;

import com.batch1.team1.Ecalendar.model.dto.LeaveTransactionDTO;
import com.batch1.team1.Ecalendar.utils.FailedToReadJsonException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;


@Component
public class LeaveTransactionsDataLoader {
	
	public static List<LeaveTransactionDTO> readJsonAndGetLeaveDetails() throws FailedToReadJsonException {
    	
		String DATE_PATTERN = "yyyy-MM-dd"; 
   	 	ObjectMapper objectMapper = new ObjectMapper();
   	 
   	 	List<LeaveTransactionDTO> Leaves = new ArrayList<>();
	   	JsonNode json;

       try (InputStream inputStream = TypeReference.class.getResourceAsStream("/data/Leave-events-response.json")) {
       	json = objectMapper.readValue(inputStream, JsonNode.class);
       } catch (IOException e) {
           throw new FailedToReadJsonException("Failed to read JSON data");
       }

       JsonNode leaves = getWorkSchedules(json);
       for (JsonNode leave : leaves) {
    	   Leaves.addAll(getDaysFromSchedulePeriods(leave));
       } 
       
       Leaves.add(new LeaveTransactionDTO("473742", "LITE045", "Helen Ward", "leave1", 
   			LocalDate.parse("2023-10-21", DateTimeFormatter.ofPattern(DATE_PATTERN)), 
   			LocalDate.parse("2023-10-21", DateTimeFormatter.ofPattern(DATE_PATTERN)), 
   			"starttime1", "endtime1", 2, "Privilege Leave", "Pending"));
       Leaves.add(new LeaveTransactionDTO("473742", "LITE045", "Helen Ward", "leave1", 
      			LocalDate.parse("2023-10-24", DateTimeFormatter.ofPattern(DATE_PATTERN)), 
      			LocalDate.parse("2023-10-26", DateTimeFormatter.ofPattern(DATE_PATTERN)), 
      			"starttime1", "endtime1", 2, "Privilege Leave", "Pending"));
       
       Leaves.add(new LeaveTransactionDTO("435628", "ARP1293", "Aaron Baker", "leave2", 
   			LocalDate.parse("2023-09-11", DateTimeFormatter.ofPattern(DATE_PATTERN)), 
   			LocalDate.parse("2023-09-15", DateTimeFormatter.ofPattern(DATE_PATTERN)), 
   			"starttime2", "endtime2", 2, "Sick Leave", "Approved"));
       
       Leaves.add(new LeaveTransactionDTO("837483", "LITE290", "Maria Newman", "leave3", 
   			LocalDate.parse("2023-09-11", DateTimeFormatter.ofPattern(DATE_PATTERN)), 
   			LocalDate.parse("2023-09-13", DateTimeFormatter.ofPattern(DATE_PATTERN)), 
   			"starttime3", "endtime3", 2, "Sick Leave", "Approved"));
       
       Leaves.add(new LeaveTransactionDTO("837483", "LITE290", "Maria Newman", "leave3", 
      			LocalDate.parse("2023-10-11", DateTimeFormatter.ofPattern(DATE_PATTERN)), 
      			LocalDate.parse("2023-10-13", DateTimeFormatter.ofPattern(DATE_PATTERN)), 
      			"starttime3", "endtime3", 2, "Privilege Leave", "Pending"));
       
       return Leaves;
    }
    
    
    private static JsonNode getWorkSchedules(JsonNode json) {
        return Optional.ofNullable(json)
                .map(j -> j.get("timeOffRequests"))
                .orElseThrow(() -> new IllegalArgumentException("Invalid JSON Object"));
    }

    private static List<LeaveTransactionDTO> getDaysFromSchedulePeriods(JsonNode leave) {
        
    	String DATE_PATTERN = "yyyy-MM-dd";
    	
    	JsonNode timeOffEntries = Optional.ofNullable(leave)
        .map(j -> j.get("timeOffEntries"))
        .orElseThrow(() -> new IllegalArgumentException("Invalid JSON Object"));
    	
    	String associateId = leave.get("associateOID").asText();
    	String workerId = leave.get("workerID").get("idValue").asText();
    	String name = leave.get("requestorName").get("formattedName").asText();
    	String leaveId = leave.get("timeOffRequestID").asText();
    	
    	List<LeaveTransactionDTO> leavesarray = new ArrayList<>();
    	
        for (JsonNode entry : timeOffEntries) {
        	
            String leaveFromDate = entry.get("datePeriod").get("startDate").asText();
            String leaveToDate = entry.get("datePeriod").get("endDate").asText();
            String startTime = entry.get("dateTimePeriod").get("startDateTime").asText();
            String endTime = entry.get("dateTimePeriod").get("endDateTime").asText();
            int totalHours = entry.get("totalQuantity").get("quantityValue").asInt();
            String leaveType = entry.get("entryTypeCode").get("shortName").asText();
            String leaveStatus = entry.get("entryStatusCode").get("shortName").asText();
        	
        	leavesarray.add(new LeaveTransactionDTO(associateId, workerId, name, leaveId, 
        			LocalDate.parse(leaveFromDate, DateTimeFormatter.ofPattern(DATE_PATTERN)), 
        			LocalDate.parse(leaveToDate, DateTimeFormatter.ofPattern(DATE_PATTERN)), 
        			startTime, endTime, totalHours, leaveType, leaveStatus));
        	
        	
        }
        
		return leavesarray; 

    }

}