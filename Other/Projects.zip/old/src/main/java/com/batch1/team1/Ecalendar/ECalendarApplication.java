package com.batch1.team1.Ecalendar;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ECalendarApplication {

	public static void main(String[] args) {
		SpringApplication.run(ECalendarApplication.class, args);
	}

}
