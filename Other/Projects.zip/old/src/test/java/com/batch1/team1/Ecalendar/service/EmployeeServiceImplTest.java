package com.batch1.team1.Ecalendar.service;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertEquals;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.TestConfiguration;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.annotation.Bean;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import com.batch1.team1.Ecalendar.utils.FailedToReadJsonException;
import com.batch1.team1.Ecalendar.dao.EmployeeDao;
import com.batch1.team1.Ecalendar.model.dto.EmployeeDTO;
import com.batch1.team1.Ecalendar.model.dto.EmployeeLeaveDTO;
import com.batch1.team1.Ecalendar.model.dto.LeaveCountbyDayDTO;
import com.batch1.team1.Ecalendar.model.dto.LeaveTransactionDTO;
import com.batch1.team1.Ecalendar.model.dto.ObjectEntitlementDTO;
import com.batch1.team1.Ecalendar.model.dto.WorkScheduleDTO;
import com.batch1.team1.Ecalendar.service.EmployeeService;
import com.batch1.team1.Ecalendar.service.EmployeeServiceImpl;

@ExtendWith(SpringExtension.class)
public class EmployeeServiceImplTest {
	
	@TestConfiguration
	static class EmployeeServiceImplContextConfiguration{
		@Bean
		public EmployeeService employeeService()
		{
			return new EmployeeServiceImpl();
		}
	}
	
	@Autowired
	private EmployeeService employeeService;

	@MockBean
	EmployeeDao dao;
	
	String datePattern = "yyyy-MM-dd";
	
	List<String> strList = new ArrayList<>();
			int count1 = 4;
			int count2 = 5;
			String strManagerInsights1;
			String strManagerInsights2;
			
    List<String> strList1 = new ArrayList<>();
			String strManagerInsights11;
			
    List<String> strList2 = new ArrayList<>();
				String strManagerInsights21;
				
	List<EmployeeDTO> allEmployees=new ArrayList<>();
	
	List<LeaveTransactionDTO> allLeaveDetails = new ArrayList<>();
	
	List<WorkScheduleDTO> allWorkDetails = new ArrayList<>();
	
	LeaveCountbyDayDTO[] array = new LeaveCountbyDayDTO[2];
	
	int[] workingCountArray = new int[2];
    
    int[] nonWorkingCountArray = new int[2];
			
	@BeforeEach()
	public void setUp() throws FailedToReadJsonException {
		
		EmployeeDTO shreya=new EmployeeDTO("SSHREYAV","508083","Shreya","Developer",LocalDate.parse("2001-07-24", DateTimeFormatter.ofPattern(datePattern)),"508090","Krishna","shreya@ADP.com",LocalDate.parse("2001-07-24", DateTimeFormatter.ofPattern(datePattern)));
		EmployeeDTO yamini=new EmployeeDTO("KYAMINIK","508093","Yamini","Developer",LocalDate.parse("2001-06-24", DateTimeFormatter.ofPattern(datePattern)),"508090","Krishna","yamini@ADP.com",LocalDate.parse("2001-07-24", DateTimeFormatter.ofPattern(datePattern)));
		
		List<EmployeeDTO> employee1=new ArrayList<>();
		List<EmployeeDTO> employee2=new ArrayList<>();
		employee1.add(shreya);
		employee2.add(yamini);
		allEmployees.add(shreya);
		allEmployees.add(yamini);
		WorkScheduleDTO workDetails1 = new WorkScheduleDTO("SHREYA","508083",LocalDate.parse("2023-09-14", DateTimeFormatter.ofPattern(datePattern)),"saturday","working",9,"8:30am","5:30pm","morning");
		WorkScheduleDTO workDetails2 = new WorkScheduleDTO("YAMINI","508093",LocalDate.parse("2023-09-14", DateTimeFormatter.ofPattern(datePattern)),"saturday","working",9,"8:30am","5:30pm","morning");
		
		List<WorkScheduleDTO> workSchedule1 = new ArrayList<>();
		List<WorkScheduleDTO> workSchedule2 = new ArrayList<>();
		workSchedule1.add(workDetails1);
		workSchedule2.add(workDetails2);
		allWorkDetails.add(workDetails1);
		allWorkDetails.add(workDetails2);
		
		LeaveTransactionDTO leaveDetails1 = new LeaveTransactionDTO("SSHREYAV","508083","Shreya","508080_leave",LocalDate.parse("2023-09-14", DateTimeFormatter.ofPattern(datePattern)),LocalDate.parse("2023-09-20", DateTimeFormatter.ofPattern(datePattern)),"8:30am","12:30am",8,"sickLeave","approved");
		
		List<LeaveTransactionDTO> leaveTransaction1 = new ArrayList<>();
		leaveTransaction1.add(leaveDetails1);
		allLeaveDetails.add(leaveDetails1);
		
		ObjectEntitlementDTO entitlementDetails1 = new ObjectEntitlementDTO("508090","SSHREYAV","Shreya","john");
		
		List<ObjectEntitlementDTO> objectEntitlementDetails1 = new ArrayList<>();
		List<ObjectEntitlementDTO> allObjectEntitlementDetails = new ArrayList<>();
		objectEntitlementDetails1.add(entitlementDetails1);
		allObjectEntitlementDetails.add(entitlementDetails1);
		
		EmployeeLeaveDTO employeeLeaveDetails1 = new EmployeeLeaveDTO("SSHREYAV","casual leave",LocalDate.parse("2023-09-14", DateTimeFormatter.ofPattern(datePattern)),LocalDate.parse("2023-09-20", DateTimeFormatter.ofPattern(datePattern)),"approved","Shreya","Developer","permanent","john","wfo","hyderabad");
		
		List<EmployeeLeaveDTO> employee1LeaveDetails = new ArrayList<>();
		List<EmployeeLeaveDTO> allEmployeeLeaveDetails1 = new ArrayList<>();
		employee1LeaveDetails.add(employeeLeaveDetails1);
		allEmployeeLeaveDetails1.add(employeeLeaveDetails1);
		
		strManagerInsights1 = shreya.getEmployeeName()+" has taken " + count1+" sick leaves";
		strManagerInsights2 = yamini.getEmployeeName()+" has taken " + count2+" sick leaves";
		strList.add(strManagerInsights1);
		strList.add(strManagerInsights2);
		
		strManagerInsights11 = entitlementDetails1.getEmployeeName()+" has not taken any leaves in three months";
		strList1.add(strManagerInsights11);
		
		strManagerInsights21 = entitlementDetails1.getEmployeeName()+" has had equal to or more than 3 consecutive shifts";
		strList2.add(strManagerInsights21);
		
		array[0]=new LeaveCountbyDayDTO(0,0);
		array[0].day = 3;
		array[0].leaveCountByDay = 5;
		array[1]=new LeaveCountbyDayDTO(0,0);
		array[1].day = 4;
		array[1].leaveCountByDay = 3;
		
		
		
		workingCountArray[0] = 2;
        workingCountArray[1] = 3;
        
        nonWorkingCountArray[0] = 2;
        nonWorkingCountArray[1] = 3;
		
		Mockito.when(dao.getEmployeeDetailsById(shreya.getAssociateId())).thenReturn(employee1);
        Mockito.when(dao.getEmployeeDetailsById(yamini.getAssociateId())).thenReturn(employee2);
        Mockito.when(dao.getEmployeeDetailsById("wrong_associateId")).thenReturn(null);
        
        
        Mockito.when(dao.getWorkSchedulesById(workDetails1.getAssociateId())).thenReturn(workSchedule1);
        Mockito.when(dao.getWorkSchedulesById(workDetails2.getAssociateId())).thenReturn(workSchedule2);
	
	    Mockito.when(dao.getLeaveTransactionsById(leaveDetails1.getAssociateId())).thenReturn(leaveTransaction1);
	
	    LocalDate date = shreya.getEmployeeDOB();
	    DateTimeFormatter formatter =DateTimeFormatter.ofPattern("yyyy-MM-dd");
	    	
	    Mockito.when(dao.getEmployeeDetailsByManagerIdFromEmployeeData(shreya.getManagerId())).thenReturn(employee1);
	
	    Mockito.when(dao.getEmployeeDetailsByManagerIdFromManagerData(entitlementDetails1.getManagerId())).thenReturn(objectEntitlementDetails1);
	    
	    Mockito.when(dao.getEmployeeLeaveDetailsById(employeeLeaveDetails1.getAssociateId())).thenReturn(employee1LeaveDetails);
	    
	    Mockito.when(dao.frequentSickLeave(entitlementDetails1.getManagerId())).thenReturn(strList);
	    
	    Mockito.when(dao.noLeaveOf3months(entitlementDetails1.getManagerId())).thenReturn(strList1);
	    
	    Mockito.when(dao.consec3NightShifts(entitlementDetails1.getManagerId())).thenReturn(strList2);
	    
	    Mockito.when(dao.EmpsBirthday(entitlementDetails1.getManagerId())).thenReturn(allEmployees);
	    
	    Mockito.when(dao.leavesOfEmpOfManager(entitlementDetails1.getManagerId())).thenReturn(allLeaveDetails);
	    
	    Mockito.when(dao.workSchedOfEmpsUnderManager(entitlementDetails1.getManagerId())).thenReturn(allWorkDetails);
	    
	    Mockito.when(dao.leaveCountOfEverydayMonthbyDay(entitlementDetails1.getManagerId())).thenReturn(array);
	    
	    Mockito.when(dao.workingCountOfEverydayMonth(entitlementDetails1.getManagerId())).thenReturn(workingCountArray);
        
        Mockito.when(dao.nonWorkingCountOfEverydayMonth(entitlementDetails1.getManagerId())).thenReturn(nonWorkingCountArray);
        
        Mockito.when(dao.workAnniversaryToday(entitlementDetails1.getManagerId())).thenReturn(allEmployees);
        
        Mockito.when(dao.EmpsBirthdayUpcoming(entitlementDetails1.getManagerId())).thenReturn(allEmployees);
	}
	
	@Test
    public void whenValidIdthenEmployeeShouldBeFound() throws FailedToReadJsonException {
        String associateId = "SSHREYAV";
        List<EmployeeDTO> found = employeeService.getEmployeeDetailsById(associateId);
        assertThat(found.get(0).getAssociateId()).isEqualTo(associateId);
    }
	
	@Test
    public void whenInValidIdthenEmployeeShouldNotBeFound() throws FailedToReadJsonException {
        List<EmployeeDTO> fromdao = employeeService.getEmployeeDetailsById("wrong_associateId");
        assertThat(fromdao).isNull();
    }
	
	@Test
    public void whenValidIdthenWorkScheduleShouldBeFound() throws FailedToReadJsonException {
        String associateId = "508083";
        List<WorkScheduleDTO> found = employeeService.getWorkSchedulesById(associateId);
        assertThat(found.get(0).getAssociateId()).isEqualTo(associateId);
    }

	@Test
    public void whenValidIdthenLeaveTransactionDetailsShouldBeFound() throws FailedToReadJsonException {
        String associateId = "SSHREYAV";
        List<LeaveTransactionDTO> found = employeeService.getLeaveTransactionsById(associateId);
        assertThat(found.get(0).getAssociateId()).isEqualTo(associateId);
    }
	
	
	@Test
    public void whenValidManagerIdthenEmployeeDetailsShouldBeFound() throws FailedToReadJsonException {
        String managerId = "508090";
        List<EmployeeDTO> found = employeeService.getEmployeeDetailsByManagerIdFromEmployeeData(managerId);
        assertThat(found.get(0).getManagerId()).isEqualTo(managerId);
    }
	
	@Test
    public void whenValidManagerIdthenEmployeeDetailsbyManagerIdShouldBeFound() throws FailedToReadJsonException {
        String managerId = "508090";
        List<ObjectEntitlementDTO> found = employeeService.getEmployeeDetailsByManagerIdFromManagerData(managerId);
        assertThat(found.get(0).getManagerId()).isEqualTo(managerId);
    }
	
	@Test
    public void whenValidIdthenEmployeeLeaveDetailsShouldBeFound() throws FailedToReadJsonException {
        String associateId = "SSHREYAV";
        List<EmployeeLeaveDTO> found = employeeService.getEmployeeLeaveDetailsById(associateId);
        assertThat(found.get(0).getAssociateId()).isEqualTo(associateId);
    }
	
	@Test
	public void whenValidManagerIdthenfrequentsSickLeaveShouldbeFound() throws FailedToReadJsonException
	{
		String managerId = "508090";
		List<String> found = employeeService.frequentSickLeave(managerId);
		assertEquals(found, strList);
	}
	
	@Test
	public void whenValidManagerIdthenNoLeaveforThreeMonthsShouldbeFound() throws FailedToReadJsonException
	{
		String managerId = "508090";
		List<String> found = employeeService.noLeaveOf3months(managerId);
		assertEquals(found, strList1);
	}
	
	@Test
	public void whenValidManagerIdthenconsec3NightShiftsShouldbeFound() throws FailedToReadJsonException
	{
		String managerId = "508090";
		List<String> found = employeeService.consec3NightShifts(managerId);
		assertEquals(found, strList2);
	}
	
	@Test
	public void whenValidManagerIdthenEmpsBirthdayShouldbeFound() throws FailedToReadJsonException
	{
		String managerId = "508090";
		List<EmployeeDTO> found = employeeService.EmpsBirthday(managerId);
		assertEquals(found, allEmployees);
	}
	
	@Test
	public void whenValidManagerIdthenleavesOfEmpOfManagerShouldbeFound() throws FailedToReadJsonException
	{
		String managerId = "508090";
		List<LeaveTransactionDTO> found = employeeService.leavesOfEmpOfManager(managerId);
		assertEquals(found, allLeaveDetails);
	}
	
	@Test
	public void whenValidManagerIdthenworkSchedOfEmpsUnderManagerShouldbeFound() throws FailedToReadJsonException
	{
		String managerId = "508090";
		List<WorkScheduleDTO> found = employeeService.workSchedOfEmpsUnderManager(managerId);
		assertEquals(found, allWorkDetails);
	}
	
	@Test
	public void whenValidManagerIdthenleaveCountOfEverydayMonthbyDayShouldbeReturned() throws FailedToReadJsonException
	{
		String managerId = "508090";
		LeaveCountbyDayDTO[] found = employeeService
				.leaveCountOfEverydayMonthbyDay(managerId);
		assertEquals(found, array);
	}	
	
	@Test
    public void whenValidManagerIdthenworkingCountOfEverydayMonthShouldbeReturned() throws FailedToReadJsonException
    {
        String managerId = "508090";
        int[] found = employeeService
                .workingCountOfEverydayMonth(managerId);
        assertEquals(found, workingCountArray);
    }    
    
    @Test
    public void whenValidManagerIdthenNonWorkingCountOfEverydayMonthShouldbeReturned() throws FailedToReadJsonException
    {
        String managerId = "508090";
        int[] found = employeeService
                .nonWorkingCountOfEverydayMonth(managerId);
        assertEquals(found, nonWorkingCountArray);
    }
    
    @Test
    public void whenValidManagerIdthenworkAnniversaryTodayShouldBeFound() throws FailedToReadJsonException {
        String managerId = "508090";
        List<EmployeeDTO> found = employeeService.workAnniversaryToday(managerId);
        assertEquals(found,allEmployees);
    }
    
    @Test
    public void whenValidManagerIdthenEmpsBirthdayUpcomingShouldBeFound() throws FailedToReadJsonException {
        String managerId = "508090";
        List<EmployeeDTO> found = employeeService.EmpsBirthdayUpcoming(managerId);
        assertEquals(found,allEmployees);
    }
    
	
}