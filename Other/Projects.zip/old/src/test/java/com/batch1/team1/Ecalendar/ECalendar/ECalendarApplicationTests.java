package com.batch1.team1.Ecalendar.ECalendar;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ECalendarApplicationTests {

	@Test
	void contextLoads() {
	}

}
