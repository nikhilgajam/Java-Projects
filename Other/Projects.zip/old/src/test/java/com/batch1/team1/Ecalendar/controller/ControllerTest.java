package com.batch1.team1.Ecalendar.controller;



import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;

import com.batch1.team1.Ecalendar.controller.ECalenderController;
import com.batch1.team1.Ecalendar.model.dto.EmployeeDTO;
import com.batch1.team1.Ecalendar.model.dto.EmployeeLeaveDTO;
import com.batch1.team1.Ecalendar.model.dto.LeaveCountbyDayDTO;
import com.batch1.team1.Ecalendar.model.dto.LeaveTransactionDTO;
import com.batch1.team1.Ecalendar.model.dto.ObjectEntitlementDTO;
import com.batch1.team1.Ecalendar.model.dto.WorkScheduleDTO;
import com.batch1.team1.Ecalendar.service.EmployeeService;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;


@WebMvcTest(ECalenderController.class)
class ControllerTest
{
	@MockBean
	EmployeeService employeeService;
	
	@Autowired
	MockMvc mockMvc;
	
	String datePattern = "yyyy-MM-dd";
	@Test
	void testGetEmployeeDetailsById() throws Exception{
		
		
		final List<EmployeeDTO> mockEmployeeList = new ArrayList<>();
		mockEmployeeList.add(new EmployeeDTO("123", "1001","John Doe", "Manager",LocalDate.parse("2023-09-14", DateTimeFormatter.ofPattern(datePattern)),"2001","Anil","john@doe.com",LocalDate.parse("2000-03-11", DateTimeFormatter.ofPattern(datePattern))));
		when(employeeService.getEmployeeDetailsById("123")).thenReturn(mockEmployeeList);
		mockMvc.perform(get("/getEmployeeDetailsById/{empId}","123")
				.contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())      
		        .andExpect(jsonPath("$[0].associateId").value("123"));
	}
	
	@Test
	void testGetEmployeeDetailsByIdValidationErrors() throws Exception{
		
		EmployeeDTO employeeDTO = new EmployeeDTO(" "," "," "," ",LocalDate.parse("2023-09-14", DateTimeFormatter.ofPattern(datePattern))," "," "," ",LocalDate.parse("2023-09-14", DateTimeFormatter.ofPattern(datePattern)));
		
		final ObjectMapper objectMapper =new ObjectMapper();
		objectMapper.registerModule(new JavaTimeModule());
		final String employeeDtoJSON = objectMapper.writeValueAsString(employeeDTO);
		
		final MvcResult result = mockMvc.perform(get("/getEmployeeDetailsById/{empId}","1250")
				.contentType(MediaType.APPLICATION_JSON)
				.content(employeeDtoJSON))
		.andReturn();
	    final int statusCode = result.getResponse().getStatus();
		assertEquals(HttpStatus.BAD_REQUEST.value(), statusCode);
	}
	
	@Test
        void testGetWorkSchedulesById() throws Exception{
		
		
		final List<WorkScheduleDTO> mockWorkScheduleList = new ArrayList<>();
		mockWorkScheduleList.add(new WorkScheduleDTO("Shreya","1234",LocalDate.parse("2023-09-14", DateTimeFormatter.ofPattern(datePattern)),"saturday","working",9,"8:30am","5:30pm","morning"));
		when(employeeService.getWorkSchedulesById("1234")).thenReturn(mockWorkScheduleList);
		mockMvc.perform(get("/getWorkschedulesById/{empId}","1234")
				.contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())      
		        .andExpect(jsonPath("$[0].associateId").value("1234"));      
	}
	
	@Test
	void testGetWorkSchedulesByIdValidationErrors() throws Exception{
		
		final WorkScheduleDTO workScheduleDTO = new WorkScheduleDTO(" ","1235",LocalDate.parse("2023-09-14", DateTimeFormatter.ofPattern(datePattern))," "," ",9,"8:30am","5:30pm"," ");
		
		final ObjectMapper objectMapper =new ObjectMapper();
		objectMapper.registerModule(new JavaTimeModule());
		
		final String workScheduleDTOJSON = objectMapper.writeValueAsString(workScheduleDTO);
		
		final MvcResult result = mockMvc.perform(get("/getWorkschedulesById/{empId}","1234")
				.contentType(MediaType.APPLICATION_JSON)
				.content(workScheduleDTOJSON))
		.andReturn();
		final int statusCode = result.getResponse().getStatus();
		assertEquals(HttpStatus.BAD_REQUEST.value(), statusCode);
	}
	
	@Test
        void testGetLeaveTransactionsById() throws Exception{
		
		final List<LeaveTransactionDTO> mockLeaveTransactionList = new ArrayList<>();
		mockLeaveTransactionList.add(new LeaveTransactionDTO("1234","123","Anmol","9848",LocalDate.parse("2023-09-14", DateTimeFormatter.ofPattern(datePattern)),LocalDate.parse("2023-09-20", DateTimeFormatter.ofPattern(datePattern)),"8:30am","12:30am",8,"sickLeave","approved"));
		when(employeeService.getLeaveTransactionsById("1234")).thenReturn(mockLeaveTransactionList);
		mockMvc.perform(get("/getLeaveTransactionsById/{empId}","1234")
				.contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())  
		        .andExpect(jsonPath("$[0].associateId").value("1234"));      
	}
	
	
	@Test
	void testGetLeaveTransactionsByIdValidationErrors() throws Exception{
		
		final LeaveTransactionDTO leaveTransactionDTO = new LeaveTransactionDTO(" "," ","Anmol","9848",LocalDate.parse("2023-09-14", DateTimeFormatter.ofPattern(datePattern)),LocalDate.parse("2023-09-20", DateTimeFormatter.ofPattern(datePattern)),"8:30am","12:30am",8,"sickLeave","approved");
		
		final ObjectMapper objectMapper =new ObjectMapper();
		objectMapper.registerModule(new JavaTimeModule());
		
		final String leaveTransactionDTOJSON = objectMapper.writeValueAsString(leaveTransactionDTO);
		
		final MvcResult result = mockMvc.perform(get("/getLeaveTransactionsById/{empId}","1234")
				.contentType(MediaType.APPLICATION_JSON)
				.content(leaveTransactionDTOJSON))
		.andReturn();
		final int statusCode = result.getResponse().getStatus();
		assertEquals(HttpStatus.BAD_REQUEST.value(), statusCode);
	}

	
	@Test
    void testGetEmployeeDetailsByManagerIdFromEmployeeData() throws Exception{
	
	final List<EmployeeDTO> mockEmployeeDetailsbyManagerIdList = new ArrayList<>();
	mockEmployeeDetailsbyManagerIdList.add(new EmployeeDTO("123", "1001","John Doe", "Manager",LocalDate.parse("2023-09-14", DateTimeFormatter.ofPattern(datePattern)),"2001","Anil","john@doe.com",LocalDate.parse("2000-09-14", DateTimeFormatter.ofPattern(datePattern))));
	when(employeeService.getEmployeeDetailsByManagerIdFromEmployeeData("2001")).thenReturn(mockEmployeeDetailsbyManagerIdList);
	mockMvc.perform(get("/getEmployeeDetailsByManagerIdFromEmployeeData/{managerId}","2001")
			.contentType(MediaType.APPLICATION_JSON))
            .andExpect(status().isOk())  
	        .andExpect(jsonPath("$[0].managerId").value("2001"));      
}
	@Test
	void testGetEmployeeDetailsByManagerIdFromEmployeeDataValidationErrors() throws Exception{
		
		final EmployeeDTO employeeDTO = new EmployeeDTO(" "," ","John Doe", "Manager",LocalDate.parse("2023-09-14", DateTimeFormatter.ofPattern(datePattern)),"2001","Anil","john@doe.com",LocalDate.parse("2000-09-14", DateTimeFormatter.ofPattern(datePattern)));
		
		final ObjectMapper objectMapper =new ObjectMapper();
		objectMapper.registerModule(new JavaTimeModule());
		
		final String employeeDTOJSON = objectMapper.writeValueAsString(employeeDTO);
		
		final MvcResult result = mockMvc.perform(get("/getEmployeeDetailsByManagerIdFromManagerData/{managerId}","123")
				.contentType(MediaType.APPLICATION_JSON)
				.content(employeeDTOJSON))
		.andReturn();
		final int statusCode = result.getResponse().getStatus();
		assertEquals(HttpStatus.BAD_REQUEST.value(), statusCode);
	}
	
	
	@Test
    void testGetEmployeeDetailsByManagerIdFromManagerData() throws Exception{
	final List<ObjectEntitlementDTO> mockEmployeeDetailsbyManagerIdFromManagerDataList = new ArrayList<>();
	mockEmployeeDetailsbyManagerIdFromManagerDataList.add(new ObjectEntitlementDTO("123", "1001","Anmol","John doe"));
	when(employeeService.getEmployeeDetailsByManagerIdFromManagerData("123")).thenReturn(mockEmployeeDetailsbyManagerIdFromManagerDataList);
	mockMvc.perform(get("/getEmployeeDetailsByManagerIdFromManagerData/{managerId}","123")
			.contentType(MediaType.APPLICATION_JSON))
            .andExpect(status().isOk())  
            .andExpect(jsonPath("$[0].managerId").value("123"))
	        .andDo(print());      
}	
	@Test
	void testGetEmployeeDetailsByManagerIdFromManagerDataValidationErrors() throws Exception{
		
		final ObjectEntitlementDTO objectEntitlementDTO = new ObjectEntitlementDTO(" ", " "," "," ");
		
		final ObjectMapper objectMapper =new ObjectMapper();
		objectMapper.registerModule(new JavaTimeModule());
		
		final String objectEntitlementDtoJSON = objectMapper.writeValueAsString(objectEntitlementDTO);
		
		final MvcResult result = mockMvc.perform(get("/getEmployeeDetailsByManagerIdFromManagerData/{managerId}","123")
				.contentType(MediaType.APPLICATION_JSON)
				.content(objectEntitlementDtoJSON))
		.andReturn();
		final int statusCode = result.getResponse().getStatus();
		assertEquals(HttpStatus.BAD_REQUEST.value(), statusCode);
	}
	
	@Test
    void testGetEmployeeLeaveDetailsById() throws Exception{
	
	final List<EmployeeLeaveDTO> mockEmployeeLeaveDetailsByIdList = new ArrayList<>();
	mockEmployeeLeaveDetailsByIdList.add(new EmployeeLeaveDTO("123","Sick leave",LocalDate.parse("2023-09-14", DateTimeFormatter.ofPattern(datePattern)),LocalDate.parse("2023-09-20", DateTimeFormatter.ofPattern(datePattern)),"pending","Anil","Developer","permanent","john","wfo","hyderabad"));
	when(employeeService.getEmployeeLeaveDetailsById("123")).thenReturn(mockEmployeeLeaveDetailsByIdList);
	mockMvc.perform(get("/getEmployeeLeaveDetailsById/{associateId}","123")
			.contentType(MediaType.APPLICATION_JSON))
            .andExpect(status().isOk())  
	        .andExpect(jsonPath("$[0].associateId").value("123"));      
}
	
	@Test
	void testGetEmployeeLeaveDetailsByIdValidationErrors() throws Exception{
		
		final EmployeeLeaveDTO employeeLeaveDTO = new EmployeeLeaveDTO(" "," ",LocalDate.parse("2023-09-14", DateTimeFormatter.ofPattern(datePattern)),LocalDate.parse("2023-09-20", DateTimeFormatter.ofPattern(datePattern))," ","Anil","Developer","permanent","john","wfo","hyderabad");
		
		final ObjectMapper objectMapper =new ObjectMapper();
		objectMapper.registerModule(new JavaTimeModule());
		
		final String employeeLeaveDTOJSON = objectMapper.writeValueAsString(employeeLeaveDTO);
		
		final MvcResult result = mockMvc.perform(get("/getEmployeeLeaveDetailsById/{associateId}","123")
				.contentType(MediaType.APPLICATION_JSON)
				.content(employeeLeaveDTOJSON))
		.andReturn();
		final int statusCode = result.getResponse().getStatus();
		assertEquals(HttpStatus.BAD_REQUEST.value(), statusCode);
	}
	
	
	@Test
    void testManagerInsight1() throws Exception{
	
	final List<String> managerInsight1List = new ArrayList<>();
	
	final List<ObjectEntitlementDTO> mockEmployeeDetailsbyManagerId = new ArrayList<>();
	ObjectEntitlementDTO objectDto = new ObjectEntitlementDTO("123", "1001","deepak","John doe");
	mockEmployeeDetailsbyManagerId.add(objectDto);
	
	final ObjectMapper objectMapper =new ObjectMapper();
	objectMapper.registerModule(new JavaTimeModule());
	
	final String objectDTOJSON = objectMapper.writeValueAsString(objectDto);
	
	final int count1 = 3;
	String str = objectDto.getEmployeeName()+" has taken " + count1+" sick leaves";
	
	managerInsight1List.add(str);
	
	when(employeeService.frequentSickLeave("123")).thenReturn(managerInsight1List);
	final MvcResult result = mockMvc.perform(get("/ManagerInsight1/{managerId}","123")
			.contentType(MediaType.APPLICATION_JSON)
            .content(objectDTOJSON))
           .andReturn();
	final int statusCode = result.getResponse().getStatus();
	assertEquals(HttpStatus.OK.value(),statusCode);
}

	@Test
    void testManagerInsight2() throws Exception{
	
	final List<String> managerInsight2List = new ArrayList<>();
	
	final List<ObjectEntitlementDTO> mockEmployeeDetailsbyManagerId = new ArrayList<>();
	ObjectEntitlementDTO objectDto = new ObjectEntitlementDTO("123", "1001","varun","John doe");
	mockEmployeeDetailsbyManagerId.add(objectDto);
	
	final ObjectMapper objectMapper =new ObjectMapper();
	objectMapper.registerModule(new JavaTimeModule());
	
	final String objectDTOJSON = objectMapper.writeValueAsString(objectDto);
	
	String str = objectDto.getEmployeeName()+" has not taken any leaves in three months";
	
	managerInsight2List.add(str);
	
	when(employeeService.noLeaveOf3months("123")).thenReturn(managerInsight2List);
	final MvcResult result = mockMvc.perform(get("/ManagerInsight2/{managerId}","123")
			.contentType(MediaType.APPLICATION_JSON)
            .content(objectDTOJSON))
           .andReturn();
	final int statusCode = result.getResponse().getStatus();
	assertEquals(HttpStatus.OK.value(),statusCode);
}
	
	@Test
    void testManagerInsight3() throws Exception{
	
	final List<String> managerInsight3List = new ArrayList<>();
	
	final List<ObjectEntitlementDTO> mockEmployeeDetailsbyManagerId = new ArrayList<>();
	ObjectEntitlementDTO objectDto = new ObjectEntitlementDTO("123", "1001","Ani","John doe");
	mockEmployeeDetailsbyManagerId.add(objectDto);
	
	final ObjectMapper objectMapper =new ObjectMapper();
	objectMapper.registerModule(new JavaTimeModule());
	
	final String objectDTOJSON = objectMapper.writeValueAsString(objectDto);
	String str = objectDto.getEmployeeName()+" has had equal to or more than 3 consecutive shifts";
	
	managerInsight3List.add(str);
	
	when(employeeService.consec3NightShifts("123")).thenReturn(managerInsight3List);
	final MvcResult result = mockMvc.perform(get("/ManagerInsight3/{managerId}","123")
			.contentType(MediaType.APPLICATION_JSON)
            .content(objectDTOJSON))
           .andReturn();
	final int statusCode = result.getResponse().getStatus();
	assertEquals(HttpStatus.OK.value(),statusCode);
}	

	@Test
    void testManagerInsights4() throws Exception{
	
	final List<EmployeeDTO> mockEmployeeDetailsList = new ArrayList<>();
	mockEmployeeDetailsList.add(new EmployeeDTO("123", "1001","John Doe", "Manager",LocalDate.parse("2023-09-14", DateTimeFormatter.ofPattern(datePattern)),"2001","Anil","john@doe.com",LocalDate.parse("2000-09-14", DateTimeFormatter.ofPattern(datePattern))));
	when(employeeService.EmpsBirthday("2001")).thenReturn(mockEmployeeDetailsList);
	mockMvc.perform(get("/ManagerInsight4/{managerId}","2001")
			.contentType(MediaType.APPLICATION_JSON))
            .andExpect(status().isOk())  
	        .andExpect(jsonPath("$[0].managerId").value("2001"));      
}
	@Test
	void testManagerInsights4ValidationErrors() throws Exception{
		
		final EmployeeDTO employeeDTO = new EmployeeDTO(" "," ","John Doe", "Manager",LocalDate.parse("2023-09-14", DateTimeFormatter.ofPattern(datePattern))," ","Anil","john@doe.com",LocalDate.parse("2000-09-14", DateTimeFormatter.ofPattern(datePattern)));
		
		final ObjectMapper objectMapper =new ObjectMapper();
		objectMapper.registerModule(new JavaTimeModule());
		
		final String employeeDTOJSON = objectMapper.writeValueAsString(employeeDTO);
		
		final MvcResult result = mockMvc.perform(get("/ManagerInsight4/{managerId}","123")
				.contentType(MediaType.APPLICATION_JSON)
				.content(employeeDTOJSON))
		.andReturn();
		final int statusCode = result.getResponse().getStatus();
		assertEquals(HttpStatus.BAD_REQUEST.value(), statusCode);
	}
	
	@Test
    void testLeavesOfEmpOfManager() throws Exception{
	
	final List<LeaveTransactionDTO> mockLeaveTransactionList = new ArrayList<>();
	mockLeaveTransactionList.add(new LeaveTransactionDTO("1234","123","Anmol","9848",LocalDate.parse("2023-09-14", DateTimeFormatter.ofPattern(datePattern)),LocalDate.parse("2023-09-20", DateTimeFormatter.ofPattern(datePattern)),"8:30am","12:30am",8,"sickLeave","approved"));
	String managerId = "1001";
	when(employeeService.leavesOfEmpOfManager(managerId)).thenReturn(mockLeaveTransactionList);
	mockMvc.perform(get("/leavesOfEmpOfManager/{managerId}","1001")
			.contentType(MediaType.APPLICATION_JSON))
            .andExpect(status().isOk()) ;      
}
	
	@Test
    void testWorkSchedOfEmpsUnderManager() throws Exception{
	
		final List<WorkScheduleDTO> mockWorkScheduleList = new ArrayList<>();
		mockWorkScheduleList.add(new WorkScheduleDTO("Shreya","1234",LocalDate.parse("2023-09-14", DateTimeFormatter.ofPattern(datePattern)),"saturday","working",9,"8:30am","5:30pm","morning"));
		String managerId = "1001";
		when(employeeService.workSchedOfEmpsUnderManager(managerId)).thenReturn(mockWorkScheduleList);
	    mockMvc.perform(get("/workSchedOfEmpsUnderManager/{managerId}","1001")
			.contentType(MediaType.APPLICATION_JSON))
            .andExpect(status().isOk()) ;      
}
	@Test
    void testLeaveCountOfEverydayMonth() throws Exception{
	
		final List<WorkScheduleDTO> mockWorkScheduleList = new ArrayList<>();
		mockWorkScheduleList.add(new WorkScheduleDTO("Shreya","1234",LocalDate.parse("2023-09-14", DateTimeFormatter.ofPattern(datePattern)),"saturday","working",9,"8:30am","5:30pm","morning"));
		String managerId = "1001";
		when(employeeService.workSchedOfEmpsUnderManager(managerId)).thenReturn(mockWorkScheduleList);
	    mockMvc.perform(get("/workSchedOfEmpsUnderManager/{managerId}","1001")
			.contentType(MediaType.APPLICATION_JSON))
            .andExpect(status().isOk()) ;      
}

	@Test
    void testLeaveCountOfEverydayMonthbyDay() throws Exception{
		
		LeaveCountbyDayDTO[] array = new LeaveCountbyDayDTO[2];
		array[0]=new LeaveCountbyDayDTO(0,0);
		array[0].day = 3;
		array[0].leaveCountByDay = 5;
		array[1]=new LeaveCountbyDayDTO(0,0);
		array[1].day = 4;
		array[1].leaveCountByDay = 3;
		
		String managerId = "1001";
		when(employeeService.leaveCountOfEverydayMonthbyDay(managerId)).thenReturn(array);
	    mockMvc.perform(get("/leaveCountOfEverydayMonthbyDay/{managerId}","1001")
			.contentType(MediaType.APPLICATION_JSON))
            .andExpect(status().isOk()) ;      
}
	 @Test
	    void testWorkingCountOfEverydayMonth() throws Exception{
	    
	        String managerId = "1001";
	        int[] array = new int[] {2,3};
	        when(employeeService.workingCountOfEverydayMonth(managerId)).thenReturn(array);
	        mockMvc.perform(get("/workingCountOfEverydayMonth/{managerId}","1001")
	            .contentType(MediaType.APPLICATION_JSON))
	            .andExpect(status().isOk()) ;      
	}
	    
	    @Test
	    void testNonWorkingCountOfEverydayMonth() throws Exception{
	    
	        String managerId = "1001";
	        int[] array = new int[] {2,3};
	        when(employeeService.nonWorkingCountOfEverydayMonth(managerId)).thenReturn(array);
	        mockMvc.perform(get("/nonWorkingCountOfEverydayMonth/{managerId}","1001")
	            .contentType(MediaType.APPLICATION_JSON))
	            .andExpect(status().isOk()) ;      
	}
	    @Test
	    void testWorkAnniversariesByManagerId() throws Exception{
	    
	    final List<EmployeeDTO> mockEmployeeDetailsList = new ArrayList<>();
	    String managerId = "2001";
	    mockEmployeeDetailsList.add(new EmployeeDTO("123", "1001","John Doe", "Manager",LocalDate.parse("2023-09-14", DateTimeFormatter.ofPattern(datePattern)),"2001","Anil","john@doe.com",LocalDate.parse("2000-09-14", DateTimeFormatter.ofPattern(datePattern))));
	    when(employeeService.workAnniversaryToday(managerId)).thenReturn(mockEmployeeDetailsList);
	    mockMvc.perform(get("/workAnniversariesByManagerId/{managerId}","2001")
	            .contentType(MediaType.APPLICATION_JSON))
	            .andExpect(status().isOk())  
	            .andExpect(jsonPath("$[0].managerId").value("2001"));      
	}
	    
	    @Test
	    void testWorkAnniversariesByManagerIdValidationErrors() throws Exception{
	        
	        final EmployeeDTO employeeDTO = new EmployeeDTO(" "," ","John Doe", "Manager",LocalDate.parse("2023-09-14", DateTimeFormatter.ofPattern(datePattern))," ","Anil","john@doe.com",LocalDate.parse("2000-09-14", DateTimeFormatter.ofPattern(datePattern)));
	        
	        final ObjectMapper objectMapper =new ObjectMapper();
	        objectMapper.registerModule(new JavaTimeModule());
	        
	        final String employeeDTOJSON = objectMapper.writeValueAsString(employeeDTO);
	        
	        final MvcResult result = mockMvc.perform(get("/workAnniversariesByManagerId/{managerId}","2001")
	                .contentType(MediaType.APPLICATION_JSON)
	                .content(employeeDTOJSON))
	        .andReturn();
	        final int statusCode = result.getResponse().getStatus();
	        assertEquals(HttpStatus.BAD_REQUEST.value(), statusCode);
	    }
	    
	    @Test
	    void testManagerInsight5() throws Exception{
	    
	    final List<EmployeeDTO> mockEmployeeDetailsList = new ArrayList<>();
	    String managerId = "2001";
	    mockEmployeeDetailsList.add(new EmployeeDTO("123", "1001","John Doe", "Manager",LocalDate.parse("2023-09-14", DateTimeFormatter.ofPattern(datePattern)),"2001","Anil","john@doe.com",LocalDate.parse("2000-09-14", DateTimeFormatter.ofPattern(datePattern))));
	    when(employeeService.EmpsBirthdayUpcoming(managerId)).thenReturn(mockEmployeeDetailsList);
	    mockMvc.perform(get("/ManagerInsight5/{managerId}","2001")
	            .contentType(MediaType.APPLICATION_JSON))
	            .andExpect(status().isOk())  
	            .andExpect(jsonPath("$[0].managerId").value("2001"));      
	}
	    
	    @Test
	    void testManagerInsight5ByManagerIdValidationErrors() throws Exception{
	        
	        final EmployeeDTO employeeDTO = new EmployeeDTO(" "," ","John Doe", "Manager",LocalDate.parse("2023-09-14", DateTimeFormatter.ofPattern(datePattern))," ","Anil","john@doe.com",LocalDate.parse("2000-09-14", DateTimeFormatter.ofPattern(datePattern)));
	        
	        final ObjectMapper objectMapper =new ObjectMapper();
	        objectMapper.registerModule(new JavaTimeModule());
	        
	        final String employeeDTOJSON = objectMapper.writeValueAsString(employeeDTO);
	        
	        final MvcResult result = mockMvc.perform(get("/ManagerInsight5/{managerId}","2001")
	                .contentType(MediaType.APPLICATION_JSON)
	                .content(employeeDTOJSON))
	        .andReturn();
	        final int statusCode = result.getResponse().getStatus();
	        assertEquals(HttpStatus.BAD_REQUEST.value(), statusCode);
	    }
	    
}