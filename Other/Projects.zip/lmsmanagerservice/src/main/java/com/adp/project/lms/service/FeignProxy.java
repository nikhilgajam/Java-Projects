package com.adp.project.lms.service;

import java.util.List;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import com.adp.project.lms.model.LeaveTransaction;
import com.adp.project.lms.model.SubLeaveUpdate;

@FeignClient(name="LEAVE-TRANSACTION-SERVICE")
public interface FeignProxy {
	
	@PostMapping("/managerPendingRequests/{manid}")
	public List<LeaveTransaction> managerPending(@PathVariable Integer manid);
	
	@PostMapping("/managerAcceptOrReject")
	public SubLeaveUpdate managerCommentsUpdate(@RequestBody SubLeaveUpdate leave);
	
}
