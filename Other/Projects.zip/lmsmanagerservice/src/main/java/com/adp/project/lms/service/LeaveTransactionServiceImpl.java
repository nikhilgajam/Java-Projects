package com.adp.project.lms.service;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.adp.project.lms.model.LeaveTransaction;
import com.adp.project.lms.model.SubLeaveUpdate;

@Service
public class LeaveTransactionServiceImpl implements LeaveTransactionService {
	
	@Autowired
	FeignProxy proxy;

	@Override
	public List<LeaveTransaction> showPendingLeaves(int manager_id) {
		return proxy.managerPending(manager_id);
	}

	@Override
	public void acceptOrReject(SubLeaveUpdate leave) {
		proxy.managerCommentsUpdate(leave);
	}

}
