package com.adp.project.lms.service;

import java.util.List;
import com.adp.project.lms.model.LeaveTransaction;
import com.adp.project.lms.model.SubLeaveUpdate;

public interface LeaveTransactionService {
	
	public List<LeaveTransaction> showPendingLeaves(int manager_id);
	public void acceptOrReject(SubLeaveUpdate leave);
	
}
