package com.adp.project.lms;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.adp.project.lms.model.LeaveTransaction;
import com.adp.project.lms.model.SubLeaveUpdate;
import com.adp.project.lms.service.LeaveTransactionService;
import org.springframework.cloud.client.loadbalancer.LoadBalanced;

@RestController
@RequestMapping("/manager")
public class LmsController {
	
	@Autowired
	LeaveTransactionService lt_ser;
	
	@PostMapping("/managerPendingRequests/{manid}")
	public ResponseEntity<List<LeaveTransaction>> managerPending(@PathVariable Integer manid) {
		return new ResponseEntity<>(lt_ser.showPendingLeaves(manid), HttpStatus.OK);
	}
	
	@PostMapping("/managerAcceptOrReject")
	public ResponseEntity<SubLeaveUpdate> managerCommentsUpdate(@RequestBody SubLeaveUpdate leave) {
		/*
		 * {
		 *	leaveid: 1011,
		 *	status: "Accepted",
		 *	comments: "You may proceed"
		 * }
		 */
		lt_ser.acceptOrReject(leave);
		
		return new ResponseEntity<>(leave, HttpStatus.CREATED);
	}
	
}
