package com.example.gateway;

import org.springframework.cloud.gateway.route.RouteLocator;
import org.springframework.cloud.gateway.route.builder.RouteLocatorBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class Configurations {
	
	@Bean
	public RouteLocator getLocators(RouteLocatorBuilder builder) {
		return builder.routes()
					  .route(p -> p.path("/producer/**").uri("lb://PRODUCER-SERVICE/producer"))
					  .route(p -> p.path("/consumer/**").uri("lb://CONSUMER-SERVICE/consumer"))
					  .build();
	}
}


