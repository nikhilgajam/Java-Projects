package exception_handling;

class SalaryException extends Exception {
	public SalaryException(String msg) {
		super(msg);
	}
}

public class EmployeeException {
	public static void main(String[] args) {
		salaryCheck(10000);
	}
	
	public static void salaryCheck(int salary) {
		try {
			if(salary < 3000) {
				throw new SalaryException("Salary should be greater than 3000");
			}else {
				System.out.println("Salary: " + salary);
			}
		}catch(Exception e) {
			System.out.println(e);
		}
	}
}
