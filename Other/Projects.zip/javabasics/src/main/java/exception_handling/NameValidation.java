package exception_handling;

public class NameValidation {
	public static void main(String[] args) {
		nameValidation("Ram", "Raj");
	}
	
	public static void nameValidation(String first_name, String last_name) {
		try {
			if(first_name.isEmpty()) {
				throw new BlankStringException("Your first_name should not be blank");
			}
			
			if(last_name.isEmpty()) {
				throw new BlankStringException("Your last_name should not be blank");
			}
			
			System.out.println(first_name + " " + last_name);
		}catch (BlankStringException e) {
			System.out.println(e);
		}
	}
}
