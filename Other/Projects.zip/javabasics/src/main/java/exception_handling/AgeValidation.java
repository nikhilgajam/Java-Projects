package exception_handling;

public class AgeValidation {
	public static void main(String[] args) {
		ageValidation(1);
	}
	
	public static void ageValidation(int age) {
		try {
			if(age >= 18) {
				System.out.println("Your age is validated");
			}else {
				throw new AgeException("Your age must be 18 or greater");
			}
		}catch(AgeException e) {
			System.out.println(e);
		}
	}
	
}
