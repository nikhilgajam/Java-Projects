package exception_handling;

public class AgeException extends Exception{
	public AgeException(String msg) {
		super(msg);
	}
}
