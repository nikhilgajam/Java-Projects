package exception_handling;

public class BlankStringException extends Exception{
	public BlankStringException(String msg) {
		super(msg);
	}
}
