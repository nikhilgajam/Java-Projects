package javabasicproblems;

import java.util.Arrays;

public class MovePositiveAndNegativeNumbers {

	public static void main(String[] args) {
		int[] arr = {-2, 3, 4, -1, -3, 1, 2, -4, 0};
		movePosToRightAndNegToLeft(arr);
	}
	
	public static void movePosToRightAndNegToLeft(int[] arr) {
		
		Arrays.sort(arr);
		System.out.println(Arrays.toString(arr));
	}

}
