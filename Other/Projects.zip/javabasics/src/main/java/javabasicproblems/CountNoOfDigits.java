package javabasicproblems;

import java.util.Scanner;

public class CountNoOfDigits {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		System.out.print("Input an integer number less than ten billion: ");
		int n = scan.nextInt();
		countDigits(n);
		scan.close();
	}
	
	public static void countDigits(int num) {
		String s = num + "";
		System.out.println("Number of digits in the number: " + s.length());
	}

}
