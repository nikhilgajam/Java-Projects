package javabasicproblems;

import java.util.Scanner;

public class TransformIntToString {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		System.out.print("Input an integer: ");
		int n = scan.nextInt();
		System.out.println("String format of the said integer: " + Integer.toString(n));
		scan.close();
	}

}
