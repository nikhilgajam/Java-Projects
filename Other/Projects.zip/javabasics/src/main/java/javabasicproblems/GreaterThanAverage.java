package javabasicproblems;

public class GreaterThanAverage {

	public static void main(String[] args) {
		int[] arr = {1, 4, 17, 7, 25, 3, 100};
		greaterThanAverage(arr);
	}
	
	public static void greaterThanAverage(int[] arr) {
		int n = arr.length;
		int sum = 0;
		for(int i=0; i<n; i++) {
			sum += arr[i];
		}
		
		double avg = sum/n;
		System.out.println("The average of the said array is: " + avg);
		System.out.println("The numbers in the said array that are greater than the average are:");
		for(int i: arr) {
			if(i > avg) {
				System.out.println(i);
			}
		}
	}

}
