package javabasicproblems;

import java.util.Arrays;

public class KthSmallestAndLargest {

	public static void main(String[] args) {
		int[] arr = {1, 4, 17, 7, 25, 3, 100};
		kthSmallLarge(arr, 2);
	}
	
	public static void kthSmallLarge(int[] arr, int k) {
		Arrays.sort(arr);
		System.out.println(arr[k-1]);
		System.out.println(arr[arr.length-k]);
	}

}
