package javabasicproblems;

import java.util.Scanner;

public class MultiplyWithoutMultiplicationOperator {
	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		System.out.print("Input the first number: ");
		int n1 = scan.nextInt();
		System.out.print("Input the second number: ");
		int n2 = scan.nextInt();
		multiplyWithoutOperator(n1, n2);
		scan.close();
	}
	
	public static void multiplyWithoutOperator(int n1, int n2) {
		int ans = 0;
		for(int i=0; i<n2; i++) {
			ans += n1;
		}
		
		System.out.println("Result: " + ans);
	}
}
