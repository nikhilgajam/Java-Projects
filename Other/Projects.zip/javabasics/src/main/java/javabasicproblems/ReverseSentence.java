package javabasicproblems;

import java.util.Scanner;

public class ReverseSentence {
	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		System.out.print("Input a string: ");
		String str = scan.nextLine();
		reverseSentence(str);
		scan.close();
	}
	
	public static void reverseSentence(String str) {
		String[] str_arr = str.split(" ");
		for(int i=str_arr.length-1; i>=0; i--) {
			System.out.print(str_arr[i] + " ");
		}
	}
}
