package javabasicproblems;

import java.util.Arrays;

public class kLargestElements {
	
	public static void main(String[] args) {
		int[] arr = {1, 4, 17, 7, 25, 3, 100};
		kLargest(arr, 3);
	}
	
	public static void kLargest(int[] arr, int k) {
		Arrays.sort(arr);
		for(int i=arr.length-1; i>k; i--) {
			System.out.print(arr[i] + " ");
		}
	}

}
