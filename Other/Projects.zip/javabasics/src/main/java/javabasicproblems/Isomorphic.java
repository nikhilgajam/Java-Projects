package javabasicproblems;

import java.util.LinkedHashSet;

public class Isomorphic {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		LinkedHashSet<Character> set = new LinkedHashSet<>();
		String s1 = "ABACB";
		String s2 = "XPZ";
	}

}
