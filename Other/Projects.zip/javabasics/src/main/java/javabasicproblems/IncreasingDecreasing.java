package javabasicproblems;

import java.util.Scanner;

public class IncreasingDecreasing {
	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		System.out.print("Input first number: ");
		int n1 = scan.nextInt();
		System.out.print("Input second number: ");
		int n2 = scan.nextInt();
		System.out.print("Input third number: ");
		int n3 = scan.nextInt();
		increasingDecreasing(n1, n2, n3);
		scan.close();
	}
	
	public static void increasingDecreasing(int a, int b, int c) {
		if(b > a && c > b) {
			System.out.println("Increasing order");
		}else if(b < a && c < b) {
			System.out.println("Decreasing order");
		}else {
			System.out.println("Neither increasing or decreasing order");
		}
	}
}
