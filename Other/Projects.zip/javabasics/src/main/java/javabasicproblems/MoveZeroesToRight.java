package javabasicproblems;

import java.util.Arrays;

public class MoveZeroesToRight {

	public static void main(String[] args) {
		int[] arr = {0, 3, 4, 0, 1, 2, 5, 0};
		moveZeroesToRight(arr);
	}
	
	public static void moveZeroesToRight(int[] arr){
		System.out.println(Arrays.toString(arr));
		
		int[] ans = new int[arr.length];
		
		int j=0;
		for(int i=0; i<ans.length; i++) {
			if(arr[i] != 0) {
				ans[j++] = arr[i];
			}
		}
		
		System.out.println(Arrays.toString(ans));
	}

}
