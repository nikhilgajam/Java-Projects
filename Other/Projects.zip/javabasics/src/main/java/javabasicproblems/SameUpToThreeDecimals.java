package javabasicproblems;

import java.util.Scanner;

public class SameUpToThreeDecimals {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		System.out.print("Input floating-point number: ");
		float n1 = scan.nextFloat();
		System.out.print("Input floating-point another number: ");
		float n2 = scan.nextFloat();
		checkUpToThreeDecimals(n1, n2);
		scan.close();
	}
	
	public static void checkUpToThreeDecimals(float n1, float n2) {
		String s1 = n1 + "";
		String s2 = n2 + "";
		s1 = s1.substring(0, s1.indexOf('.')+4);
		s2 = s2.substring(0, s2.indexOf('.')+4);
		
		if(s1.equals(s2)) {
			System.out.println("They are same");
		}else {
			System.out.println("They are different");
		}
	}

}
