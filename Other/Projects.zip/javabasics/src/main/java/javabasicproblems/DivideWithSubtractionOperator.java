package javabasicproblems;

import java.util.Scanner;

public class DivideWithSubtractionOperator {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		System.out.print("Input the dividend: ");
		int n1 = scan.nextInt();
		System.out.print("Input the divide: ");
		int n2 = scan.nextInt();
		divideWithSubtractionOperator(n1, n2);
		scan.close();
	}
	
	public static void divideWithSubtractionOperator(int dividend, int divider) {
		int quotient = 0;
		while(dividend > 0) {
			quotient++;
			dividend -= divider;
		}
		
		System.out.println("Result: " + quotient);
	}

}
