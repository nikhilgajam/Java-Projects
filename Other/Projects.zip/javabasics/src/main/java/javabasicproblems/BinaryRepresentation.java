package javabasicproblems;

public class BinaryRepresentation {

	public static void main(String[] args) {
		binaryZeroCount(100);
	}
	
	public static void binaryZeroCount(int n) {
		System.out.println("Input first number: " + n);
		String bin = Integer.toBinaryString(n);
		System.out.println("Binary representation of " + n + "is: " + bin);
		int count = 0;
		for(int i=0; i<bin.length(); i++) {
			if(bin.charAt(i) == '0') {
				count++;
			}
		}
		
		System.out.println("Number of zero bits: " + count);
	}

}
