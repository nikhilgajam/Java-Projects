package practicequestionsarrays;

import java.util.Stack;

public class BracketPairOrder {
	public static void main(String[] args) {
		char[] arr = {'{', '}','(', ')', '[', ']'};
		System.out.println(bracketOrder(arr));
	}
	
	public static boolean bracketOrder(char[] arr) {
		Stack<Character> stack = new Stack<>();
		
		for(int i=0; i<arr.length; i++) {
			if(arr[i] == '{' || arr[i] == '(' || arr[i] == '[') {
				stack.push(arr[i]);
			}else {
				if(!stack.isEmpty()) {
					if(arr[i] == '}' && stack.peek() == '{') {
						stack.pop();
					}else if(arr[i] == ')' && stack.peek() == '(') {
						stack.pop();
					}else if(arr[i] == ']' && stack.peek() == '[') {
						stack.pop();
					}else {
						return false;
					}
				}else {
					return false;
				}
				
			}
		}
		
		return stack.isEmpty();
	}
}
