package practicequestionsarrays;

import java.util.*;

public class UnionIntersection {
	public static void main(String[] args) {
		int arr1[] = {1, 3, 4, 5, 7};
        int arr2[] = {2, 3, 5, 6};
        Union(arr1, arr2);
        Intersection(arr1, arr2);
	}
	
	public static void Union(int[] arr1, int[] arr2) {
		HashSet<Integer> set = new HashSet<>();
		for(int i: arr1)
			set.add(i);
		for(int i: arr2)
			set.add(i);
			
		System.out.println(set);
	}
	
	public static void Intersection(int[] arr1, int[] arr2) {
		HashSet<Integer> set = new HashSet<>();
		HashSet<Integer> ans = new HashSet<>();
		
		for(int i: arr1)
			set.add(i);
		
		for(int i: arr2) {
			if(set.contains(i))
				ans.add(i);
		}
		
		System.out.println(ans);
	}
}
