package practicequestionsarrays;

public class MedianOfTwoArrays {

	public static void main(String[] args) {
		int[] arr1 = {1, 2, 3};
		int[] arr2 = {4, 5, 6};   // 1 2 3 4 5 6
		medianOfTwoArrays(arr1, arr2);

	}
	
	public static void medianOfTwoArrays(int[] arr1, int[] arr2) {
		int n_sum = arr1.length + arr2.length;
		int[] merged_arr = new int[n_sum];
		
		int j = 0;
		for(int i: arr1) {
			merged_arr[j++] = i;
		}
		
		for(int i: arr2) {
			merged_arr[j++] = i;
		}
		
		int median = n_sum/2;
		
		if(n_sum%2 == 0) {
			double avg = (merged_arr[median-1] + merged_arr[median])/2.0;
			System.out.println(avg);
		}else {
			System.out.println("Median: " + merged_arr[median]);
		}
	}

}
