package practicequestionsarrays;

public class Fibonacci {

	public static void main(String[] args) {
		System.out.println(fibonacci(10));
		System.out.println(fib(10));
	}
	
	public static long fibonacci(int n) {
		int a=0, b=1, c=0;
		for(int i=0; i<=n; i++) {
			a = a+b;
			b = c;
			c = a;
		}
		
		return a;
	}
	
	public static long fib(int n) {
		if(n <= 2)
			return n;
		return fib(n-1)+fib(n-2);
	}
}
