package practicequestionsarrays;

public class CharacterCount {

	public static void main(String[] args) {
		characterCount("string");
	}
	
	public static void characterCount(String str) {
		str = str.toUpperCase();
		int[] count = new int[26];
		
		for(int i=0; i<str.length(); i++) {
			int ch = str.charAt(i) - 65;
			count[ch]++;
		}
		
		for(int i=0; i<count.length; i++) {
			char ch = (char)(i+65);
			System.out.println(ch + " : " + count[i]);
		}
	}

}
