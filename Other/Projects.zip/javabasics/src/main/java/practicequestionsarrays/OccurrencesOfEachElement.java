package practicequestionsarrays;

import java.util.HashMap;

public class OccurrencesOfEachElement {

	public static void main(String[] args) {
		Integer[] arr = {1, 2, 3, 1};
		countOccurrences(arr);
	}
	
	public static void countOccurrences(Object[] arr) {
		HashMap<Object, Integer> map = new HashMap<>();
		for(Object i: arr) {
			map.put(i, map.getOrDefault(i, 0)+1);
		}
		
		System.out.println(map);
	}

}
