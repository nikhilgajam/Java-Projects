package practicequestionsarrays;

public class LongestCommonPrefix {

	public static void main(String[] args) {
		String[] arr = {"who", "where", "what"};
		System.out.println(longestCommonPrefix(arr));
	}
	
	public static String longestCommonPrefix(String[] arr) {
		String ans = arr[0];
		
		for(int i=0; i<arr.length; i++) {
			while(arr[i].indexOf(ans) != 0) {
				ans = ans.substring(0, ans.length()-1);
				
				if(ans.isEmpty()) {
					return "-1";
				}
			}
		}
		
		return ans;
	}
	
}
