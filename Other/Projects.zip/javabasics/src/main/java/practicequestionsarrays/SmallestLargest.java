package practicequestionsarrays;

public class SmallestLargest {

	public static void main(String[] args) {
		int[] arr = {2, 3, 4, 1, 2, 1, 5, 3, 10};
		smallestLargest(arr);
	}
	
	public static void smallestLargest(int[] arr) {
		int min = Integer.MAX_VALUE;
		int max = Integer.MIN_VALUE;
		
		for(int i: arr) {
			if(i < min)
				min = i;
			if(i > max)
				max = i;
		}
		
		System.out.println("Minimum: " + min);
		System.out.println("Maximum: " + max);
	}

}
 