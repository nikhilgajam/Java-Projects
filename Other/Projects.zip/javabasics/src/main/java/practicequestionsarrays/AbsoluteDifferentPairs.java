package practicequestionsarrays;

public class AbsoluteDifferentPairs {
	public static void main(String[] args) {
		int[] arr = {1, 2, 3, 4};
		System.out.println(absoluteDifferentPairs(arr));
	}
	
	public static int absoluteDifferentPairs(int[] arr) {
		int sum = 0;
		for(int i=0; i<arr.length; i++) {
			for(int j=i+1; j<arr.length; j++) {
				sum += Math.abs(arr[j]-arr[i]);
			}
		}
		
		return sum;
	}
}
