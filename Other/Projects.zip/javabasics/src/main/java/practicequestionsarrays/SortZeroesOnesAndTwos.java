package practicequestionsarrays;

import java.util.Arrays;

public class SortZeroesOnesAndTwos {
	public static void main(String[] args) {
		int[] arr = {0, 1, 1, 0, 1, 2, 1, 2, 0, 0, 0, 1};
		sort(arr);
	}
	
	public static void sort(int[] A) {
		int z=0, o=0, t=0;
		for(int i=0; i<A.length; i++) {
			if(A[i] == 0) {
				z++;
			}else if(A[i] == 1) {
				o++;
			}else if(A[i] == 2){
				t++;
			}
		}
		
		for(int i=0; i<A.length; i++) {
			if(z > 0) {
				A[i] = 0;
				z--;
			}else if(o > 0) {
				A[i] = 1;
				o--;
			}else if(t > 0){
				A[i] = 2;
				t--;
			}
		}
		
		System.out.println(Arrays.toString(A));
		
	}
}
