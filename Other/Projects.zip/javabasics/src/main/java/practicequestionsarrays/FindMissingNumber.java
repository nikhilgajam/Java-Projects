package practicequestionsarrays;

public class FindMissingNumber {
	public static void main(String[] args) {
		int[] arr = {1,2,3,4,6};
		System.out.println(findMissingNumber(arr));
	}
	
	public static long findMissingNumber(int[] arr) {
		int n = arr.length+1;
		long actualSum = (n*(n+1))/2;
		long sum = 0;
		for(int i: arr) {
			sum += i;
		}
		
		long ans = actualSum-sum;
		
		return ans;
	}
}
