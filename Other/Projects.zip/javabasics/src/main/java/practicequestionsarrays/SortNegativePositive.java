package practicequestionsarrays;

import java.util.Arrays;

public class SortNegativePositive {
	public static void main(String[] args) {
		int[] arr = {-12, 11, -13, -5, 6, -7, 5, -3, -6};
		sortNegativePositive(arr);
	}
	
	public static void sortNegativePositive(int[] arr) {
		int[] ans = new int[arr.length];
		
		int j=0;
		for(int i=0; i<arr.length; i++) {
			if(arr[i] < 0)
				ans[j++] = arr[i];
		}
		
		for(int i=0; i<arr.length; i++) {
			if(arr[i] > 0)
				ans[j++] = arr[i];
		}
		
		System.out.println(Arrays.toString(ans));
	}
}
