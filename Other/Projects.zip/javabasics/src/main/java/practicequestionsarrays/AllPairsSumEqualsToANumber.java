package practicequestionsarrays;

public class AllPairsSumEqualsToANumber {
	public static void main(String[] args) {
		int[] arr = {1, 2, 3, 4};
		System.out.println(allPairsSumEqualsToNumber(arr, 5));
	}
	
	public static int allPairsSumEqualsToNumber(int[] arr, int k) {
		int count = 0;
		for(int i: arr) {
			for(int j: arr) {
				if(i+j == k)
					count++;
			}
		}
		
		return count;
	}
}
