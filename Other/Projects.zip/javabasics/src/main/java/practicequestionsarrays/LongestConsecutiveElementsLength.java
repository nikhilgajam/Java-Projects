package practicequestionsarrays;

import java.util.HashSet;

public class LongestConsecutiveElementsLength {

	public static void main(String[] args) {
		int arr[] = {36, 41, 56, 35, 44, 33, 34, 92, 43, 32, 42};
		System.out.println(longestConsecutiveElementsLength(arr));
	}
	
	public static int longestConsecutiveElementsLength(int[] arr) {
		HashSet<Integer> set = new HashSet<>();
		int ans = 0;
		
		for(int i: arr) {
			set.add(i);
		}
		
		for(int i=0; i<arr.length; i++) {
			int num = arr[i];
			if(!set.contains(num-1)) {
				int count = 0;
				while(set.contains(num)) {
					num++;
					count++;
				}
				ans = Math.max(ans, count);
			}
		}
		
		return ans;
	}

}
