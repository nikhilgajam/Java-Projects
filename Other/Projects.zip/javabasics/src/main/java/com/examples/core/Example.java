package com.examples.core;

public class Example {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] arr = new int[3];
		System.out.println(arr);
	}

}
