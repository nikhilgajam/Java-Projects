package collections_framework;

import java.util.*;
import java.time.LocalDate;

public class VoterEligibility {

	public static void main(String[] args) {
		HashMap<Integer, LocalDate> map = new HashMap<>();
		map.put(1, LocalDate.parse("1981-01-10"));
		map.put(2, LocalDate.now());
		System.out.println(votersList(map));
	}
	
	public static List<Integer> votersList(Map<Integer, LocalDate> map) {
		ArrayList<Integer> list = new ArrayList<>();
		LocalDate current = LocalDate.now();
		
		for(Map.Entry<Integer, LocalDate> e: map.entrySet()) {
			int id = e.getKey();
			LocalDate date = e.getValue();
			int age = current.getYear() - date.getYear();
			if(age >= 18) {
				list.add(id);
			}
		}
		
		return list;
	}

}
