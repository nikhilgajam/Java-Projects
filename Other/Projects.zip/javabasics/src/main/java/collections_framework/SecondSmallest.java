package collections_framework;

import java.util.*;

public class SecondSmallest {

	public static void main(String[] args) {
		int[] arr = {1, 3, 2, 4, 5, 6, 7, 8};
		System.out.println(getSecondSmallest(arr));
	}
	
	public static int getSecondSmallest(int[] arr) {
		if(arr.length < 2)
			return -1;
		
		ArrayList<Integer> list = new ArrayList<>();
		for(int i: arr) {
			list.add(i);
		}
		
		Collections.sort(list);
		
		return list.get(1);
	}

}
