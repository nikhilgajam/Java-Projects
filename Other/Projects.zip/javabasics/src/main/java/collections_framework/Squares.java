package collections_framework;

import java.util.*;

public class Squares {

	public static void main(String[] args) {
		int[] arr = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10};
		System.out.println(getSquares(arr));
	}
	
	public static Map<Integer, Integer> getSquares(int[] arr) {
		HashMap<Integer, Integer> hm = new HashMap<>();
		for(int i: arr) {
			hm.put(i, i*i);
		}
		
		return hm;
	}
}
