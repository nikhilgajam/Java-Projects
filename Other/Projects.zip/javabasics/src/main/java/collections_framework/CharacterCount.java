package collections_framework;

import java.util.*;

public class CharacterCount {

	public static void main(String[] args) {
		char[] arr = "Java Strings".toCharArray();
		System.out.println(charCount(arr));
	}
	
	public static Map<Character, Integer> charCount(char[] arr) {
		HashMap<Character, Integer> map = new HashMap<>();
		for(char c: arr) {
			map.put(c, map.getOrDefault(c, 0) + 1);
		}
		
		return map;
	}

}
