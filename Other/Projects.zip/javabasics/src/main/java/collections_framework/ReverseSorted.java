package collections_framework;

import java.util.*;

public class ReverseSorted {
	public static void main(String[] args) {
		int[] arr = {789, 123, 111, 1000, 998};
		int[] ans = getSorted(arr);
		System.out.println(Arrays.toString(ans));
	}
	
	public static int reverse(int num) {
		int n, r=0;
		while(num > 0) {
			n = num%10;
			r = r*10+n;
			num /= 10;
		}
		
		return r;
	}
	
	public static int[] getSorted(int[] arr) {
		int[] ans = new int[arr.length];
		for(int i=0; i<arr.length; i++) {
			ans[i] = reverse(arr[i]);
		}
		
		Arrays.sort(ans);
		
		return ans;
	}
}
