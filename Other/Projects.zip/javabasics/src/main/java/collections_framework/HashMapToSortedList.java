package collections_framework;

import java.util.*;

public class HashMapToSortedList {

	public static void main(String[] args) {
		HashMap<Integer, Integer> hm = new HashMap<>();
		hm.put(1, 2);
		hm.put(2, 1);
		hm.put(100, 1000);
		System.out.println(hashMapToSortedList(hm));
	}
	
	public static List<Integer> hashMapToSortedList(HashMap<Integer, Integer> hm) {
		ArrayList<Integer> list = new ArrayList<>();
		for(Map.Entry<Integer, Integer> entry: hm.entrySet()) {
			list.add(entry.getValue());
		}
		Collections.sort(list);
		return list;
	}
}
