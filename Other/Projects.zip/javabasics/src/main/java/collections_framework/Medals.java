package collections_framework;

import java.util.*;

public class Medals {
	public static void main(String[] args) {
		HashMap<Integer, Integer> hm = new HashMap<>();
		hm.put(1, 99);
		hm.put(2, 80);
		hm.put(3, 70);
		hm.put(4, 75);
		hm.put(5, 99);
		System.out.println(getStudents(hm));
	}
	
	public static Map<Integer, String> getStudents(Map<Integer, Integer> map) {
		HashMap<Integer, String> hm = new HashMap<>();
		for(Map.Entry<Integer, Integer> e: map.entrySet()) {
			int regid = e.getKey();
			int marks = e.getValue();
			if(marks >= 90) {
				hm.put(regid, "Gold");
			}else if(marks < 90 && marks >= 80) {
				hm.put(regid, "Silver");
			}else if(marks < 80 && marks >= 70) {
				hm.put(regid, "Bronze");
			}
		}
		
		return hm;
	}
}
