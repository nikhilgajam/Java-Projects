package lambda;

public class MethodReference {
	
	public static void main(String[] args) {
		ReferredInterface ri = ReferredClass::new;
		ReferredClass rc = ri.createInstance(100, 1000);
		System.out.println(rc);
	}
}

interface ReferredInterface {
	ReferredClass createInstance(int a, int b);
}

class ReferredClass{
	public int a, b;
	
	public ReferredClass(int a, int b) {
		this.a = a;
		this.b = b;
	}
	public int getA() {
		return a;
	}
	public void setA(int a) {
		this.a = a;
	}
	public int getB() {
		return b;
	}
	public void setB(int b) {
		this.b = b;
	}
	@Override
	public String toString() {
		return "ReferredClass [a=" + a + ", b=" + b + "]";
	}
	
}
	