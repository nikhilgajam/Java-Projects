package lambda;

import java.util.function.Function;

public class LambdaSpace {
	public static void main(String[] args) {
		Function<String, String> function = str -> {
			String ans = "";
			for(int i=0; i<str.length(); i++) {
				ans += str.charAt(i) + " ";
			}
			
			return ans.substring(0, ans.length()-1);
		};
		
		System.out.println(function.apply("CG"));
		
	}
}
