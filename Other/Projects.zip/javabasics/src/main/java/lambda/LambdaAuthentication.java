package lambda;

import java.util.function.BiPredicate;

public class LambdaAuthentication {

	public static void main(String[] args) {
		BiPredicate<String, String> predicate = (usr, pwd) -> usr.equals("admin") && pwd.equals("admin");
		System.out.println(predicate.test("admin", "admin"));
	}

}
