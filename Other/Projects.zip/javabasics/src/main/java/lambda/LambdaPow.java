package lambda;

import java.util.function.*;

public class LambdaPow {
	public static void main(String[] args) {
		BiFunction<Double, Double, Double> function = (n1, n2) -> Math.pow(n1, n2);
		System.out.println(function.apply(3.0, 3.0));
	}
}
