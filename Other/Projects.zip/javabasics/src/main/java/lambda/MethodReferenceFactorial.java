package lambda;

public class MethodReferenceFactorial {
	public static void main(String[] args) {
		FactorialInterface fact = Factorial::factorial;
		System.out.println(fact.factorial(10));
	}
}

interface FactorialInterface {
	long factorial(int n);
}

class Factorial{
	public static long factorial(int n) {
		long ans = 1;
		for(int i=1; i<=n; i++) {
			ans *= i;
		}
		
		return ans;
	}
}
