package com.adp.leave_management_system.dao;

import com.adp.leave_management_system.model.LeaveBalancesTable;
import com.adp.leave_management_system.model.LeaveTransaction;

public class Methods {
	public static void insert(LeaveBalancesTable obj, int leave_id, String status, String reason, String comments) {
		
	}
	
	public static void insert(LeaveTransaction obj) {
		
	}
}
