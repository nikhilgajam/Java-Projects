package com.adp.leave_management_system.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import com.adp.leave_management_system.model.LeaveBalancesTable;
import com.adp.leave_management_system.model.LeaveTransaction;
import com.adp.leave_management_system.utils.Dbconnections;
import com.adp.leave_management_system.utils.JpaImplementation;

public class ManagerDaoImpl implements IManagerDao {

	@Override
	public boolean approveOrRejectLeave(int leave_id, String status, String comments) {
		try {
			EntityManager em = JpaImplementation.getEntityManager();
			
//			String q = "from LeaveTransaction where leave_id = " + leave_id;
//			Query query = em.createQuery(q);
			LeaveTransaction lt = em.find(LeaveTransaction.class, leave_id);
			System.out.println(lt);
			
			if(lt == null) {
				return false;
			}
			
			int employee_id = lt.getEmployeeid();
			int leavecount = lt.getLeavecount();
			String leavetype = lt.getLeavetype().toLowerCase();
			
			em.getTransaction().begin();
			LeaveTransaction lts = em.find(LeaveTransaction.class, leave_id);
			lts.setStatus(status);
			lts.setComments(comments);
			em.persist(lts);
//			em.getTransaction().commit();
			
//			System.out.println(status + " " + (status.equals("Approved")) + (!status.equals("Approved")));
			if(!status.equals("Approved")) {
				return true;
			}
			
			int count = 1;
				
			String q = "select " + leavetype + " from LeaveBalancesTable where employeeid = " + employee_id;
			Query query = em.createQuery(q);
			System.out.println(query.getSingleResult());
			
			Integer remaining_leaves = (Integer) query.getSingleResult();
			
			int new_remaining_leaves = remaining_leaves - leavecount;
			
			if(new_remaining_leaves >= 0) {
//				q = "from LeaveBalancesTable set " + leavetype + " = " + new_remaining_leaves + " where employee_id = " + employee_id;
				q = "from LeaveBalancesTable";
				query = em.createQuery(q);
				List<LeaveBalancesTable> search_list = query.getResultList();
				LeaveBalancesTable lbt = new LeaveBalancesTable();
				
				for(int i=0; i<search_list.size(); i++) {
					LeaveBalancesTable t = search_list.get(i);
					if(t.getEmployeeid() == employee_id) {
						lbt = t;
						break;
					}
				}
				
				if(leavetype.equals("sickleaves")) {
					lbt.setSickleaves(new_remaining_leaves);
				}else if(leavetype.equals("maternityleaves")) {
					lbt.setMaternityleaves(new_remaining_leaves);
				}else if(leavetype.equals("paternityleaves")) {
					lbt.setPaternityleaves(new_remaining_leaves);
				}else if(leavetype.equals("privilegedleaves")) {
					lbt.setPrivilegedleaves(new_remaining_leaves);
				}
				
				em.persist(lbt);
				em.getTransaction().commit();
				em.close();
				return true;
			}
			
			return false;
		}catch(Exception e) {
			System.out.println("There's a problem!: " + e);
			return false;
		}
	}

	@Override
	public List<LeaveTransaction> viewPendingRequests(int manager_id) {
		try {
			EntityManager em = JpaImplementation.getEntityManager();
			
			String q = "from LeaveTransaction where status = 'Pending' and managerid = " + manager_id + " order by startdate";
			Query query = em.createQuery(q);
			List<LeaveTransaction> list = query.getResultList();
			em.close();
			return list;
		}catch(Exception e) {
			System.out.println("There's a problem!: " + e);
			return null;
		}
	}
	
}
