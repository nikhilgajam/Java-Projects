package com.adp.leave_management_system.dao;

import java.util.List;
import java.util.Random;

import javax.persistence.Query;
import javax.persistence.TypedQuery;
import javax.persistence.EntityManager;
import com.adp.leave_management_system.model.Employee;
import com.adp.leave_management_system.model.LeaveBalancesTable;
import com.adp.leave_management_system.model.LeaveTransaction;
import com.adp.leave_management_system.utils.JpaImplementation;

public class EmployeeDaoImpl implements IEmployeeDao {

	@Override
	public boolean applyLeave(int employee_id, String startdate, String enddate, int leavecount, String leavetype, String reason) {
		try {
			EntityManager em = JpaImplementation.getEntityManager();
			
			em.getTransaction().begin();
			
			Employee emp = em.find(Employee.class, employee_id);
			
			int leave_id = Math.abs(new Random().nextInt());
			String status = "Pending";
			
			LeaveTransaction lt = new LeaveTransaction();
			
			lt.setLeaveid(leave_id);
			lt.setEmployeeid(employee_id);
			lt.setManagerid(emp.getManagerid());
			lt.setStartdate(startdate);
			lt.setEnddate(enddate);
			lt.setLeavetype(leavetype);
			lt.setLeavecount(leavecount);
			lt.setStatus(status);
			lt.setReason(reason);
			lt.setComments("");
			
			em.persist(lt);
			em.getTransaction().commit();
			em.close();
			
			return true;
		}catch(Exception e) {
			System.out.println("There's a problem!: " + e);
			return false;
		}
	}

	@Override
	public List<LeaveTransaction> employeeLeaveStatus(int employee_id) {
		try {
		EntityManager em = JpaImplementation.getEntityManager();
		
		String q = "from LeaveTransaction where employeeid = " + employee_id;
		Query query = em.createQuery(q);
		List<LeaveTransaction> list = query.getResultList();
		em.close();
		return list;
		}catch(Exception e) {
			System.out.println("There's a problem!: " + e);
			return null;
		}
	}

	@Override
	public List<LeaveBalancesTable> employeeLeaveBalance(int employee_id) {
		EntityManager em = JpaImplementation.getEntityManager();
		
		String q = "from LeaveBalancesTable where employeeid = " + employee_id;
		Query query = em.createQuery(q);
		List<LeaveBalancesTable> list = query.getResultList();
		em.close();
		return list;
	}

}
