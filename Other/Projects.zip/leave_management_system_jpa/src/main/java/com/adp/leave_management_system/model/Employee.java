package com.adp.leave_management_system.model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="season2_batch1_team2_employee")
public class Employee {
	@Id
	private int employeeid;
	private String name;
	private String gender;
	private String department;
	private String position;
	private int managerid;
	private String maritalstatus;
	
	public int getEmployeeid() {
		return employeeid;
	}
	public void setEmployeeid(int employeeid) {
		this.employeeid = employeeid;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getDepartment() {
		return department;
	}
	public void setDepartment(String department) {
		this.department = department;
	}
	public String getPosition() {
		return position;
	}
	public void setPosition(String position) {
		this.position = position;
	}
	public int getManagerid() {
		return managerid;
	}
	public void setManagerid(int managerid) {
		this.managerid = managerid;
	}
	public String getMaritalstatus() {
		return maritalstatus;
	}
	public void setMaritalstatus(String maritalstatus) {
		this.maritalstatus = maritalstatus;
	}
	
	@Override
	public String toString() {
		return "Employee [employeeid=" + employeeid + ", name=" + name + ", gender=" + gender + ", department="
				+ department + ", position=" + position + ", managerid=" + managerid + ", maritalstatus="
				+ maritalstatus + "]";
	}
	
}
