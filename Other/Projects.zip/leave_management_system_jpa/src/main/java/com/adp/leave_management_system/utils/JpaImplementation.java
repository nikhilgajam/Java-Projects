package com.adp.leave_management_system.utils;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class JpaImplementation {
	private static EntityManagerFactory emf = Persistence.createEntityManagerFactory("lms");
	private static EntityManager entity_manager = null;
	
	public static EntityManager getEntityManager() {
		entity_manager = emf.createEntityManager();
		return entity_manager;
	}
	
}
