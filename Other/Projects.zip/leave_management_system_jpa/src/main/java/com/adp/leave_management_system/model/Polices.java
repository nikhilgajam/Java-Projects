package com.adp.leave_management_system.model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="season2_batch1_team2_policies")
public class Polices {
	@Id
	private int leaveid;
	private String leavetype;
	private int totalcount;
	
	
	public int getLeaveid() {
		return leaveid;
	}
	public void setLeaveid(int leaveid) {
		this.leaveid = leaveid;
	}
	public String getLeavetype() {
		return leavetype;
	}
	public void setLeavetype(String leavetype) {
		this.leavetype = leavetype;
	}
	public int getTotalcount() {
		return totalcount;
	}
	public void setTotalcount(int totalcount) {
		this.totalcount = totalcount;
	}
	
	@Override
	public String toString() {
		return "Polices [leaveid=" + leaveid + ", leavetype=" + leavetype + ", totalcount=" + totalcount + "]";
	}
	
}
