package com.adp.leave_management_system.model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="season2_batch1_team2_leavebalancestable")
public class LeaveBalancesTable {
	@Id
	private int employeeid;
	private int sickleaves;
	private int maternityleaves;
	private int paternityleaves;
	private int privilegedleaves;
	
	
	public int getEmployeeid() {
		return employeeid;
	}
	public void setEmployeeid(int employeeid) {
		this.employeeid = employeeid;
	}
	public int getSickleaves() {
		return sickleaves;
	}
	public void setSickleaves(int sickleaves) {
		this.sickleaves = sickleaves;
	}
	public int getMaternityleaves() {
		return maternityleaves;
	}
	public void setMaternityleaves(int maternityleaves) {
		this.maternityleaves = maternityleaves;
	}
	public int getPaternityleaves() {
		return paternityleaves;
	}
	public void setPaternityleaves(int paternityleaves) {
		this.paternityleaves = paternityleaves;
	}
	public int getPrivilegedleaves() {
		return privilegedleaves;
	}
	public void setPrivilegedleaves(int privilegedleaves) {
		this.privilegedleaves = privilegedleaves;
	}
	
	@Override
	public String toString() {
		return "LeaveBalancesTable [employeeid=" + employeeid + ", sickleaves=" + sickleaves + ", maternityleaves="
				+ maternityleaves + ", paternityleaves=" + paternityleaves + ", privilegedleaves=" + privilegedleaves
				+ "]";
	}
	
	
}
