package com.adp.leave_management_system.model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="season2_batch1_team2_leavetransaction")
public class LeaveTransaction {
	@Id
	private int leaveid;
	private int employeeid;
	private int managerid;
	private String startdate;
	private String enddate;
	private String leavetype;
	private int leavecount;
	private String status;
	private String reason;
	private String comments;
	
	
	public int getLeaveid() {
		return leaveid;
	}
	public void setLeaveid(int leaveid) {
		this.leaveid = leaveid;
	}
	public int getEmployeeid() {
		return employeeid;
	}
	public void setEmployeeid(int employeeid) {
		this.employeeid = employeeid;
	}
	public int getManagerid() {
		return managerid;
	}
	public void setManagerid(int managerid) {
		this.managerid = managerid;
	}
	public String getStartdate() {
		return startdate;
	}
	public void setStartdate(String startdate) {
		this.startdate = startdate;
	}
	public String getEnddate() {
		return enddate;
	}
	public void setEnddate(String enddate) {
		this.enddate = enddate;
	}
	public String getLeavetype() {
		return leavetype;
	}
	public void setLeavetype(String leavetype) {
		this.leavetype = leavetype;
	}
	public int getLeavecount() {
		return leavecount;
	}
	public void setLeavecount(int leavecount) {
		this.leavecount = leavecount;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getReason() {
		return reason;
	}
	public void setReason(String reason) {
		this.reason = reason;
	}
	public String getComments() {
		return comments;
	}
	public void setComments(String comments) {
		this.comments = comments;
	}
	
	@Override
	public String toString() {
		return "LeaveTransaction [leaveid=" + leaveid + ", employeeid=" + employeeid + ", managerid=" + managerid
				+ ", startdate=" + startdate + ", enddate=" + enddate + ", leavetype=" + leavetype + ", leavecount="
				+ leavecount + ", status=" + status + ", reason=" + reason + ", comments=" + comments + "]";
	}
	
	
	
}
