package com.adp.leave_management_system.dao;

import java.util.List;

import com.adp.leave_management_system.model.LeaveBalancesTable;
import com.adp.leave_management_system.model.LeaveTransaction;

public interface IEmployeeDao {
	public boolean applyLeave(int employee_id, String startdate, String enddate, int leavecount, String leavetype, String reason);
	public List<LeaveTransaction> employeeLeaveStatus(int employee_id);
	public List<LeaveBalancesTable> employeeLeaveBalance(int employee_id);
}
