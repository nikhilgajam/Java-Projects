package com.adp.sfcc.model;

import com.adp.endur.model.Person;

public class Student extends Person{
	private String grade;
	private String hobbies;
	
	public String getGrade() {
		return grade;
	}
	public void setGrade(String grade) {
		this.grade = grade;
	}
	public String getHobbies() {
		return hobbies;
	}
	public void setHobbies(String hobbies) {
		this.hobbies = hobbies;
	}
	@Override
	public String toString() {
		return "Student [grade=" + grade + ", hobbies=" + hobbies + ", getBirthdate()=" + getBirthdate()
				+ ", getAdharCard()=" + getAdharCard() + ", getName()=" + getName() + ", getAddress()=" + getAddress()
				+ ", getEmail()=" + getEmail() + ", getMobile()=" + getMobile() + ", toString()=" + super.toString()
				+ ", getClass()=" + getClass() + ", hashCode()=" + hashCode() + "]";
	}
	
	
	
}
