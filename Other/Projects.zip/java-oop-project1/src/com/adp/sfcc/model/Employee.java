package com.adp.sfcc.model;

import com.adp.endur.model.Person;
import java.time.LocalDate;

public class Employee extends Person{
	private Long empno;
	private String job;
	private Long sal;
	private Long deptno;
	private LocalDate hiredate;
	
	
	public Long getEmpno() {
		return empno;
	}



	public void setEmpno(Long empno) {
		this.empno = empno;
	}



	public String getJob() {
		return job;
	}



	public void setJob(String job) {
		this.job = job;
	}



	public Long getSal() {
		return sal;
	}



	public void setSal(Long sal) {
		this.sal = sal;
	}



	public Long getDeptno() {
		return deptno;
	}



	public void setDeptno(Long deptno) {
		this.deptno = deptno;
	}



	public LocalDate getHiredate() {
		return hiredate;
	}



	public void setHiredate(LocalDate hiredate) {
		this.hiredate = hiredate;
	}



	@Override
	public String toString() {
		return "Employee [empno=" + empno + ", job=" + job + ", sal=" + sal + ", deptno=" + deptno + ", hiredate="
				+ hiredate + ", getBirthdate()=" + getBirthdate() + ", getAdharCard()=" + getAdharCard()
				+ ", getName()=" + getName() + ", getAddress()=" + getAddress() + ", getEmail()=" + getEmail()
				+ ", getMobile()=" + getMobile() + ", toString()=" + super.toString() + ", getClass()=" + getClass()
				+ ", hashCode()=" + hashCode() + "]";
	}



	
	
	
}
