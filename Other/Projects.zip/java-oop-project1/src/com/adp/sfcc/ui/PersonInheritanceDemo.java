package com.adp.sfcc.ui;

import com.adp.endur.model.Person;
import com.adp.sfcc.model.Student;
import com.adp.sfcc.model.Employee;

import java.time.LocalDate;
import java.util.*;

public class PersonInheritanceDemo {
	public static void main(String[] args) {
		
		Scanner scan = new Scanner(System.in);
		
		System.out.print("Enter no of persons: ");
		int NE = scan.nextInt();
		
		Person persons[] = new Person[NE];
		
		PersonInheritanceDemo pid = new PersonInheritanceDemo();
		
		for(int i=0; i<NE; i++) {
			System.out.print("Enter 1 for student and 2 for employee: ");
			int n = scan.nextInt();
			if(n == 1) {
				persons[i] = new Student();
				pid.getPersonsDetails((Student) persons[i]);
				pid.showPersonsDetails((Student) persons[i]);
			}else {
				persons[i] = new Employee();
				pid.getPersonsDetails((Employee) persons[i]);
				pid.showPersonsDetails((Employee) persons[i]);
			}
			
			
		}
		
		scan.close();
		
	}
	
	public void getPersonsDetails(Student persons) {
		Scanner scan = new Scanner(System.in);
		System.out.print("Enter adhar: ");
		persons.setAdharCard(scan.nextLong());
		System.out.print("Enter name: ");
		persons.setName(scan.nextLine());
		System.out.print("Enter birth date: ");
		LocalDate date = LocalDate.parse(scan.next());
		persons.setBirthdate(date);
		persons.setAddress(Person.colonyName);
		System.out.print("Enter email: ");
		persons.setEmail(scan.nextLine());
		System.out.print("Enter mobile: ");
		persons.setMobile(scan.nextLong());
		System.out.print("Enter grade: ");
		persons.setGrade(scan.nextLine());
		System.out.print("Enter hobbies: ");
		persons.setHobbies(scan.nextLine());
		scan.close();
	}
	
	public void getPersonsDetails(Employee persons) {
		Scanner scan = new Scanner(System.in);
		System.out.print("Enter adhar: ");
		persons.setAdharCard(scan.nextLong());
		System.out.print("Enter name: ");
		persons.setName(scan.nextLine());
		System.out.print("Enter birth date: ");
		LocalDate date = LocalDate.parse(scan.next());
		persons.setBirthdate(date);
		persons.setAddress(Person.colonyName);
		System.out.print("Enter email: ");
		persons.setEmail(scan.nextLine());
		System.out.print("Enter mobile: ");
		persons.setMobile(scan.nextLong());
		System.out.print("Enter empno: ");
		persons.setEmpno(scan.nextLong());
		System.out.print("Enter job: ");
		persons.setJob(scan.nextLine());
		System.out.print("Enter sal: ");
		persons.setSal(scan.nextLong());
		System.out.print("Enter Deptno: ");
		persons.setDeptno(scan.nextLong());
		System.out.print("Enter Hire Date(YYYY-MM-DD): ");
		persons.setHiredate(LocalDate.parse(scan.nextLine()));
		scan.close();
	}
	
	public void showPersonsDetails(Student persons) {
		System.out.println("Aadhar: " + persons.getAdharCard());
		System.out.println("Name: " + persons.getName());
		System.out.println("Birth Date: " + persons.getBirthdate());
		System.out.println("Address: " + persons.getAddress());
		System.out.println("Email: " + persons.getEmail());
		System.out.println("Mobile: " + persons.getMobile());
		System.out.print("Grade: " + persons.getGrade());
		System.out.print("Hobbies: " + persons.getHobbies());
	}
	
	public void showPersonsDetails(Employee persons) {
		System.out.println("Aadhar: " + persons.getAdharCard());
		System.out.println("Name: " + persons.getName());
		System.out.println("Birth Date: " + persons.getBirthdate());
		System.out.println("Address: " + persons.getAddress());
		System.out.println("Email: " + persons.getEmail());
		System.out.println("Mobile: " + persons.getMobile());
		System.out.print("Empno: " + persons.getEmpno());
		System.out.print("Job: " + persons.getJob());
		System.out.print("Sal: " + persons.getSal());
		System.out.print("Deptno: " + persons.getDeptno());
		System.out.print("Enter Hire Date(YYYY-MM-DD): " + persons.getHiredate());
	}
	
	public List<Person> getPersonsEligibleForVoting(Person[] persons) {
		ArrayList<Person> list = new ArrayList<>();
		
		for(Person p: persons) {
			int current_year = LocalDate.now().getYear();
			int birth_year = p.getBirthdate().getYear();
			int age = current_year - birth_year;
			if(age >= 18) {
				list.add(p);
			}
		}
		
		return list;
	}
	
	public  Map<String,List<Person>> getPersonsWorkingInADP(Employee[] persons){
		HashMap<String, List<Person>> map = new HashMap<>();
		
		ArrayList<Person> list = new ArrayList<>();
		
		for(Employee emp: persons) {
			if(emp.getJob().equals("ADP")) {
				list.add(emp);
			}
		}
		
		map.put("ADP", list);
		
		return map;
	}
}
