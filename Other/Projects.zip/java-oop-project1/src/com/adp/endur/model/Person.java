package com.adp.endur.model;

import java.time.LocalDate;

public class Person {
	private Long adharCard; 
	private String name;
	private LocalDate birthdate; 
	private String address; 
	private String email;
	private Long mobile;
	
	public final static String colonyName = "Adp Colony";
	
	public Person() {
		this.adharCard = 0L;
		this.name = "";
		this.birthdate = LocalDate.parse("0001-01-01");
		this.address = "";
		this.email = "";
		this.mobile = 0L;
	}
	
	public Person(Long adharCard) {
		this();
		this.adharCard = adharCard;
	}
	
	public Person(Long adharCard, String name, LocalDate birthdate, String address, String email, Long mobile) {
		this.adharCard = adharCard;
		this.name = name;
		this.birthdate = birthdate;
		this.address = address;
		this.email = email;
		this.mobile = mobile;
	}

	public LocalDate getBirthdate() {
		return birthdate;
	}

	public void setBirthdate(LocalDate birthdate) {
		this.birthdate = birthdate;
	}

	public Long getAdharCard() {
		return adharCard;
	}

	public void setAdharCard(Long adharCard) {
		this.adharCard = adharCard;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public Long getMobile() {
		return mobile;
	}

	public void setMobile(Long mobile) {
		this.mobile = mobile;
	}

	@Override
	public String toString() {
		return "Person [adharCard=" + adharCard + ", name=" + name + ", birthdate=" + birthdate + ", address=" + address
				+ ", email=" + email + ", mobile=" + mobile + "]";
	}
	
	
	
	
	
}
