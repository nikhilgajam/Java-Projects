package com.adp.endur.service;

import java.time.LocalDate;

import com.adp.endur.model.Person;

public class Tester {

	public static void main(String[] args) {
		Person person = new Person();
		Person person1 = new Person(123456789012L);
		Person person2 = new Person(123456789012L, "Ram", LocalDate.parse("2001-01-01"), Person.colonyName, "ram@gmail.com", 9876789999L);
		
		System.out.println(person);
		System.out.println(person1);
		System.out.println(person2);
		
		Validator validator = new Validator();
		
		Person p = person2;
		
		System.out.println("Is Valid Aadhar: " + validator.isValidAdhhar(p.getAdharCard()));
		System.out.println("Is Valid Name: " + validator.isValidName(p.getName()));
		System.out.println("Is Valid Birthdate: " + validator.isValidBirthdate(p.getBirthdate()));
		System.out.println("Is Valid Email: " + validator.isValidEmail(p.getEmail()));
		System.out.println("Is Valid Mobile Number: " + validator.isValidMobile(p.getMobile()));
		
	}

}
