package com.adp.endur.service;

import java.time.LocalDate;

/**
 * 
 * @author Admin
 * This is Validator class that validates the Person details.
 * This type of validation is called Server side validation
 */
public class Validator{

	/**
	 * 
	 * @param adharCard receives adhar card number, returns true if it is valid number,
	 * a 12-digit number is valid else returns false
	 * @return
	 */
	public Boolean isValidAdhhar(Long adharCard){
		String str = adharCard.toString();
		return str.matches("[0-9]{12}");
	}

	/**
	 * 
	 * @param name receives person name
	 * @return return true if name contains alphabets, dots and spaces (optional) else
	 * returns false
	 * 
	 */
	public Boolean isValidName(String name) {
		return name.matches("[A-Za-z. ]+");
	}

	/**
	 * 
	 * @param localDate receives person's birthdate
	 * @return returns true if birthdate is less that current date else 
	 * returns false
	 */
	public Boolean isValidBirthdate(LocalDate localDate) {		
		LocalDate currentDate = LocalDate.now();
		return localDate.isBefore(currentDate);
	}

	/**
	 * 
	 * @param email receives email
	 * @return return true if the email id is valid else returns false
	 * 
	 */
	public Boolean isValidEmail(String email) {
		return email.matches("^[\\w\\d._-]+@[\\w]+\\.[\\w.]*$");
	}

	/**
	 * 
	 * @param mobile receives mobile number
	 * @return return true if it 10-digit number and the mobile number begins with 6 or 7 or 8 or 9
	 * else returns false
	 */
	public Boolean isValidMobile(Long mobile) {
		String str = mobile.toString();
		return str.matches("^[6789]{1}[0-9]{9}$");
	}


}
