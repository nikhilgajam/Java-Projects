package com.adp.project.lms.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.adp.project.lms.model.LeaveBalancesTable;

@Service
public class LeaveBalancesTableServiceImpl implements LeaveBalancesTableService{
	
	@Autowired
	FeignProxy proxy;

	@Override
	public List<LeaveBalancesTable> showLeaveBalances(int empid) {
		return proxy.empLeaveBalances(empid);
	}
	
}
