package com.adp.project.lms;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.adp.project.lms.model.LeaveBalancesTable;
import com.adp.project.lms.model.LeaveTransaction;
import com.adp.project.lms.model.SubLeaveTransaction;
import com.adp.project.lms.service.LeaveBalancesTableService;
import com.adp.project.lms.service.LeaveTransactionService;

@RestController
@RequestMapping("/employee")
public class LmsController {
	
	@Autowired
	LeaveTransactionService lt_ser;
	
	@Autowired
	LeaveBalancesTableService lb_ser;
	
	@PostMapping("/empApplyLeave")
	public ResponseEntity<SubLeaveTransaction> empapp(@RequestBody SubLeaveTransaction transaction) {
		/*
		 * {
		 * 	empid: 1,
		 * 	startdate: "28-10-2023",
		 * 	enddate: "28-10-2023",
		 * 	leavecount: 1,
		 * 	leavetype: "PrivilegedLeave",
		 *  reason: "Trip"
		 * }
		 */
		lt_ser.applyLeave(transaction);
		
		return new ResponseEntity<>(transaction, HttpStatus.CREATED);
	}
	
	@PostMapping("/empCheckLeaveStatus/{empid}")
	public ResponseEntity<List<LeaveTransaction>> empLeaveStatus(@PathVariable Integer empid) {
		return new ResponseEntity<>(lt_ser.empLeaveHistory(empid), HttpStatus.OK);
	}
	
	@PostMapping("/empCheckLeaveBalances/{empid}")
	public ResponseEntity<List<LeaveBalancesTable>> empLeaveBalances(@PathVariable Integer empid) {
		return new ResponseEntity<>(lb_ser.showLeaveBalances(empid), HttpStatus.OK);
	}
	
}
