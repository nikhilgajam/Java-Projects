package com.adp.project.lms.model;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
@Data
public class SubLeaveTransaction {
	int empid;
	String startdate;
	String enddate;
	int leavecount;
	String leavetype;
	String reason;
}
