package com.adp.project.lms.model;

import lombok.Data;

@Data
public class SubLeaveUpdate {
	int leaveid;
	String status;
	String comments;
}
