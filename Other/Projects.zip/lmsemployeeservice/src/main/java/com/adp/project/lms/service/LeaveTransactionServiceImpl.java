package com.adp.project.lms.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.Random;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.adp.project.lms.dao.EmployeeDao;
import com.adp.project.lms.dao.LeaveBalancesTableDao;
import com.adp.project.lms.dao.LeaveTransactionDao;
import com.adp.project.lms.model.Employee;
import com.adp.project.lms.model.LeaveBalancesTable;
import com.adp.project.lms.model.LeaveTransaction;
import com.adp.project.lms.model.SubLeaveTransaction;

@Service
public class LeaveTransactionServiceImpl implements LeaveTransactionService {
	
	@Autowired
	EmployeeDao emp_dao;
	
	@Autowired
	LeaveTransactionDao lt_dao;
	
	@Autowired
	FeignProxy proxy;

	@Override
	public void applyLeave(SubLeaveTransaction transaction) {
		proxy.empapp(transaction);
	}

	@Override
	public List<LeaveTransaction> empLeaveHistory(int emp_id) {
		return proxy.empLeaveStatus(emp_id);
	}

}
