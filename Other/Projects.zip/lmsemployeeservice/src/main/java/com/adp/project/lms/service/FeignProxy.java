package com.adp.project.lms.service;

import java.util.List;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import com.adp.project.lms.model.LeaveBalancesTable;
import com.adp.project.lms.model.LeaveTransaction;
import com.adp.project.lms.model.SubLeaveTransaction;

@FeignClient(name="LEAVE-TRANSACTION-SERVICE")
public interface FeignProxy {
	
	@PostMapping("/empApplyLeave")
	public SubLeaveTransaction empapp(@RequestBody SubLeaveTransaction transaction);
	
	@PostMapping("/empCheckLeaveStatus/{empid}")
	public List<LeaveTransaction> empLeaveStatus(@PathVariable Integer empid);
	
	@PostMapping("/empCheckLeaveBalances/{empid}")
	public List<LeaveBalancesTable> empLeaveBalances(@PathVariable Integer empid);
	
}
