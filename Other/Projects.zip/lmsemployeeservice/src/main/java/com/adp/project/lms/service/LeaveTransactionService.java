package com.adp.project.lms.service;

import java.util.List;
import com.adp.project.lms.model.LeaveTransaction;
import com.adp.project.lms.model.SubLeaveTransaction;

public interface LeaveTransactionService {
	
	public void applyLeave(SubLeaveTransaction transaction);
	public List<LeaveTransaction> empLeaveHistory(int emp_id);
	
}
