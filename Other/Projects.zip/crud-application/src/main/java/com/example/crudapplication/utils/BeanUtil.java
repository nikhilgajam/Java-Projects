package com.example.crudapplication.utils;

import com.example.crudapplication.dto.StudentDto;
import com.example.crudapplication.model.Student;

public class BeanUtil {
	public static Student toEntity(StudentDto dto)
	{
		return new Student(dto.getHtno(), dto.getGpa(), dto.getGrade(), dto.getName(), dto.getDept());
	}
	
	public static StudentDto toDto(Student s)
	{
		return new StudentDto(s.getHtno(), s.getGpa(),s.getGrade(), s.getName(), s.getDepartment());
	}
	
}
