package com.example.crudapplication.service;

import java.util.List;

import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.example.crudapplication.exceptions.StudentNotFoundException;
import com.example.crudapplication.dao.StudentDao;
import com.example.crudapplication.dto.StudentDto;
import com.example.crudapplication.model.Student;
import com.example.crudapplication.utils.BeanUtil;

import jakarta.validation.Valid;

@Service
public class StudentServiceImpl implements StudentService {

	@Autowired
	StudentDao dao;
	
	@Override
	public List<StudentDto> getAllStudents() {
		return dao.findAll().stream().map(BeanUtil::toDto).collect(Collectors.toList());
	}

	@Override
	public Optional<StudentDto> findStudent(int htno) throws StudentNotFoundException{
		// TODO Auto-generated method stub
		Optional<Student> s = dao.findById(htno);
		if(s.isEmpty())
			throw new StudentNotFoundException();
		return Optional.of(BeanUtil.toDto(s.get()));
		
	}

	@Override
	public List<StudentDto> getStudentsByDept(String dept) {
		// TODO Auto-generated method stub
		return dao.findByDept(dept).stream().map(BeanUtil::toDto).collect(Collectors.toList());
	}

	@Override
	public void addStudent(@Valid StudentDto student) {
		// TODO Auto-generated method stub
		dao.save(BeanUtil.toEntity(student));
		
	}

}
