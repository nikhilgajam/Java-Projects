package com.example.crudapplication.dto;

import com.example.crudapplication.model.Department;

import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class StudentDto {
	@NotNull(message = "Hall ticket cannot be null")
	public int htno;
	@Max(value = 10, message = "GPA cannot be greater than 10")
	public Double gpa;
	public String grade;
	@NotNull(message = "Name cannot be null")
	public String name;
	public Department dept;
	
	
	
}
