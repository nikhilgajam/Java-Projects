package com.example.crudapplication.service;

import java.util.List;
import java.util.Optional;

import com.example.crudapplication.dto.StudentDto;
import com.example.crudapplication.exceptions.StudentNotFoundException;
import com.example.crudapplication.model.Student;

import jakarta.validation.Valid;

public interface StudentService {
	
	public List<StudentDto> getAllStudents();
	public Optional<StudentDto> findStudent(int htno) throws StudentNotFoundException;
	public List<StudentDto> getStudentsByDept(String dept);
	public void addStudent(@Valid StudentDto student); 
}
