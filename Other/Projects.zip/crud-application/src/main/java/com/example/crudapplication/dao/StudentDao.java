package com.example.crudapplication.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.example.crudapplication.model.Student;

@Repository
public interface StudentDao extends JpaRepository<Student,Integer>{
	@Query("FROM Student WHERE department.name = :dept")
	List<Student> findByDept(String dept);
	

}
