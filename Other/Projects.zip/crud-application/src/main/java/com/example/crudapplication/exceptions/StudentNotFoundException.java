package com.example.crudapplication.exceptions;

public class StudentNotFoundException extends Exception{
	public StudentNotFoundException()
	{
	super("No student present with the given details");
	}
}
