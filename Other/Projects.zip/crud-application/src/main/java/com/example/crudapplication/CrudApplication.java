package com.example.crudapplication;


import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
@ComponentScan(basePackages = "com.example.crudapplication")
public class CrudApplication{

	public static void main(String[] args) {
		SpringApplication.run(CrudApplication.class, args);
	}

}
