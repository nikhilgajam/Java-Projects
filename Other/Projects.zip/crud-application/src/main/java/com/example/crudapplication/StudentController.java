package com.example.crudapplication;


import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import com.example.crudapplication.dto.StudentDto;
import com.example.crudapplication.exceptions.StudentNotFoundException;
import com.example.crudapplication.service.StudentService;
import jakarta.validation.Valid;

@RestController
public class StudentController {
	
	@Autowired
	StudentService service;
	
	@GetMapping("/")
	public String home()
	{
		return "login";
	}
	
	@GetMapping("/details")
	public ResponseEntity<StudentDto> valid(@RequestParam("htno") Integer htno) throws StudentNotFoundException
	{
		Optional<StudentDto> s = service.findStudent(htno);
		return new ResponseEntity<>(s.get(),HttpStatus.OK);	
	}
	
	@GetMapping("/allstudents")
	public ResponseEntity<List<StudentDto>> students()
	{
		List<StudentDto> students = service.getAllStudents();
		return new ResponseEntity<>(students,HttpStatus.OK);
	}
	
	@GetMapping("/allstudents/{dept}")
	public ResponseEntity<List<StudentDto>> deptstudents(@PathVariable("dept") String dept)
	{
		List<StudentDto> students = service.getStudentsByDept(dept);
		return new ResponseEntity<>(students,HttpStatus.OK);
	}
	
	@PostMapping("/addstudent")
	public ResponseEntity<StudentDto> addStudent(@RequestBody @Valid StudentDto student)
	{
		service.addStudent(student);
		return new ResponseEntity<>(student, HttpStatus.CREATED);
	}
}
