package com.example.springboot.springbootdemo;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import jakarta.servlet.http.HttpServletRequest;

@Controller
public class EmployeeController {
	
	
	/*
	@GetMapping -- Get Method
	@PostMapping -- Post Method
	@PutMapping --- Put Method
	@DeleteMapping -- Delete Method
	
	*/
	
	@GetMapping("/validate")
	public String validationPage(@RequestParam("lid") String lid, @RequestParam("pwd") String pwd, Model model) {
	//	String loginid = request.getParameter("lid");
	//	String passwd = request.getParameter("pwd");
		Connection con = null;
		Statement st = null;
		ResultSet rs= null;
		boolean isFound=false;
		con= Dbconnections.getConnection();
		try {
			st = con.createStatement();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			rs= st.executeQuery("select * from batch1users");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		try {
			while(rs.next()) {
				String usr = rs.getString(1);
				String pwd1 = rs.getString(2);
				System.out.println(usr+" "+pwd);
				if( lid.equals(usr) && pwd.equals(pwd1)) {
					isFound=true;
					break;
				}
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
		if( isFound) {
			
			model.addAttribute("user",lid);
			return "valid";
		}
		else {
			model.addAttribute("user",pwd);
			return "invalid";
			
		}
	}
	
	@GetMapping("/")
	public String test() {
		return "login";
	}
	
	@GetMapping("/register")
	public String register() {
		return "register";
	}
	
	
	@RequestMapping("/logout")
	public String getView() {
		return "logout";
	}
	
	@PostMapping("/addData")
	public String newUserRegistration(HttpServletRequest request, Model model) {
		String loginid = request.getParameter("lid");
		String passwd = request.getParameter("pwd");
		Connection con = null;
		PreparedStatement pst = null;
		con= Dbconnections.getConnection();
		String str = "insert into batch1users values(?,?)";
		try {
			pst = con.prepareStatement(str);
			pst.setString(1, loginid);
			pst.setString(2, passwd);
			pst.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return "login";
	}
	
	@GetMapping("/searchproduct")
	public String searchProduct() {
		return "searchproduct";
	}
	
	@GetMapping("/displayproducts")
	public String displayproducts(Model model) {
		Connection con = null;
		Statement st = null;
		ResultSet rs= null;
		List<Product> products=new ArrayList<>();
		con= Dbconnections.getConnection();
		try {
			st = con.createStatement();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			rs= st.executeQuery("select * from batch1products");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			while(rs.next()) {
				int pid = rs.getInt(1);
				String pname = rs.getString(2);
				String pcat = rs.getString(3);
				System.out.println(pid+" "+pname+" "+pcat);
				products.add(new Product(pid,pname,pcat));
				
				
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		model.addAttribute("data",products);
		return "displayproducts";
	}
	
	@GetMapping("/search")
	public String search(HttpServletRequest request, Model model) {
		Connection con = null;
		List<Product> products = new ArrayList<>();
		PreparedStatement pst = null;
		ResultSet rs = null;
		con= Dbconnections.getConnection();
		String str = "select * from batch1products where category = ?";
		String category = request.getParameter("cat");
		try {
			pst = con.prepareStatement(str);
			pst.setString(1,category);
			rs = pst.executeQuery();
			while(rs.next()) {
				int pid = rs.getInt(1);
				String pname = rs.getString(2);
				String pcat = rs.getString(3);
				System.out.println(pid+" "+pname+" "+pcat);
				products.add(new Product(pid,pname,pcat));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		model.addAttribute("data",products);
		return "products";
	}
	
	@GetMapping("/deleteProduct/{pid}")
	public String deleteProduct(@PathVariable("pid") Integer pid, Model model) {
		
		Connection con = null;
		PreparedStatement pst = null;
		Statement st = null;
		con= Dbconnections.getConnection();
		ResultSet rs = null;
		String str = "delete batch1products where pid = ?";
		String qry = "select * from batch1products";
		List<Product> products=new ArrayList<>();
		try {
			pst = con.prepareStatement(str);
			st= con.createStatement();
			pst.setInt(1, pid);
			pst.executeUpdate();
			rs= st.executeQuery(qry);
			while(rs.next()) {
				int p = rs.getInt(1);
				String pname = rs.getString(2);
				String pcat = rs.getString(3);
				//System.out.println(pid+" "+pname+" "+pcat);
				products.add(new Product(p,pname,pcat));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		model.addAttribute("data",products);
		return "displayproducts";
	}
	
	@GetMapping("/addproduct")
	public String addProduct() {
		return "addproduct";
	}
	
	@PostMapping("/insert")
	public String insertProduct(HttpServletRequest request, Model model) {
		List<Product> products=new ArrayList<>();
		Integer pid = Integer.parseInt(request.getParameter("id"));
		String pname= request.getParameter("name");
		String pcat = request.getParameter("cat");
		ResultSet rs= null;
		Connection con = null;
		PreparedStatement pst = null;
		Statement st = null;
		con= Dbconnections.getConnection();
		String str = "insert into batch1products values(?,?,?)";
		String qry = "select * from batch1products";
		try {
			pst = con.prepareStatement(str);
			st= con.createStatement();
			pst.setInt(1, pid);
			pst.setString(2, pname);
			pst.setString(3, pcat);
			pst.executeUpdate();
			rs= st.executeQuery(qry);
			while(rs.next()) {
				int p1 = rs.getInt(1);
				String p2 = rs.getString(2);
				String p3 = rs.getString(3);
				//System.out.println(pid+" "+pname+" "+pcat);
				products.add(new Product(p1,p2,p3));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		model.addAttribute("data", products);
		return "displayproducts";
	}
	
}
