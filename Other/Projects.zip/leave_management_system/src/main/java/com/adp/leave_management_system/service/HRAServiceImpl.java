package com.adp.leave_management_system.service;

public class HRAServiceImpl implements IHRAService {

}
