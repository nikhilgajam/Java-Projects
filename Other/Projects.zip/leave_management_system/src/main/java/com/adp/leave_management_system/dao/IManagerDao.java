package com.adp.leave_management_system.dao;

import com.adp.leave_management_system.model.LeaveTransaction;
import java.util.List;

public interface IManagerDao {
	public boolean approveOrRejectLeave(int leave_id, String status, String comments);
	public List<LeaveTransaction> viewPendingRequests(int manager_id);
}
