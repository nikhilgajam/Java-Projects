package com.adp.leave_management_system.controller;

import java.util.List;
import java.util.Scanner;
import com.adp.leave_management_system.model.LeaveTransaction;
import com.adp.leave_management_system.service.EmployeeServiceImpl;
import com.adp.leave_management_system.service.ManagerServiceImpl;

public class LeaveManagementSystemMain {
	
	public static void main(String[] args) {
		EmployeeServiceImpl service_emp = new EmployeeServiceImpl();
		ManagerServiceImpl service_man = new ManagerServiceImpl();
		Scanner scan = new Scanner(System.in);
		
		while(true) {
			
			System.out.println("\nSelect The Option Accordingly:");
			System.out.println("-----------------------------");
			System.out.println("1: Employee Portal");
			System.out.println("2: Manager Portal");
			System.out.print("0: Exit\n: ");
			
			int option = Integer.parseInt(scan.nextLine());
			
			switch(option) {
			
			case 1:
				System.out.println("\nEmployee Portal:");
				System.out.println("1: To Apply Leave");
				System.out.println("2: To Check Status ");
				System.out.print("0: To Exit\n: ");
				int emp_opt = Integer.parseInt(scan.nextLine());
				
				if(emp_opt == 1) {
					System.out.println("\nLeave Application:");
					
					System.out.print("Enter Your ID: ");
					int emp_id = Integer.parseInt(scan.nextLine());
					
					System.out.print("Enter startdate(dd-mm-yyyy): ");
					String startdate = scan.nextLine();
					
					System.out.print("Enter end date(dd-mm-yyyy): ");
					String enddate = scan.nextLine();
					
					System.out.print("Enter leave count: ");
					int leavecount = Integer.parseInt(scan.nextLine());
					
					System.out.print("Enter leave type number\n1 = Sick Leave\n2 = Privilege leave\n3 = Maternity Leave\n4 = Paternity Leave\n:");
					int leave_no = Integer.parseInt(scan.nextLine());
					
					String leavetype = "";
					switch(leave_no) {
					case 1: leavetype = "SickLeaves"; break;
					case 2: leavetype = "PrivilegedLeaves"; break;
					case 3: leavetype = "MaternityLeaves"; break;
					case 4: leavetype = "PaternityLeaves"; break;
					default: leavetype = "PrivilegedLeaves";
					}
					
					System.out.print("State the reason: ");
					String reason = scan.nextLine();
					
					boolean output = service_emp.applyLeave(emp_id, startdate, enddate, leavecount, leavetype, reason);
					System.out.println("Successfully Applied: " + output);
					
				} else if(emp_opt == 2) {
					System.out.println("\nChecking Leave Status:");
					
					System.out.print("Enter employee_id: ");
					int emp_id = Integer.parseInt(scan.nextLine());
					
					List<LeaveTransaction> list = service_emp.employeeLeaveStatus(emp_id);
					if(list == null) {
						System.out.println("No Previous Leave Status History Available");
					}else {
						list.forEach(System.out::println);
					}
				}else if(emp_opt == 0) {
					break;
				}else {
					System.out.println("Choose correct option");
				}
				
				break;
				
			case 2:
				System.out.println("\nManager Portal:");
				System.out.println("1: To Show Pending Requests");
				System.out.println("2: To Approve/Reject");
				System.out.print("0: To Exit\n: ");
				
				int man_opt = Integer.parseInt(scan.nextLine());
				
				if(man_opt==1) {
					System.out.println("\nPending Requests:");
					
					System.out.print("Enter Your ID: ");
					int managerid = Integer.parseInt(scan.nextLine());
					
					List<LeaveTransaction> list = service_man.viewPendingRequests(managerid);
					if(list == null) {
						System.out.println("No Pending Requests");
					}else {
						list.forEach(System.out::println);
					}
					
				}else if(man_opt==2) {
					System.out.println("\nApprove/Reject:");
					
					System.out.print("Enter Leave ID: ");
					int transactionid = Integer.parseInt(scan.nextLine());
					
					System.out.print("Enter status no\n1 = Approve\n2 = Reject\n:");
					int stat_id = Integer.parseInt(scan.nextLine());
					
					String status = "";
					switch(stat_id) {
					case 1: status = "Approved"; break;
					case 2: status = "Rejected"; break;
					default: status = "Approved";
					}
					
					System.out.print("Enter comments: ");
					String comments = scan.nextLine();
					
					boolean output = service_man.approveOrRejectLeave(transactionid, status, comments);
					System.out.println("Successfully Approved/Rejected: " + output);
				}else if(man_opt == 0) {
					break;
				}else {
					System.out.println("Choose correct option");
				}
				
				break;
				
			case 0:
				System.out.println("Program Ended");
				System.exit(0);
				scan.close();
				break;
				
			default:
				System.out.println("\nEntemr Correct Option");
				
			}
		
		}
		
	}
	
}
