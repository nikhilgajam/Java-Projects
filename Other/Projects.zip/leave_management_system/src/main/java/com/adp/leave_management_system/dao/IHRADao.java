package com.adp.leave_management_system.dao;

public interface IHRADao {

}
