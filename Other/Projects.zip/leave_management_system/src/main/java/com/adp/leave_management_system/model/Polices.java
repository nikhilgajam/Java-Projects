package com.adp.leave_management_system.model;

public class Polices {
	private int leave_id;
	private String leavetype;
	private int totalcount;
	public int getLeave_id() {
		return leave_id;
	}
	public void setLeave_id(int leave_id) {
		this.leave_id = leave_id;
	}
	public String getLeavetype() {
		return leavetype;
	}
	public void setLeavetype(String leavetype) {
		this.leavetype = leavetype;
	}
	public int getTotalcount() {
		return totalcount;
	}
	public void setTotalcount(int totalcount) {
		this.totalcount = totalcount;
	}
	
	@Override
	public String toString() {
		return "Polices [leave_id=" + leave_id + ", leavetype=" + leavetype + ", totalcount=" + totalcount + "]";
	}
	
}
