package com.adp.leave_management_system.model;

public class LeaveTransaction {
	private int leave_id;
	private int employee_id;
	private int manager_id;
	private String startdate;
	private String enddate;
	private String leavetype;
	private int leavecount;
	private String status;
	private String reasons;
	private String comments;
	
	public int getLeave_id() {
		return leave_id;
	}
	public void setLeave_id(int leave_id) {
		this.leave_id = leave_id;
	}
	public int getEmployee_id() {
		return employee_id;
	}
	public void setEmployee_id(int employee_id) {
		this.employee_id = employee_id;
	}
	public int getManager_id() {
		return manager_id;
	}
	public void setManager_id(int manager_id) {
		this.manager_id = manager_id;
	}
	public String getStartdate() {
		return startdate;
	}
	public void setStartdate(String startdate) {
		this.startdate = startdate;
	}
	public String getEnddate() {
		return enddate;
	}
	public void setEnddate(String enddate) {
		this.enddate = enddate;
	}
	public String getLeavetype() {
		return leavetype;
	}
	public void setLeavetype(String leavetype) {
		this.leavetype = leavetype;
	}
	public int getLeavecount() {
		return leavecount;
	}
	public void setLeavecount(int leavecount) {
		this.leavecount = leavecount;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getReasons() {
		return reasons;
	}
	public void setReasons(String reasons) {
		this.reasons = reasons;
	}
	public String getComments() {
		return comments;
	}
	public void setComments(String comments) {
		this.comments = comments;
	}
	
	@Override
	public String toString() {
		return "LeaveTransaction [leave_id=" + leave_id + ", employee_id=" + employee_id + ", manager_id=" + manager_id
				+ ", startdate=" + startdate + ", enddate=" + enddate + ", leavetype=" + leavetype + ", leavecount="
				+ leavecount + ", status=" + status + ", reasons=" + reasons + ", comments=" + comments + "]";
	}
	
}
