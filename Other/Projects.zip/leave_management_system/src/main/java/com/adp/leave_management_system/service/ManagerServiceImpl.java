package com.adp.leave_management_system.service;

import java.util.List;
import com.adp.leave_management_system.model.LeaveTransaction;
import com.adp.leave_management_system.dao.ManagerDaoImpl;

public class ManagerServiceImpl implements IManagerService {
	
	ManagerDaoImpl manager_dao = new ManagerDaoImpl();
	
	@Override
	public boolean approveOrRejectLeave(int leave_id, String status, String comments) {
		return manager_dao.approveOrRejectLeave(leave_id, status, comments);
	}

	@Override
	public List<LeaveTransaction> viewPendingRequests(int manager_id) {
		return manager_dao.viewPendingRequests(manager_id);
	}

	

}
