package com.adp.leave_management_system.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import com.adp.leave_management_system.model.LeaveTransaction;
import com.adp.leave_management_system.utils.Dbconnections;

public class EmployeeDaoImpl implements IEmployeeDao {

	@Override
	public boolean applyLeave(int employee_id, String startdate, String enddate, int leavecount, String leavetype, String reason) {
		
		int manager_id;
		
		try {
			
			Connection connect = Dbconnections.getConnection();
			String query = "select managerid from season2_batch1_team2_employee where employeeid = ?";
			
			PreparedStatement pstmt = connect.prepareStatement(query);
			pstmt.setInt(1, employee_id);
			
			ResultSet rs = pstmt.executeQuery();
			rs.next();
			
			manager_id = rs.getInt(1);
			
			connect.close();
		}catch(Exception e) {
			e.printStackTrace();
			return false;
		}
		
		try {
			Connection connect = Dbconnections.getConnection();
			
			int leave_id = Math.abs(new Random().nextInt());
			String status = "Pending";
			
			String query = "insert into Season2_Batch1_Team2_LeaveTransaction values (?,?,?,?,?,?,?,?,?,?)";
			PreparedStatement pstmt = connect.prepareStatement(query);
			pstmt.setInt(1, leave_id);
			pstmt.setInt(2, employee_id);
			pstmt.setInt(3, manager_id);
			pstmt.setString(4, startdate);
			pstmt.setString(5, enddate);
			pstmt.setString(6, leavetype);
			pstmt.setInt(7, leavecount);
			pstmt.setString(8, status);
			pstmt.setString(9, reason);
			pstmt.setString(10, "");
			
			pstmt.executeUpdate();
			
			connect.close();
			return true;
		}catch(Exception e) {
			System.out.println("There's a problem!: " + e);
			return false;
		}
	}

	@Override
	public List<LeaveTransaction> employeeLeaveStatus(int employee_id) {
		try {
			ArrayList<LeaveTransaction> list = new ArrayList<>();
			
			Connection connect = Dbconnections.getConnection();
			String query = "select * from Season2_Batch1_Team2_LeaveTransaction where employeeid = ? order by startdate desc";
			PreparedStatement pstmt = connect.prepareStatement(query);
			pstmt.setInt(1, employee_id);
			ResultSet rs = pstmt.executeQuery();
			
			while(rs.next()) {
				LeaveTransaction lt = new LeaveTransaction();
				lt.setLeave_id(rs.getInt(1));
				lt.setEmployee_id(rs.getInt(2));
				lt.setManager_id(rs.getInt(3));
				lt.setStartdate(rs.getString(4));
				lt.setEnddate(rs.getString(5));
				lt.setLeavetype(rs.getString(6));
				lt.setLeavecount(rs.getInt(7));
				lt.setStatus(rs.getString(8));
				lt.setReasons(rs.getString(9));
				lt.setComments(rs.getString(10));
				
				list.add(lt);
			}
			
			connect.close();
			return list;
		}catch(Exception e) {
			System.out.println("There's a problem!: " + e);
			return null;
		}
	}

}
