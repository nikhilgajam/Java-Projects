package com.adp.leave_management_system.model;

public class LeaveBalancesTable {
	private int employee_id;
	private int sickleaves;
	private int maternityleaves;
	private int paternityleaves;
	private int privilegedleaves;
	public int getEmployee_id() {
		return employee_id;
	}
	public void setEmployee_id(int employee_id) {
		this.employee_id = employee_id;
	}
	public int getSickleaves() {
		return sickleaves;
	}
	public void setSickleaves(int sickleaves) {
		this.sickleaves = sickleaves;
	}
	public int getMaternityleaves() {
		return maternityleaves;
	}
	public void setMaternityleaves(int maternityleaves) {
		this.maternityleaves = maternityleaves;
	}
	public int getPaternityleaves() {
		return paternityleaves;
	}
	public void setPaternityleaves(int paternityleaves) {
		this.paternityleaves = paternityleaves;
	}
	public int getPrivilegedleaves() {
		return privilegedleaves;
	}
	public void setPrivilegedleaves(int privilegedleaves) {
		this.privilegedleaves = privilegedleaves;
	}
	
	@Override
	public String toString() {
		return "LeaveBalancesTable [employee_id=" + employee_id + ", sickleaves=" + sickleaves + ", maternityleaves="
				+ maternityleaves + ", paternityleaves=" + paternityleaves + ", privilegedleaves=" + privilegedleaves
				+ "]";
	}
	
	
}
