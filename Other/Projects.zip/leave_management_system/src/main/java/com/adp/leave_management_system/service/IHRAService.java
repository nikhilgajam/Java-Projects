package com.adp.leave_management_system.service;

public interface IHRAService {

}
