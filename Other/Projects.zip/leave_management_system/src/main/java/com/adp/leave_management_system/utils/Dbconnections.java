package com.adp.leave_management_system.utils;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

public class Dbconnections {
    
    static Connection con = null;
    static Properties props = null;
    static FileReader reader = null;    
    
    public static Connection getConnection() {
        
        try {
            reader = new FileReader("src\\main\\resources\\dbproperties.properties");
        } catch (FileNotFoundException e) {
            
            e.printStackTrace();
        }
        
        props = new Properties();
        try {
            props.load(reader);
        } catch (IOException e) {
            
            e.printStackTrace();
        }
        
        try {
            Class.forName(props.getProperty("driver"));
        } catch (ClassNotFoundException e) {
            
            e.printStackTrace();
        }
        String driver = props.getProperty("driver");
        String url = props.getProperty("url");
        String uid = props.getProperty("username");
        String pwd = props.getProperty("password");
        try {
            Class.forName(driver);
        } catch (ClassNotFoundException e1) {
            e1.printStackTrace();
        }
        
        try {
            con = DriverManager.getConnection(url, uid, pwd);
        } catch (SQLException e) {
            
            e.printStackTrace();
        }
        
        return con;
    }
}
