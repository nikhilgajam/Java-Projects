package com.adp.leave_management_system.model;

public class Employee {
	
	private int employee_ID;
	private String name;
	private String gender;
	private String department;
	private String position;
	private int manager_ID;
	private String martial_status;
	
	public int getEmployee_ID() {
		return employee_ID;
	}
	public void setEmployee_ID(int employee_ID) {
		this.employee_ID = employee_ID;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getDepartment() {
		return department;
	}
	public void setDepartment(String department) {
		this.department = department;
	}
	public String getPosition() {
		return position;
	}
	public void setPosition(String position) {
		this.position = position;
	}
	public int getManager_ID() {
		return manager_ID;
	}
	public void setManager_ID(int manager_ID) {
		this.manager_ID = manager_ID;
	}
	public String getMartial_status() {
		return martial_status;
	}
	public void setMartial_status(String martial_status) {
		this.martial_status = martial_status;
	}
	
	@Override
	public String toString() {
		return "EmployeeModel [employee_ID=" + employee_ID + ", name=" + name + ", gender=" + gender + ", department="
				+ department + ", position=" + position + ", manager_ID=" + manager_ID + ", martial_status="
				+ martial_status + "]";
	}
	
	
	
}
