package com.adp.leave_management_system.dao;

public class HRADaoImpl implements IHRADao {

}
