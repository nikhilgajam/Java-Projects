package com.adp.leave_management_system.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import com.adp.leave_management_system.model.LeaveTransaction;
import com.adp.leave_management_system.utils.Dbconnections;

public class ManagerDaoImpl implements IManagerDao {

	@Override
	public boolean approveOrRejectLeave(int leave_id, String status, String comments) {
		// It takes leave_id, status, comments;
		try {
			Connection connect = Dbconnections.getConnection();
			connect.setAutoCommit(false);
			
			String query = "select employeeid, leavecount, leavetype from Season2_Batch1_Team2_LeaveTransaction where leaveid = ?";
			PreparedStatement pstmts = connect.prepareStatement(query);
			pstmts.setInt(1, leave_id);
			ResultSet r = pstmts.executeQuery();
			r.next();
			
			int employee_id = r.getInt(1);
			int leavecount = r.getInt(2);
			String leavetype = r.getString(3);
			
			query = "update Season2_Batch1_Team2_LeaveTransaction set status = ?, comments = ? where leaveid = ?";
			PreparedStatement pstmt = connect.prepareStatement(query);
			pstmt.setString(1, status);
			pstmt.setString(2, comments);
			pstmt.setInt(3, leave_id);
			
			int count = pstmt.executeUpdate();
			
			if(!status.equals("Approved")) {
				return true;
			}
			
			if(count > 0) {
				Statement stmt = connect.createStatement();
				
				query = "select " + leavetype + " from season2_batch1_team2_leavebalancestable where employeeid = " + employee_id;
				ResultSet rss = stmt.executeQuery(query);
				rss.next();
				
				int remaining_leaves = rss.getInt(1);
				
				int new_remaining_leaves = remaining_leaves - leavecount;
				
				if(new_remaining_leaves >= 0) {
					query = "update season2_batch1_team2_leavebalancestable set " + leavetype + " = " + new_remaining_leaves + " where employeeid = " + employee_id;
					int c = stmt.executeUpdate(query);
					if(c > 0) {
						connect.commit();
						connect.close();
						return true;
					}else {
						return false;
					}
				}
				
				return false;
			}else {
				return false;
			}
		}catch(Exception e) {
			System.out.println("There's a problem!: " + e);
			return false;
		}
	}

	@Override
	public List<LeaveTransaction> viewPendingRequests(int manager_id) {
		// It takes obj.setManager(Number);
		try {
			ArrayList<LeaveTransaction> list = new ArrayList<>();
			Connection connect = Dbconnections.getConnection();
			String query = "select * from Season2_Batch1_Team2_LeaveTransaction where status = 'Pending' and managerid = ? order by startdate";
			PreparedStatement pstmt = connect.prepareStatement(query);
			pstmt.setInt(1, manager_id);
			ResultSet rs = pstmt.executeQuery();
			
			Connection connect1 = Dbconnections.getConnection();
			while(rs.next()) {
				LeaveTransaction lt = new LeaveTransaction();
				lt.setLeave_id(rs.getInt(1));
				lt.setEmployee_id(rs.getInt(2));
				lt.setManager_id(rs.getInt(3));
				lt.setStartdate(rs.getString(4));
				lt.setEnddate(rs.getString(5));
				lt.setLeavetype(rs.getString(6));
				lt.setLeavecount(rs.getInt(7));
				lt.setStatus(rs.getString(8));
				lt.setReasons(rs.getString(9));
				lt.setComments(rs.getString(10));
				
				list.add(lt);
			}
			
			connect1.close();
			connect.close();
			return list;
		}catch(Exception e) {
			System.out.println("There's a problem!: " + e);
			return null;
		}
	}
	
}
