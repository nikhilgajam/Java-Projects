package com.adp.leave_management_system.service;

import java.util.List;
import com.adp.leave_management_system.model.LeaveTransaction;

public interface IEmployeeService {
	public boolean applyLeave(int employee_id, String startdate, String enddate, int leavecount, String leavetype, String reason);
	public List<LeaveTransaction> employeeLeaveStatus(int employee_id);
}
