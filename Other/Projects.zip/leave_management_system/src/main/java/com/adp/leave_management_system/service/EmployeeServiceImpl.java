package com.adp.leave_management_system.service;

import java.util.List;
import com.adp.leave_management_system.dao.EmployeeDaoImpl;
import com.adp.leave_management_system.model.LeaveTransaction;

public class EmployeeServiceImpl implements IEmployeeService {
	
	EmployeeDaoImpl emp_dao = new EmployeeDaoImpl();

	@Override
	public boolean applyLeave(int employee_id, String startdate, String enddate, int leavecount, String leavetype, String reason) {
		return emp_dao.applyLeave(employee_id, startdate, enddate, leavecount, leavetype, reason);
	}

	@Override
	public List<LeaveTransaction> employeeLeaveStatus(int employee_id) {
		// TODO Auto-generated method stub
		return emp_dao.employeeLeaveStatus(employee_id);
	}

}
