package com.adp.project.comments.dto;

import com.adp.project.comments.model.Posts;

import lombok.Data;

@Data
public class CommentsDto {
	private int pid;
	private int cid;
	private String comments;
	private String commenter;
//	private Posts post;
}
