package com.adp.project.comments.dao;

import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.adp.project.comments.model.Posts;

@Repository
public interface PostsDao extends JpaRepository<Posts, Integer>{
	public List<Posts> findByTitle(String title);
}
