package com.adp.project.comments.service;

import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.adp.project.comments.dto.PostsDto;

@FeignClient(name="post-service")
public interface FeignProxy {
	@GetMapping("/posts/{title}")
	public List<PostsDto> getPostsByTitle(@PathVariable String title);
}
