package com.adp.project.comments;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.adp.project.comments.dto.CommentsDto;
import com.adp.project.comments.service.CommentsService;

@RestController
@RequestMapping("/comments")
public class CommentsController {
	
	@Autowired
	CommentsService com_ser;
	
	@GetMapping("/{pid}")
	public ResponseEntity<List<CommentsDto>> getCommentsById(@PathVariable int pid) {
		List<CommentsDto> list = com_ser.commentsOfPostById(pid);
		return new ResponseEntity<>(list, HttpStatus.OK);
	}
	
	@PostMapping("/add")
	public ResponseEntity<CommentsDto> getPostsByTitle(@RequestBody CommentsDto dto) {
		/*
		 * {
		    "pid": 1,
		    "comments": "It's good",
		    "commenter": "John"
		   }
		 */
		return new ResponseEntity<>(com_ser.addComment(dto), HttpStatus.CREATED);
	}
	
	@PostMapping("/delete")
	public ResponseEntity<String> deletePost(@PathVariable int cid) {
		com_ser.deleteComment(cid);
		return new ResponseEntity<>("Deleted Successfully", HttpStatus.OK);
	}
	
	@PostMapping("/update")
	public ResponseEntity<CommentsDto> updatePost(@RequestBody CommentsDto dto) {
		return new ResponseEntity<>(com_ser.updateComment(dto), HttpStatus.OK);
	}

}
