package com.adp.project.comments.service;

import java.util.List;
import com.adp.project.comments.dto.CommentsDto;

public interface CommentsService {
	public CommentsDto addComment(CommentsDto dto);
	public void deleteComment(int cid);
	public CommentsDto updateComment(CommentsDto dto);
	public List<CommentsDto> commentsOfPostById(int id);
}
