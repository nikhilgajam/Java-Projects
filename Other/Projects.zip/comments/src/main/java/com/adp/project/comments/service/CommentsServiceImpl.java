package com.adp.project.comments.service;

import java.util.List;
import java.util.stream.Collectors;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.adp.project.comments.dao.CommentsDao;
import com.adp.project.comments.dto.CommentsDto;
import com.adp.project.comments.model.Comments;

@Service
public class CommentsServiceImpl implements CommentsService {
	
	@Autowired
	CommentsDao com_dao;
	
	ModelMapper modelmap;
	
	public CommentsServiceImpl() {
		modelmap = new ModelMapper();
	}
	

	@Override
	public CommentsDto addComment(CommentsDto dto) {
		int cid = com_dao.save(modelmap.map(dto, Comments.class)).getCid();
		dto.setCid(cid);
		return dto;
	}

	@Override
	public void deleteComment(int cid) {
		com_dao.deleteById(cid);
	}

	@Override
	public CommentsDto updateComment(CommentsDto dto) {
		int cid = com_dao.save(modelmap.map(dto, Comments.class)).getCid();
		dto.setCid(cid);
		return dto;
	}

	@Override
	public List<CommentsDto> commentsOfPostById(int id) {
		return com_dao.findByPid(id).stream().map(comments -> modelmap.map(comments, CommentsDto.class)).collect(Collectors.toList());
	}

}
