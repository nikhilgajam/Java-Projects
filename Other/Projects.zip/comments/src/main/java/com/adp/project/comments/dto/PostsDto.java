package com.adp.project.comments.dto;

import java.util.List;

import com.adp.project.comments.model.Comments;

import lombok.Data;

@Data
public class PostsDto {
	private int pid;
	private String author;
	private String title;
	private String description;
//	List<Comments> comments;
}
