/**
 * 
 */
/**
 * @author gajamnik
 *
 */
module practice {
}