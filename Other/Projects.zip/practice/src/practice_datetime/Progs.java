package practice_datetime;

import java.time.LocalDate;
import java.time.MonthDay;
import java.time.Period;
import java.time.YearMonth;
import java.time.LocalTime;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;

public class Progs {
	public static void main(String[] args) {
		// 1.How to get today's date in Java 8
		System.out.println(LocalDate.now());
		
		// 2.How to get a current day, month, and year in Java 8
		LocalDate date = LocalDate.parse(LocalDate.now() + "");
		System.out.println("Date: " + date.getDayOfMonth());
		System.out.println("Month: " + date.getMonth());
		System.out.println("Year: " + date.getYear());
		
		// 3.How to get a particular date in Java 8
		date = LocalDate.parse("2023-09-20");
		System.out.println("Date: " + date.getDayOfMonth());
		System.out.println("Month: " + date.getMonth());
		System.out.println("Year: " + date.getYear());
		
		// 4.How to check if two dates are equal in Java 8
		LocalDate new_date = LocalDate.parse(LocalDate.now().toString());
		System.out.println(new_date.equals(date));
		
		// 5.How to check for recurring events e.g. birthday in Java 8
		LocalDate dob = LocalDate.parse("2001-05-24");
		MonthDay birthday = MonthDay.of(dob.getMonth(), dob.getDayOfMonth());
		MonthDay today = MonthDay.from(LocalDate.now());
		System.out.println(birthday.equals(today));
		
		// 6.How to get current Time in Java 8
		System.out.println(LocalTime.now());
		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd hh:mm:ss a");
		System.out.println(dtf.format(LocalDateTime.now()));
		
		// 7.How to add hours in time
		LocalDateTime d1 = LocalDateTime.now();
		LocalDateTime d2 = d1.plusHours(10);
		System.out.println(dtf.format(d1));
		System.out.println(dtf.format(d2));
		
		// 8.How to find Date after 1 week
		LocalDateTime ow = d1.plusWeeks(1);
		System.out.println(dtf.format(ow));
		
		// 9.Date before and after 1 year
		LocalDateTime oy = d1.plusYears(1);
		System.out.println(dtf.format(oy));
		
		// 10. How to see if a date is before or after another date in Java 8
		System.out.println(d1.isAfter(d1.minusDays(1)));
		System.out.println(d1.isBefore(d1.plusDays(1)));
		
		// 11.How to represent fixed date e.g. credit card expiry, 
		// YearMonth
		date = LocalDate.parse("2023-10-01");
		YearMonth ym = YearMonth.of(date.getYear(), date.getMonth());
		System.out.println(ym);
		
		// 12.How to check Leap Year in Java 8
		boolean isLeapYear = LocalDate.parse("2023-04-01").isLeapYear();
		System.out.println(isLeapYear);
		
		// 13.How many days, the month between two dates
		LocalDate db = LocalDate.parse("2023-04-01");
		LocalDate da = LocalDate.parse("2023-10-02");
		long months = ChronoUnit.MONTHS.between(db, da);
		Period p = Period.between(db, da);
		System.out.println(p.getDays());
		System.out.println(p.getMonths());
		System.out.println(p.getYears());
		System.out.println(months);
		
		// 14.How to parse/format date in Java 8 using predefined formatting
		DateTimeFormatter dt = DateTimeFormatter.ofPattern("dd/MMM/yyyy");
		System.out.println(dt.format(LocalDate.now()));
		
		// 15.How to parse the date in Java using custom formatting
		DateTimeFormatter tt = DateTimeFormatter.ofPattern("hh:mm:ss a");
		System.out.println(tt.format(LocalTime.now()));
		
		// 16.How to convert Date to String in Java 8, formatting dates
		System.out.println(db.toString());
		
		
		
	}
}
