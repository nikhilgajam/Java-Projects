package practice_arrays;

public class Prog8 {
	public static void main(String[] args) {
		int[] arr = {1, 5, 7, -1, 5};
		System.out.println(pairsCount(arr, 6));
	}
	
	public static int pairsCount(int[] arr, int k) {
		// Write a Java program to find all pairs of elements in an integer array whose 
		//  sum is equal to a given number?
		int count = 0;
		for(int i=0; i<arr.length; i++) {
			for(int j=i+1; j<arr.length; j++) {
				if(arr[i] + arr[j] == k) {
					count++;
				}
			}
		}
		
		return count;
	}
}
