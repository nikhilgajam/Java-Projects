package practice_arrays;

public class Prog3 {
	public static void main(String[] args) {
		
		System.out.println("String Count");
		characterCount("String");
	}
	
	public static void characterCount(String str) {
		// Java program to print count of each character in a string string.
		int[] smalls = new int[26];
		int[] caps = new int[26];
		
		for(int i=0; i<str.length(); i++) {
			int ch = (int)str.charAt(i);
			if(ch >= 65 && ch <= 90) {
				caps[ch-65]++;
			}else if(ch >= 97 && ch <= 122) {
				smalls[ch-97]++;
			}
		}
		
		for(int i=0; i<26; i++) {
			char small = (char)(i + 65);
			char cap = (char)(i + 97);
			System.out.println(small + " : " + caps[i] + ", " + cap + " : " + smalls[i]);
		}
		
	}
}
