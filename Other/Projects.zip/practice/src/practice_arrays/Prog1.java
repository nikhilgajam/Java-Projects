package practice_arrays;

public class Prog1 {
	public static void main(String[] args) {
		String[] arr = {"whats", "what is", "what is this"};
		System.out.println(longestCommonSuffix(arr));
	}
	
	public static String longestCommonPrefix(String[] arr) {
		// Given an array of N strings, find the longest common prefix among all strings present in the array.
		// O(m*n)
		
		String ans = arr[0];
		
		for(int i=0; i<arr.length; i++) {
			while(arr[i].indexOf(ans) != 0) {
				ans = ans.substring(0, ans.length()-1);
				
				if(ans.isEmpty()) {
					return "-1";
				}
			}
		}
		
		return ans;
		
	}
	
	public static String reverseString(String str) {
		String ans = "";
		for(int i=str.length()-1; i>=0; i--) {
			ans += str.charAt(i);
		}
		
		return ans;
	}
	
	public static String longestCommonSuffix(String[] arr) {
		
		for(int i=0; i<arr.length; i++) {
			arr[i] = reverseString(arr[i]);
		}
		
		String ans = arr[0];
		
		for(int i=0; i<arr.length; i++) {
			while(arr[i].indexOf(ans) != 0) {
				ans = ans.substring(0, ans.length()-1);
				
				if(ans.isEmpty()) {
					return "-1";
				}
			}
		}
		
		return ans;
		
	}
	
	
	
	
	
	

}
