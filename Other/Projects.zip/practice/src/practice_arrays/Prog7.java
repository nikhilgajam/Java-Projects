package practice_arrays;

public class Prog7 {
	public static void main(String[] args) {
		int arr[] = {1, 2, 3, 4};
		System.out.println(absSumDifPairs(arr));
	}
	
	public static int absSumDifPairs(int[] arr) {
		/*
		 * Given a sorted array of distinct elements, the task is to find the summation of 
		  absolute differences of all pairs in the given array.
		
		  Examples: 
		
		 Input : arr[] = {1, 2, 3, 4}
		 Output: 10
		 Sum of |2-1| + |3-1| + |4-1| +
		       |3-2| + |4-2| + |4-3| = 10
		 */
		// O(n)
		int n = arr.length;
		int sum = 0;
		for(int i=0; i<n; i++) {
			sum += i * arr[i] - (n-1-i) * arr[i];
		}
		
		return sum;
	}
}
