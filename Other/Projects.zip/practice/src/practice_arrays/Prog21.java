package practice_arrays;

import java.util.*;

public class Prog21 {
	
	public static void main(String[] args) {
		// Given an unsorted array of integers, find the length of the longest consecutive elements sequence?
		
		int arr[] = {36, 41, 56, 35, 44, 33, 34, 92, 43, 32, 42};
		System.out.println("Length: " + longestConsecutiveElementsSequence(arr));
		
	}
	
	public static int longestConsecutiveElementsSequence(int[] arr) {
		// O(n)
		
		HashSet<Integer> set = new HashSet<>();
		ArrayList<Integer> list = new ArrayList<>();
		
		int ans = 0;
		
		for(int i=0; i<arr.length; i++) {
			set.add(arr[i]);
			list.add(arr[i]);
		}
		
		for(int i=0; i<arr.length; i++) {
			int num = arr[i];
			if(!set.contains(num-1)) {
				int count = 0;
				while(set.contains(num)) {
					count++;
					num++;
				}
				
				ans = Math.max(ans, count);
			}
		}
		
		Collections.sort(list);
		
		for(int i=0; i<ans; i++) {
			System.out.print(list.get(i) + " ");
		}
		
		System.out.println();
		
		return ans;
		
	}

}
