package practice_arrays;

import java.util.Map;
import java.util.HashMap;

public class Prog10 {
	
	public static void main(String[] args) {
		int[] arr = {10, 20, 20, 10, 10, 20, 5, 20};
		countOccurences(arr);
	}
	
	public static void countOccurences(int[] arr) {
		// Write a Java program to count occurrences of each element in an array?
		// O(n)
		HashMap<Integer, Integer> map = new HashMap<>();
		
		for(int i=0; i<arr.length; i++) {
			if(map.containsKey(arr[i])) {
				map.put(arr[i], map.get(arr[i])+1);
			}else {
				map.put(arr[i], 1);
			}
		}
		
		for(Map.Entry<Integer, Integer> entry : map.entrySet()) {
			System.out.println(entry.getKey() + " : " + entry.getValue());
		}
	}

}
