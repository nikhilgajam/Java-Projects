package practice_arrays;

public class Prog30 {
	public static void main(String[] args) {
		int[] a = {1, 3, 5, 7, 9};
		int arr[] = rightRotation(a, 2);
		
		for(int i=0; i<a.length; i++) {
			System.out.print(arr[i] + " ");
		}
	}
	
	public static int[] leftRotation(int[] arr, int k) {
		// How to rotate an array left and right by a given number K?
		// O(n)
		int[] ans = new int[arr.length];
		
		int j = 0;
		for(int i=k; i<arr.length; i++) {
			ans[j++] = arr[i];
		}
		
		
		for(int i=0; i<k; i++) {
			ans[j++] = arr[i];
		}
		
		return ans;
	}
	
	public static int[] rightRotation(int[] arr, int k) {
		int[] ans = new int[arr.length];
		
		int j=0;
		for(int i=arr.length-k; i<arr.length; i++) {
			ans[j++] = arr[i];
		}
		
		for(int i=0; i<arr.length-k; i++) {
			ans[j++] = arr[i];
		}
		
		return ans;
	}
}
