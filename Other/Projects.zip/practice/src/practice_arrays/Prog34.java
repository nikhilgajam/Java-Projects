package practice_arrays;

public class Prog34 {
	public static void main(String[] args) {
		int[] arr = {-2, -3, 4, -1, -2, 1, 5, 3};
		System.out.println(contiguousSubarray(arr));
	}
	
	public static int contiguousSubarray(int[] arr) {
		// Given an integer array, find the contiguous subarray (containing at least one number) 
		// which has the largest sum and return its sum?
		
		// Kadane's algorithm O(n)
		int ans = Integer.MIN_VALUE;
		int sum = 0;
		
		for(int i=0; i<arr.length; i++) {
			sum += arr[i];
			
			if(ans < sum)
				ans = sum;
			
			if(sum < 0)
				sum = 0;
		}
		
		return ans;
	}
}
