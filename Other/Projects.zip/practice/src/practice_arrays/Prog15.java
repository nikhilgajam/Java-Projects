package practice_arrays;

import java.util.*;

public class Prog15 {
	public static void main(String[] args) {
		int[] arr = {1, 2, 3, 6, 3, 6, 1};
		
		duplicateNumbers(arr);
	}
	
	public static void duplicateNumbers(int[] arr) {
		// How do you find the duplicate number on a given integer array?
		// O(n)
		String s = "";
		for(int i=0; i<arr.length; i++) {
			s += arr[i];
		}
		
		HashMap<Character, Integer> map = new HashMap<>();
		
		for(int i=0; i<s.length(); i++) {
			
			int ch = 0;
			int count = 0;
			while((ch = s.indexOf(s.charAt(i), ch)) != -1) {
				ch++;
				count++;
			}
			
			if(count > 1)
				map.put(s.charAt(i), count);
		}
		
		
		for(Map.Entry<Character, Integer> entry : map.entrySet()) {
			System.out.println(entry.getKey() + " : " + entry.getValue());
		}
		
	}
}
