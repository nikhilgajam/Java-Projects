package practice_arrays;

public class BinarySearch {
	public static void main(String[] args) {
//		int[] arr = {1, 5, 8, 12, 16, 23, 38, 56, 72, 91};
		int[] arr = {1, 2, 3, 4, 10, 40};
		System.out.println(binarySearch(arr, 1));
	}
	
	public static int binarySearch(int[] arr, int x) {
		int l = 0, h = arr.length-1, m;
		while(l <= h) {
			m = l + (h-1)/2; // m = (l+h)/2
			if(arr[m] == x) {
				return m;
			}
			if(arr[m] < x) {
				l = m+1;
			}else {
				h = m-1;
			}
		}
		
		return -1;
	}
}
