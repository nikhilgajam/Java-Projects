package practice_arrays;

import java.util.*;

public class Prog6 {
	public static void main(String[] args) {
		/*
		 * Given two sorted arrays, find their union and intersection.

  		   Example:

  			Input: arr1[] = {1, 3, 4, 5, 7}
        	arr2[] = {2, 3, 5, 6} 
  			Output: 
  			Union : {1, 2, 3, 4, 5, 6, 7} 
         	Intersection : {3, 5}
		 * 
		 */
		int arr1[] = {1, 3, 4, 5, 7};
        int arr2[] = {2, 3, 5, 6};
		union(arr1, arr2);
		intersection(arr1, arr2);
	}
	
	public static void union(int[] arr1, int[] arr2) {
		HashSet<Integer> set = new HashSet<>();
		
		for(int i=0; i<arr1.length; i++) {
			set.add(arr1[i]);
		}
		
		for(int i=0; i<arr2.length; i++) {
			set.add(arr2[i]);
		}
		
		System.out.println(set);
	}
	
	
	public static void intersection(int[] arr1, int[] arr2) {
		HashSet<Integer> set = new HashSet<>();
		ArrayList<Integer> ans = new ArrayList<>();
		
		for(int i=0; i<arr1.length; i++) {
			set.add(arr1[i]);
		}
		
		for(int i=0; i<arr2.length; i++) {
			if(set.contains(arr2[i])) {
				ans.add(arr2[i]);
			}
		}
		
		System.out.println(ans);
	}
	
}
