package practice_arrays;

import java.util.Stack;

public class Prog2 {
	public static void main(String[] args) {
		char[] arr = {'{', '}', '(', ')', '[', ']'};
		System.out.println(correctPairs(arr));
	}
	
	public static boolean correctPairs(char[] arr) {
		// Given an expression string exp, write a program to examine whether the pairs and the 
		//  orders of “{“, “}”, “(“, “)”, “[“, “]” are correct in exp.
		// O(n)
		Stack<Character> stack = new Stack<>();
		
		for(int i=0; i<arr.length; i++) {
			if(arr[i] == '{' || arr[i] == '(' || arr[i] == '[') {
				stack.push(arr[i]);
			}
			
			if(arr[i] == '}' && stack.peek() == '{') {
				stack.pop();
			}else if(arr[i] == ')' && stack.peek() == '(') {
				stack.pop();
			}if(arr[i] == ']' && stack.peek() == '[') {
				stack.pop();
			}
			
		}
		
		return stack.isEmpty();
	}
}
