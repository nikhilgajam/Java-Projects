package practice_mixed;

public class Prog10 {
	public static void main(String[] args) {
		System.out.println(checkThreeDecimalsAreSame(25.586, 25.589));
	}
	
	public static boolean checkThreeDecimalsAreSame(double a, double b) {
		/*
		 * 10.  Write a Java program that reads two floating-point numbers and tests whether they are the same up to three decimal places.
			Test Data
			Input floating-point number: 25.586
			Input floating-point another number: 25.589
			Expected Output :
			They are different
		 */
		String s1 = a + "";
		String s2 = b + "";
		
		s1 = s1.substring(0, s1.indexOf(".")+4);
		s2 = s2.substring(0, s2.indexOf(".")+4);
		
		return s1.equals(s2);
		
	}
}
