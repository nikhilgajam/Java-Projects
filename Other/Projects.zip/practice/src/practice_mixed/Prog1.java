package practice_mixed;

import java.util.*;

public class Prog1 {
	public static void main(String[] args) {
		int[] arr = {1, 4, 17, 7, 25, 3, 100};
		kLargest(arr, 3);
	}
	
	public static void kLargest(int[] arr, int k) {
		/*
		 * 1. Write a Java program to find the k largest elements in a given array. Elements in the array can be in any order.
			
			Expected Output:
			Original Array:
			[1, 4, 17, 7, 25, 3, 100]
			3 largest elements of the said array are:
			100 25 17
		 */
		Arrays.sort(arr);
		LinkedHashSet<Integer> set = new LinkedHashSet<>();
		
		for(int i=arr.length-1; i>=0; i--) {
			set.add(arr[i]);
		}
		
		int c = 0;
		for(int i: set) {
			System.out.println(i);
			c++;
			
			if(c==k)
				break;
		}
	}
	
}
