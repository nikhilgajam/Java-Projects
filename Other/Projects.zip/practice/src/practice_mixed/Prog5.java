package practice_mixed;

public class Prog5 {
	public static void main(String[] args) {
		System.out.println(divideUsingSubtraction(84, 5));
	}
	
	public static int divideUsingSubtraction(int dividend, int divisor) {
		/*
		 * 5.  Write a Java program to divide the two given integers using the subtraction operator.
			
			Expected Output:
			Input the dividend: 625
			Input the divider: 25
			Result: 25.0
		 */
		boolean flag = false;
		if(divisor < 0) {
			flag = true;
			divisor = -divisor;
		}
		
		int c = 0;
		while(dividend >= divisor) {
			c++;
			dividend -= divisor;
		}
		
		if(flag)
			return -c;
		else
			return c;
	}
}
