package practice_mixed;

public class Prog9 {
	public static void main(String[] args) {
		System.out.println(multiplyWithoutOperator(100, 10));
	}
	
	public static int multiplyWithoutOperator(int a, int b) {
		
		/*
		 * 9. Write a Java program to multiply two given integers without using the multiply operator (*).
			
			Input the first number: 25
			Input the second number: 5
			Result: 125
		 */
		
		boolean flag_a = false, flag_b = false;
		
		if(a < 0) {
			flag_a = true;
			a = - a;
		}
		if(b < 0) {
			flag_b = true;
			b = -b;
		}
		
		int ans = 0;
		for(int i=0; i<b; i++) {
			ans += a;
		}
		
		if(flag_a && flag_b)
			return ans;
		else if(flag_a || flag_b)
			return -ans;
		else
			return ans;
	}
}
