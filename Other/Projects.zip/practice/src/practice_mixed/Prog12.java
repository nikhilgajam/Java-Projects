package practice_mixed;

public class Prog12 {
	public static void main(String[] args) {
		orderPrinting(1524, 2345, 3321);
	}
	
	public static void orderPrinting(int a, int b, int c) {
		/*
		 * 12.  Write a program that accepts three numbers from the user and prints "increasing" if the numbers are in increasing order, 
			"decreasing" if the numbers are in decreasing order, and "Neither increasing or decreasing order" otherwise.
			Test Data
			Input first number: 1524
			Input second number: 2345
			Input third number: 3321
			Expected Output :
			
			Increasing order
		 */
		if(b > a && c > b) {
			System.out.println("Increasing order");
		}else if(b < a && c < b) {
			System.out.println("Decreasing order");
		}else {
			System.out.println("Neither increasing nor decreasing");
		}
	}
}
