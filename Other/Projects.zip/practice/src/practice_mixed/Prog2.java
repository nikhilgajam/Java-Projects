package practice_mixed;

import java.util.*;

public class Prog2 {
	public static void main(String[] args) {
		int[] arr = {1, 4, 17, 7, 25, 3, 100};
		kthSmallestAndLargest(arr, 2);
	}
	
	public static void kthSmallestAndLargest(int[] arr, int k) {
		/*
		 * 2. Write a Java program to find the kth smallest and largest element in a given array. Elements in the array can be in any order.

			Expected Output:
			Original Array:
			[1, 4, 17, 7, 25, 3, 100]
			K'th smallest element of the said array:
			3
			K'th largest element of the said array:
			25
		 */
		Arrays.sort(arr);
		System.out.println(arr[0+(k-1)]);
		System.out.println(arr[arr.length-k]);
	}
}
