package practice_mixed;

public class Prog3 {
	public static void main(String[] args) {
		System.out.println(sentenceReversal("The quick brown fox jumps over the lazy dog"));
	}
	
	public static String sentenceReversal(String str) {
		/*
		 * 13. Write a Java program to reverse a sentence (assume a single space between two words) without reverse every word.
			
			Input a string: The quick brown fox jumps over the lazy dog
			Result: dog lazy the over jumps fox brown quick The

		 */
		String[] arr = str.split(" ");
		String ans = "";
		
		for(int i=arr.length-1; i>=0; i--) {
			ans += arr[i] + " ";
		}
		
		return ans.substring(0, ans.length()-1);
	}
	
}
