package predefined_functional_interfaces;

import java.util.function.BiConsumer;
import java.util.function.BiFunction;
import java.util.function.BiPredicate;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.function.Supplier;


public class PredefinedFunctionalInterfaces {
	
	public static void main(String[] args) {
		
		System.out.println("Hello World");
		
		Predicate<Integer> p = n -> n%2==0;
		System.out.println(p.test(100));
		
		Function<Integer, Integer> pr = n -> n%2;
		System.out.println(pr.apply(99));
		
		Consumer<Integer> prt = n -> {int k = n%2; System.out.println(k);};
		prt.accept(100);
		
		Supplier<Double> prtk = () -> Math.random();
		System.out.println(prtk.get());
		
		BiPredicate<Integer, Integer> bp = (n1, n2) -> n1%n2==0;
		System.out.println(bp.test(100, 100));
		
		BiFunction<Integer, Integer, Integer> bpr = (n1, n2) -> n1+n2;
		System.out.println(bpr.apply(1000, 1));
		
		BiConsumer<Integer, Integer> bprt = (n1, n2) -> System.out.println(n1*n2);
		bprt.accept(1000, 1000);
		
	}
	
}
