package practice_string;

import java.util.LinkedHashSet;

public class Prog01 {
	public static void main(String[] args) {
		System.out.println(uniqueCharacters("String Operations"));
	}
	
	public static String uniqueCharacters(String str) {
		str = str.replace(" ", "");
		LinkedHashSet<Character> set = new LinkedHashSet<>();
		
		for(int i=0; i<str.length(); i++) {
			set.add(str.charAt(i));
		}
		
		String ans = "";
		for(char c : set) {
			ans += c;
		}
		
		return ans;
	}
}
