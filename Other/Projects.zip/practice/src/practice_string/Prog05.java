package practice_string;

public class Prog05 {
	public static void main(String[] args) {
		permutations("aab", "");
	}
	
	public static void permutations(String s, String ans) {
		// How do you find all the permutations of a string?
		if(s.isEmpty()) {
			System.out.println(ans);
			return;
		}
		
		for(int i=0; i<s.length(); i++) {
			char ch = s.charAt(i);
			String ros = s.substring(0, i) + s.substring(i+1);
			permutations(ros, ans+ch);
		}
	}
}
