package practice_string;

import java.util.HashSet;

public class Prog19 {
	
	static HashSet<String> set = new HashSet<>(); 
	
	public static void main(String[] args) {
		System.out.println(permutation("xxyz", "yxzx"));
	}
	
	/*
	 * 19. Write a Java program to check if a given string is a permutation of another given string.
		Sample Output:
		Original strings: xxyz yxzx
		true
	 */
	
	public static boolean permutation(String s1, String s2) {
		permutations(s1, "");
		return set.contains(s2);
	}
	
	public static void permutations(String s, String ans) {
		if(s.isEmpty()) {
			set.add(ans);
		}
		
		for(int i=0; i<s.length(); i++) {
			char ch = s.charAt(i);
			String ros = s.substring(0, i) + s.substring(i+1);
			permutations(ros, ans+ch);
		}
	}
}
