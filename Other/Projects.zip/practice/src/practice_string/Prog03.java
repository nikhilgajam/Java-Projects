package practice_string;

import java.util.ArrayList;

public class Prog03 {
	public static void main(String[] args) {
		longestPalindromicSubstring("peeks");
	}
	
	public static boolean isPalindrome(String str) {
		String s = "";
		for(int i=str.length()-1; i>=0; i--) {
			s += str.charAt(i);
		}
		
		return str.equals(s);
	}
	
	public static void longestPalindromicSubstring(String str) {
		// Finding the Longest Palindromic Substring - String Operations
		str = str.toUpperCase();
		int n = str.length();
		int max = 0;
		
		ArrayList<String> list = new ArrayList<>();
		
		for(int i=0; i<n; i++) {
			for(int j=i+2; j<n; j++) {
				String s = str.substring(i, j);
				if(isPalindrome(s) && s.length() >= max) {
					list.add(s);
					max = Math.max(max, s.length());
				}
			}
		}
		
		System.out.println(list);
	}
}
