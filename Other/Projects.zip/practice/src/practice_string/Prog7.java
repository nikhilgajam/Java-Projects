package practice_string;

public class Prog7 {
	public static void main(String[] args) {
		System.out.println(clockWiseCheck("amazon", "azonam"));
		System.out.println(antiClockCheck("amazon", "onamaz"));
	}
	
	/*
	 * 7. Given two strings, write a java program to find if a string can be obtained by rotating another string by two places. 
			Input: string1 = “amazon”, string2 = “azonam” 
			Output: Yes 
			Explanation: Rotating string1 by 2 places in anti-clockwise gives the string2.
			
			Input: string1 = “amazon”, string2 = “onamaz” 
			Output: Yes 
			Explanation: Rotating string1 by 2 places in clockwise gives the string2.
	 */
	
	public static boolean clockWiseCheck(String s1, String s2) {
		String ans = "";
		for(int i=2; i<s1.length(); i++) {
			ans += s1.charAt(i);
		}
		
		for(int i=0; i<2; i++) {
			ans += s1.charAt(i);
		}
		
		return s2.equals(ans);
	}
	
	public static boolean antiClockCheck(String s1, String s2) {
		String ans = "";
		for(int i=s1.length()-2; i<s1.length(); i++) {
			ans += s1.charAt(i);
		}
		
		for(int i=0; i<s1.length()-2; i++) {
			ans += s1.charAt(i);
		}
		
		return s2.equals(ans);
	}
}
