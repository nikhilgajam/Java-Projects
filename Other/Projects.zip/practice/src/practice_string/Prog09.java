package practice_string;

public class Prog09 {
	
	public static void main(String[] args) {
		System.out.println(firstNonRepeatingChar("heyh"));
	}
	
	public static char firstNonRepeatingChar(String str) {
		// How do you print the first non-repeated character from a string?
		for(int i=0; i<str.length(); i++) {
			int ch = str.charAt(i);
			if(str.indexOf(ch, str.indexOf(ch) + 1) == -1) {
				return str.charAt(i);
			}
		}
		
		return '$';
	}

}
