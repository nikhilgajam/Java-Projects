package practice_string;

public class Prog4 {
	public static void main(String[] args) {
		System.out.println(pangram("The quick brown fox jumps over the lazy dog"));
	}
	
	public static boolean pangram(String str) {
		// 4. Write a java program to check whether given string is pangram or not?
		//  Hint: Pangram is string which consists of all alphabets
		str = str.replace(" ", "");
		str = str.toUpperCase();
		
		int[] arr = new int [26];
		
		for(int i=0; i<str.length(); i++) {
			int ch = str.charAt(i)-65;
			arr[ch]++;
		}
		
		for(int i=0; i<arr.length; i++) {
			if(arr[i] == 0)
				return false;
		}
		
		return true;
		
		
	}
}
