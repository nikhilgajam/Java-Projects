package practice_string;

public class Prog2 {
	public static void main(String[] args) {
		System.out.println(numOfOccurs("dhimanman", "man"));
		System.out.println(numOfOccurs("aaaaa", "aa"));
	}
	
	public static int numOfOccurs(String str, String pattern) {
		// 2. Write a java program to find the number of occurrences of the given pattern.
		int ch = -1;
		int count = -1;
		while(true) {
			ch = str.indexOf(pattern, ch+1);
			count++;
			
			if(ch == -1)
				break;
		}
		
		return count;
	}
}
