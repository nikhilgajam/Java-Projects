package practice_string;

import java.util.Arrays;

public class Prog04 {
	public static void main(String[] args) {
		System.out.println(anagrams("arm", "ram"));
	}
	
	public static boolean anagrams(String a, String b) {
		if(a.length() != b.length())
			return false;
		
		a = a.toUpperCase();
		b = b.toUpperCase();
		
		int[] arr1 = new int[26];
		int[] arr2 = new int[26];
		
		Arrays.fill(arr1, 0);
		Arrays.fill(arr2, 0);
		
		for(int i=0; i<a.length(); i++) {
			int ch = (int)a.charAt(i)-65;
			arr1[ch]++;
			ch = (int)b.charAt(i)-65;
			arr2[ch]++;
		}
		
		return Arrays.equals(arr1, arr2);
		
//		for(int i=0; i<arr1.length; i++) {
//			if(arr1[i] != arr2[i]) {
//				return false;
//			}
//		}
//		
//		return true;
	}
}
