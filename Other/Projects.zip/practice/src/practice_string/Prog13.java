package practice_string;

public class Prog13 {
	public static void main(String[] args) {
		fizzBuzz();
	}
	
	// 13. Write a Java program that iterates integers from 1 to 100. For multiples of three print "Fizz" instead of the number 
	// and print "Buzz" for five. When the number is divided by three and five, print "fizz buzz".
	
	public static void fizzBuzz() {
		for(int i=1; i<=100; i++) {
			if(i%3 == 0 && i%5 == 0) {
				System.out.println("Fizz Buzz");
			}else if(i%3 == 0) {
				System.out.println("Fizz");
			}else if(i%5 == 0) {
				System.out.println("Buzz");
			}else {
				System.out.println(i);
			}
		}
	}
}
