package practice_string;

import java.util.*;

public class Prog8 {
	public static void main(String[] args) {
		vowelOccurrences("heyok");
	}
	
	public static void vowelOccurrences(String str) {
		// 8. Write a method that returns number of occurrences of a each ovel in a string.
		str = str.toLowerCase();
		HashMap<Character, Integer> map = new HashMap<>();
		for(int i=0; i<str.length(); i++) {
			char ch = str.charAt(i);
			if("aeiou".indexOf(str.charAt(i)) != -1) {
				if(map.containsKey(ch)) {
					map.put(ch, map.get(ch)+1);
				}else {
					map.put(ch, 1);
				}
			}
		}
		
		for(Map.Entry<Character, Integer> entry: map.entrySet()) {
			System.out.println(entry.getKey() + " : " + entry.getValue());
		}
	}
}
