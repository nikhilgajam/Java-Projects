package practice_string;

import java.util.ArrayList;

public class Prog02 {
	public static void main(String[] args) {
		longestSubstrWithoutReps("printer");
	}
	
	public static void longestSubstrWithoutReps(String str) {
		// Longest Substring Without Repeating Characters - String Manipulation
		int n = str.length();
		str = str.toUpperCase();
		int max = 0;
		
		ArrayList<String> list = new ArrayList<>();
		ArrayList<String> ans_list = new ArrayList<>();
		
		for(int i=0; i<n; i++) {
			String ans = str.charAt(i) + "";
			
			int j = i+1;
			char ch;
			
			while(j < n && ans.indexOf( ( ch = str.charAt(j) ) ) == -1) {
				ans += ch;
				j++;
			}
			
			if(ans.length() >= max) {
				list.add(ans);
				max = Math.max(max, ans.length());
			}
		}
		
		for(int i=0; i<list.size(); i++) {
			String s = list.get(i);
			if(s.length() == max) {
				ans_list.add(s);
			}
		}
		
		System.out.println(ans_list);
		
	}
}
