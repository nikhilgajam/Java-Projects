package practice_string;

public class Prog06 {
	public static void main(String[] args) {
		System.out.println(allDigits("12345678"));
	}
	
	public static boolean allDigits(String s) {
		
		// How do you check if a string contains only digits? 
		for(int i=0; i<s.length(); i++) {
			if("0123456789".indexOf(s.charAt(i)) == -1)   // Character.isDigit(s.charAt(i)) == false
				return false;
		}
		
		return true;
	}
}
