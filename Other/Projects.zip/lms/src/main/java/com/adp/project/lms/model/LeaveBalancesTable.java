package com.adp.project.lms.model;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Table(name="season2_batch1_team2_leavebalancestable")
@Setter
@Getter
@NoArgsConstructor
@AllArgsConstructor
public class LeaveBalancesTable {
	@Id
	private int employeeid;
	private int sickleaves;
	private int maternityleaves;
	private int paternityleaves;
	private int privilegedleaves;
	
	@Override
	public String toString() {
		return "LeaveBalancesTable [employeeid=" + employeeid + ", sickleaves=" + sickleaves + ", maternityleaves="
				+ maternityleaves + ", paternityleaves=" + paternityleaves + ", privilegedleaves=" + privilegedleaves
				+ "]";
	}
	
	
}
