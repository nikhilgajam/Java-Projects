package com.adp.project.lms.dao;

import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.adp.project.lms.model.LeaveTransaction;

@Repository
public interface LeaveTransactionDao extends JpaRepository<LeaveTransaction, Integer> {
	public List<LeaveTransaction> findByEmployeeid(int employeeid);
	public List<LeaveTransaction> findByManagerid(int managerid);
}
