package com.adp.project.lms.service;

import java.util.List;
import com.adp.project.lms.model.LeaveBalancesTable;

public interface LeaveBalancesTableService {
	public List<LeaveBalancesTable> showLeaveBalances(int empid);
}
