package com.adp.project.lms.dao;

import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.adp.project.lms.model.LeaveBalancesTable;

@Repository
public interface LeaveBalancesTableDao extends JpaRepository<LeaveBalancesTable, Integer>{
	public List<LeaveBalancesTable> findByEmployeeid(int employeeid);
}
