package com.adp.project.lms.service;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.adp.project.lms.dao.EmployeeDao;
import com.adp.project.lms.model.Employee;

@Service
public class EmployeeServiceImpl implements EmployeeService {
	
	@Autowired
	EmployeeDao dao;

	@Override
	public List<Employee> getAllEmployees() {
		System.out.println(dao.findById(1).get());
		return dao.findAll();
	}

	
}
