package com.adp.project.lms.service;

import java.util.List;
import com.adp.project.lms.model.LeaveTransaction;

public interface LeaveTransactionService {
	
	public void applyLeave(int emp_id, String startdate, String enddate, int leavecount, String leavetype, String reason);
	public List<LeaveTransaction> showPendingLeaves(int manager_id);
	public void acceptOrReject(int managerid, String status, String comments);
	public List<LeaveTransaction> empLeaveHistory(int emp_id);
	
}
