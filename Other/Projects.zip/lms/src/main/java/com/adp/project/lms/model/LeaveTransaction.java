package com.adp.project.lms.model;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Table(name="season2_batch1_team2_leavetransaction")
@Setter
@Getter
@NoArgsConstructor
@AllArgsConstructor
public class LeaveTransaction {
	@Id
	private int leaveid;
	private int employeeid;
	private int managerid;
	private String startdate;
	private String enddate;
	private String leavetype;
	private int leavecount;
	private String status;
	private String reason;
	private String comments;
	
	@Override
	public String toString() {
		return "LeaveTransaction [leaveid=" + leaveid + ", employeeid=" + employeeid + ", managerid=" + managerid
				+ ", startdate=" + startdate + ", enddate=" + enddate + ", leavetype=" + leavetype + ", leavecount="
				+ leavecount + ", status=" + status + ", reason=" + reason + ", comments=" + comments + "]";
	}
	
}
