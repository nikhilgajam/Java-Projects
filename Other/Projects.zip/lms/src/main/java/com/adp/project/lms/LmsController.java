package com.adp.project.lms;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import com.adp.project.lms.service.EmployeeService;
import com.adp.project.lms.service.LeaveBalancesTableService;
import com.adp.project.lms.service.LeaveTransactionService;

import jakarta.servlet.http.HttpServletRequest;

@Controller
public class LmsController {
	
	@Autowired
	EmployeeService emp_ser;
	
	@Autowired
	LeaveTransactionService lt_ser;
	
	@Autowired
	LeaveBalancesTableService lb_ser;
	
	@GetMapping("/")
	public String home() {
		System.out.println(emp_ser.getAllEmployees());
		return "home";
	}
	
	@GetMapping("/home")
	public String homes(HttpServletRequest request, Model model) {
		return "home";
	}
	
	@GetMapping("/employeeportal")
	public String employeeportal(HttpServletRequest request, Model model) {
		return "employeeportal";
	}
	
	@GetMapping("/empLeaveApply")
	public String empLeaveApply(HttpServletRequest request, Model model) {
		return "empLeaveApply";
	}
	
	@PostMapping("/empapp")
	public String empapp(HttpServletRequest request, Model model) {
		int empid = Integer.parseInt(request.getParameter("empid"));
		String startdate = request.getParameter("startdate").replace("/", "-");
		String enddate = request.getParameter("enddate").replace("/", "-");
		int leavecount = Integer.parseInt(request.getParameter("leavecount"));
		String leavetype = request.getParameter("leavetype");
		String reason = request.getParameter("reason");
		
		lt_ser.applyLeave(empid, startdate, enddate, leavecount, leavetype, reason);
		
		return "/employeeportal";
	}
	
	@GetMapping("/empCheckLeaveStatus")
	public String checkLeaveStatus(HttpServletRequest request, Model model) {
		return "empCheckLeaveStatus";
	}
	
	@PostMapping("/empls")
	public String empLeaveStatus(HttpServletRequest request, Model model){
		int empid = Integer.parseInt(request.getParameter("empid"));
		model.addAttribute("empleavedata", lt_ser.empLeaveHistory(empid));
		return "empCheckLeaveStatus";
	}
	
	@GetMapping("/empCheckLeaveBalances")
	public String checkLeaveBalances(HttpServletRequest request, Model model) {
		return "empCheckLeaveBalances";
	}
	
	@PostMapping("/emplb")
	public String empLeaveBalances(HttpServletRequest request, Model model) {
		int empid = Integer.parseInt(request.getParameter("empid"));
		model.addAttribute("empbalancedata", lb_ser.showLeaveBalances(empid));
		return "empCheckLeaveBalances";
	}
	
	
	@GetMapping("/managerportal")
	public String managerportal(HttpServletRequest request, Model model) {
		return "managerportal";
	}
	
	@GetMapping("/manShowPending")
	public String managerShowPending(HttpServletRequest request, Model model) {
		return "manShowPending";
	}
	
	@PostMapping("/manpl")
	public String managerPending(HttpServletRequest request, Model model) {
		int manid = Integer.parseInt(request.getParameter("manid"));
		model.addAttribute("manpendingdata", lt_ser.showPendingLeaves(manid));
		return "manShowPending";
	}
	
	@GetMapping("/manARL")
	public String managerApproveOrRejectLeave(HttpServletRequest request, Model model) {
		return "manARL";
	}
	
	@PostMapping("/manaARL")
	public String managerARL(HttpServletRequest request, Model model) {
		int manid = Integer.parseInt(request.getParameter("manid"));
		model.addAttribute("manpendingdata", lt_ser.showPendingLeaves(manid));
		return "manARL";
	}
	
	@GetMapping("/manComments/{leaveid}")
	public String managerComments(@PathVariable("leaveid") Integer leaveid, Model model) {	
		return "manComments";
	}
	
	@PostMapping("/manComm")
	public String managerCommentsUpdate(HttpServletRequest request, Model model) {
		int leaveid = Integer.parseInt(request.getParameter("leaveid"));
		String status = request.getParameter("status");
		String comments = request.getParameter("comments");
		
		lt_ser.acceptOrReject(leaveid, status, comments);
		
		return "manARL";
	}
	
}
