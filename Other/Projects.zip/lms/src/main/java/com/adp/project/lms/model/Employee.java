package com.adp.project.lms.model;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import lombok.Getter;
import lombok.Setter;

@Entity
@Table(name="season2_batch1_team2_employee")
@Setter
@Getter
@NoArgsConstructor
@AllArgsConstructor
public class Employee {
	@Id
	private int employeeid;
	private String name;
	private String gender;
	private String department;
	private String position;
	private int managerid;
	private String maritalstatus;
	
	@Override
	public String toString() {
		return "Employee [employeeid=" + employeeid + ", name=" + name + ", gender=" + gender + ", department="
				+ department + ", position=" + position + ", managerid=" + managerid + ", maritalstatus="
				+ maritalstatus + "]";
	}
	
}
