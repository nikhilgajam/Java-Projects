package com.adp.project.lms.service;

import java.util.List;
import com.adp.project.lms.model.Employee;

public interface EmployeeService {
	public List<Employee> getAllEmployees();
}
