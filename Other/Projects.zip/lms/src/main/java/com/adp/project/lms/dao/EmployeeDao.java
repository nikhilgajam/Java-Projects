package com.adp.project.lms.dao;

import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.adp.project.lms.model.Employee;

@Repository
public interface EmployeeDao extends JpaRepository<Employee, Integer> {
	public List<Employee> findByEmployeeid(int employeeid);
	public List<Employee> findByManagerid(int managerid);
}
