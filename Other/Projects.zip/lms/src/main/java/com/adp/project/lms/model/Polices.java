package com.adp.project.lms.model;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Table(name="season2_batch1_team2_policies")
@Setter
@Getter
@NoArgsConstructor
@AllArgsConstructor
public class Polices {
	@Id
	private int leaveid;
	private String leavetype;
	private int totalcount;
	
	@Override
	public String toString() {
		return "Polices [leave_id=" + leaveid + ", leavetype=" + leavetype + ", totalcount=" + totalcount + "]";
	}
	
}
