package com.example.springworking;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.springworking.dto.StudentDto;
import com.example.springworking.service.StudentService;

import jakarta.validation.Valid;

@RestController
public class Controller {
	
	@Autowired
	StudentService student_ser;
	
	@GetMapping("/")
	public String home() {
		return "Welcome";
	}
	
	@PostMapping("/add")
	public ResponseEntity<StudentDto> add(@RequestBody @Valid StudentDto student) {
		student_ser.addStudent(student);
		return new ResponseEntity<>(student, HttpStatus.CREATED);
	}
	
	@GetMapping("/getall")
	public ResponseEntity<List<StudentDto>> getAll() {
		List<StudentDto> list = student_ser.getAll();
		return new ResponseEntity<>(list, HttpStatus.OK);
	}
	
	@GetMapping("/get/{name}")
	public ResponseEntity<StudentDto> getByName(){
		return new ResponseEntity<>(null, HttpStatus.OK);
	}
}
