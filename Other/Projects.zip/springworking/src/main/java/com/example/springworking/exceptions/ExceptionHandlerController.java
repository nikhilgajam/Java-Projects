package com.example.springworking.exceptions;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

@RestControllerAdvice
public class ExceptionHandlerController {
	@ExceptionHandler(StudentNotFoundException.class)
	public ResponseEntity<ErrorInfo> studentHandler(StudentNotFoundException e) {
		ErrorInfo ef = new ErrorInfo();
		ef.setErrorMessage(e.getMessage());
		ef.setErrorCode(HttpStatus.NOT_FOUND.value());
		return new ResponseEntity<>(ef,HttpStatus.NOT_FOUND);
	}
	
}
