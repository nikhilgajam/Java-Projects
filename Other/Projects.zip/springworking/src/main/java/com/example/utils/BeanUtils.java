package com.example.utils;

import com.example.springworking.dto.StudentDto;
import com.example.springworking.model.Student;

public class BeanUtils {
	public static Student toEntity(StudentDto student) {
		return new Student(student.getHtno(), student.getName(), student.getDept(), student.getGpa(), student.getGrade());
	}
	
	public static StudentDto toDto(Student student) {
		return new StudentDto(student.getHtno(), student.getName(), student.getDept(), student.getGpa(), student.getGrade());
	}
}
