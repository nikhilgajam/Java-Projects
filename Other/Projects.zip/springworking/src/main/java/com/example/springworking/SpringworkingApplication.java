package com.example.springworking;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
@ComponentScan(basePackages="com.example.springworking")
public class SpringworkingApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringworkingApplication.class, args);
	}

}
