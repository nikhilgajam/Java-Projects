package com.example.springworking.Dao;

import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.springworking.model.Student;

@Repository
public interface StudentDao extends JpaRepository<Student, Integer> {
	
}
