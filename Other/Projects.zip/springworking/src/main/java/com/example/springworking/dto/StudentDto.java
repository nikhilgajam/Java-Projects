package com.example.springworking.dto;

import org.hibernate.validator.constraints.Range;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class StudentDto {
	@NotNull(message="HTNO cannot be null")
	int htno;
	@NotNull(message="NAME cannot be null")
	String name;
	@NotNull(message="DEPT cannot be null")
	String dept;
	@Range(min=6, max=10)
	int gpa;
	@NotNull(message="GRADE cannot be null")
	String grade;
	
	StudentDto(StudentDto student){
		this.htno = student.htno;
		this.name = student.name;
		this.dept = student.dept;
		this.gpa = student.gpa;
		this.grade = student.grade;
	}
}
