package com.example.springworking.model;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name="batch1_nikhil_student")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Student {
	@Id
	int htno;
	String name;
	String dept;
	int gpa;
	String grade;
	
	Student(Student student){
		this.htno = student.htno;
		this.name = student.name;
		this.dept = student.dept;
		this.gpa = student.gpa;
		this.grade = student.grade;
	}
	
}
