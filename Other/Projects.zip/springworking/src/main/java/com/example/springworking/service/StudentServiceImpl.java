package com.example.springworking.service;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.springworking.Dao.StudentDao;
import com.example.springworking.dto.StudentDto;
import com.example.utils.BeanUtils;

@Service
public class StudentServiceImpl implements StudentService {
	
	@Autowired
	StudentDao student_dao;

	@Override
	public void addStudent(StudentDto student) {
		student_dao.save(BeanUtils.toEntity(student));
	}

	@Override
	public List<StudentDto> getAll() {
		return student_dao.findAll().stream().map(student -> BeanUtils.toDto(student)).collect(Collectors.toList());
	}

}
