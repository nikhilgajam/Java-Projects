package com.example.springworking.service;

import java.util.List;
import com.example.springworking.dto.StudentDto;

public interface StudentService {
	public void addStudent(StudentDto student);
	public List<StudentDto> getAll();
}
