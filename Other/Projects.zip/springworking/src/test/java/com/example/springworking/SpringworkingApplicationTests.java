package com.example.springworking;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringworkingApplicationTests {

	@Test
	void contextLoads() {
	}

}
