package com.adp.project.calendar.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.adp.project.calendar.dao.EmployeeDetailsDao;
import com.adp.project.calendar.dto.EmployeeDetailsDto;
import com.adp.project.calendar.model.EmployeeDetails;
import com.adp.project.calendar.utils.Utils;

@Service
public class EmployeeDetailsServiceImpl implements EmployeeDetailsService{
	
	@Autowired
	EmployeeDetailsDao emp_dao;

	@Override
	public List<EmployeeDetailsDto> getAll() {
		List<EmployeeDetails> list = emp_dao.findAll();
		List<EmployeeDetailsDto> dto_list = new ArrayList<>();		
		for(EmployeeDetails emp : list) {
			dto_list.add(Utils.empModelToDto(emp));
		}
		
		return dto_list;
	}

	@Override
	public EmployeeDetailsDto getEmp(int id) {
		return Utils.empModelToDto(emp_dao.findById(id).get());
	}

	@Override
	public List<EmployeeDetailsDto> getEmpsByManagerId(int id) {
		List<EmployeeDetails> list = emp_dao.findByManagerid(id);
		List<EmployeeDetailsDto> dto_list = new ArrayList<>();
		
		for(EmployeeDetails emp : list) {
			dto_list.add(Utils.empModelToDto(emp));
		}
		
		return dto_list;
	}

}
