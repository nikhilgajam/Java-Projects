package com.adp.project.calendar.service;

import java.util.List;

import com.adp.project.calendar.dto.LeavesTableDto;
import com.adp.project.calendar.dto.LeavesWithNameDto;

public interface LeavesTableService {
	public List<LeavesTableDto> getAll();
	public List<LeavesTableDto> getByManagerid(int id);
	public List<LeavesTableDto> getByEmpid(int id);
	public List<LeavesWithNameDto> getByEmpidWithName(int id);
	public List<LeavesWithNameDto> getByManidWithName(int id);
}
