package com.adp.project.calendar.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.adp.project.calendar.model.LoginDetails;

@Repository
public interface LoginDetailsDao extends JpaRepository<LoginDetails, Integer>{

}
