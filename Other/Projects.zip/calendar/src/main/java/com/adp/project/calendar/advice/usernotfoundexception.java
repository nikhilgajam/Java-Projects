package com.adp.project.calendar.advice;

public class usernotfoundexception extends Exception {
	public usernotfoundexception(String message) {
		super(message);
	}
}
