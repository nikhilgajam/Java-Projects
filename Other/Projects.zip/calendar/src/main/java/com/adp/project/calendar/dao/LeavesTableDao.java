package com.adp.project.calendar.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.adp.project.calendar.model.LeavesTable;

@Repository
public interface LeavesTableDao extends JpaRepository<LeavesTable, Integer>{
	public List<LeavesTable> findByManagerid(int id);
	public List<LeavesTable> findByEmpid(int id);
}
