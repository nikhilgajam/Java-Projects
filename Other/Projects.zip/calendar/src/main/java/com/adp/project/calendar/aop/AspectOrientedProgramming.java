package com.adp.project.calendar.aop;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.AfterThrowing;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

@Aspect
@Component
public class AspectOrientedProgramming {
	private Logger logger = LoggerFactory.getLogger(this.getClass());
    private String log = "Before invoking method {} in class ";
    
    @Before("execution(* com.adp.project.calendar.controller.*.*(..))")
    public void logBeforeController(JoinPoint joinPoint) throws Exception {
        String methodName = joinPoint.getSignature().getName();
        String className = joinPoint.getTarget().getClass().getName();
        logger.info(log + methodName, className);
        
    }
    
    @Before("execution(* com.adp.project.calendar.model.*.*(..))")
    public void logBeforeModel(JoinPoint joinPoint) throws Exception {
        String methodName = joinPoint.getSignature().getName();
        String className = joinPoint.getTarget().getClass().getName();
        
        logger.info(log + methodName, className);
    }
    
    @Before("execution(* com.adp.project.calendar.service.*.*(..))")
    public void logServiceBeforeService(JoinPoint joinPoint) throws Exception {
        String methodName = joinPoint.getSignature().getName();
        String className = joinPoint.getTarget().getClass().getName();
        
        logger.info(log + methodName, className);
    }
    
    @Before("execution(* com.adp.project.calendar.dto.*.*(..))")
    public void logServiceBeforeDto(JoinPoint joinPoint) throws Exception {
        String methodName = joinPoint.getSignature().getName();
        String className = joinPoint.getTarget().getClass().getName();
        
        logger.info(log + methodName, className);
    }
    
	@AfterThrowing(pointcut = "execution(* com.adp.project.calendar.service.*Impl.*(..))", throwing = "exception")
	public void logServiceException(Exception exception) {
		logger.error(exception.getMessage(), exception);
	}
    
}
