package com.adp.project.calendar.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.adp.project.calendar.model.EmployeeDetails;

@Repository
public interface EmployeeDetailsDao extends JpaRepository<EmployeeDetails, Integer>{
	public List<EmployeeDetails> findByManagerid(int id);
}
