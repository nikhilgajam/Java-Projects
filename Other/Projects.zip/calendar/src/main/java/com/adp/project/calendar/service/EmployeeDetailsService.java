package com.adp.project.calendar.service;

import java.util.List;
import com.adp.project.calendar.dto.EmployeeDetailsDto;

public interface EmployeeDetailsService {
	public List<EmployeeDetailsDto> getAll();
	public EmployeeDetailsDto getEmp(int id);
	public List<EmployeeDetailsDto> getEmpsByManagerId(int id);
}
