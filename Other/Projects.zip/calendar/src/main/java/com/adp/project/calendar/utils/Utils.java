package com.adp.project.calendar.utils;

import com.adp.project.calendar.dto.EmployeeDetailsDto;
import com.adp.project.calendar.dto.LeavesTableDto;
import com.adp.project.calendar.dto.LoginDetailsDto;
import com.adp.project.calendar.model.EmployeeDetails;
import com.adp.project.calendar.model.LeavesTable;
import com.adp.project.calendar.model.LoginDetails;

public class Utils {
	
	public static EmployeeDetailsDto empModelToDto(EmployeeDetails obj) {
		return new EmployeeDetailsDto(obj.getId(), obj.getFormattedname(), obj.getGivenname(), obj.getBirthdate(), obj.getJoindate(), obj.getDesignation(), obj.getWorkshift(), obj.getWeekoffs(), obj.getWorktimings(), obj.getCountrycode(), obj.getManagerid());
	}
	
	public static EmployeeDetails empDtoToModel(EmployeeDetailsDto obj) {
		return new EmployeeDetails(obj.getId(), obj.getFormattedname(), obj.getGivenname(), obj.getBirthdate(), obj.getJoindate(), obj.getDesignation(), obj.getWorkshift(), obj.getWeekoffs(), obj.getWorktimings(), obj.getCountrycode(), obj.getManagerid());
	}
	
	public static LeavesTableDto leavesModelToDto(LeavesTable obj) {
		return new LeavesTableDto(obj.getLeaveid(), obj.getEmpid(), obj.getManagerid(), obj.getLeavetype(), obj.getLeavestartdate(), obj.getLeaveenddate(), obj.getNoofdays(), obj.getReason(), obj.getComments(), obj.getStatus());
	}
	
	public static LeavesTable leavesDtoToModel(LeavesTableDto obj) {
		return new LeavesTable(obj.getLeaveid(), obj.getEmpid(), obj.getManagerid(), obj.getLeavetype(), obj.getLeavestartdate(), obj.getLeaveenddate(), obj.getNoofdays(), obj.getReason(), obj.getComments(), obj.getStatus());
	}
	
	public static LoginDetails loginDtoToModel(LoginDetailsDto obj) {
		return new LoginDetails(obj.getId(), obj.getEmail(), obj.getPassword());
	}
	
	public static LoginDetailsDto loginModelToDto(LoginDetails obj) {
		return new LoginDetailsDto(obj.getId(), obj.getEmail(), obj.getPassword());
	}
	
}
