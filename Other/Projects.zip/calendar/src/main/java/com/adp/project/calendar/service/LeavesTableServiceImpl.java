package com.adp.project.calendar.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.adp.project.calendar.dao.EmployeeDetailsDao;
import com.adp.project.calendar.dao.LeavesTableDao;
import com.adp.project.calendar.dto.LeavesTableDto;
import com.adp.project.calendar.dto.LeavesWithNameDto;
import com.adp.project.calendar.model.EmployeeDetails;
import com.adp.project.calendar.model.LeavesTable;
import com.adp.project.calendar.utils.Utils;

@Service
public class LeavesTableServiceImpl implements LeavesTableService{
	
	@Autowired
	LeavesTableDao leaves_dao;
	
	@Autowired
	EmployeeDetailsDao emp_dao;

	@Override
	public List<LeavesTableDto> getAll() {
		List<LeavesTable> list = leaves_dao.findAll();
		List<LeavesTableDto> dto_list = new ArrayList<>();
		
		for(LeavesTable emp : list) {
			dto_list.add(Utils.leavesModelToDto(emp));
		}
		
		return dto_list;
	}

	@Override
	public List<LeavesTableDto> getByManagerid(int id) {
		List<LeavesTable> list = leaves_dao.findByManagerid(id);
		List<LeavesTableDto> dto_list = new ArrayList<>();
		
		for(LeavesTable emp : list) {
			dto_list.add(Utils.leavesModelToDto(emp));
		}
		
		return dto_list;
	}

	@Override
	public List<LeavesTableDto> getByEmpid(int id) {
		List<LeavesTable> list = leaves_dao.findByEmpid(id);
		List<LeavesTableDto> dto_list = new ArrayList<>();
		
		for(LeavesTable emp : list) {
			dto_list.add(Utils.leavesModelToDto(emp));
		}
		
		return dto_list;
	}

	@Override
	public List<LeavesWithNameDto> getByEmpidWithName(int id){
		List<LeavesTable> list = leaves_dao.findByEmpid(id);
		List<LeavesWithNameDto> dto_list = new ArrayList<>();
		
		for(int i=0; i<list.size(); i++) {
			LeavesTable lt = list.get(i);
			EmployeeDetails emp = emp_dao.findById(lt.getEmpid()).get();
			dto_list.add(new LeavesWithNameDto(lt.getLeaveid(), lt.getEmpid(), emp.getGivenname(), lt.getManagerid(), lt.getLeavetype(), lt.getLeavestartdate(), lt.getLeaveenddate(), lt.getNoofdays(), lt.getReason(), lt.getComments(), lt.getStatus(), emp.getWorktimings(), emp.getWeekoffs()));
		}
		
		return dto_list;
	}

	@Override
	public List<LeavesWithNameDto> getByManidWithName(int id) {
		List<LeavesTable> list = leaves_dao.findByManagerid(id);
		List<LeavesWithNameDto> dto_list = new ArrayList<>();
		
		for(int i=0; i<list.size(); i++) {
			LeavesTable lt = list.get(i);
			EmployeeDetails emp = emp_dao.findById(lt.getEmpid()).get();
			dto_list.add(new LeavesWithNameDto(lt.getLeaveid(), lt.getEmpid(), emp.getGivenname(), lt.getManagerid(), lt.getLeavetype(), lt.getLeavestartdate(), lt.getLeaveenddate(), lt.getNoofdays(), lt.getReason(), lt.getComments(), lt.getStatus(), emp.getWorktimings(), emp.getWeekoffs()));
		}
		
		return dto_list;
	}

}
