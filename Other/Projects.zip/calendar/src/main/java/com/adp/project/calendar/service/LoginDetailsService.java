package com.adp.project.calendar.service;

import java.util.List;
import com.adp.project.calendar.dto.LoginDetailsDto;

public interface LoginDetailsService {
	public List<LoginDetailsDto> getAll();
}
