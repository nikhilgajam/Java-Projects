package com.adp.project.calendar.model;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "season2_batch1_team2_calendar_employee_details")
public class EmployeeDetails{
    @Id
    private int id;
    private String formattedname;
    private String givenname;
    private String birthdate;
    private String joindate;
    private String designation;
    private String workshift;
    private String weekoffs;
    private String worktimings;
    private String countrycode;
    private int managerid;
    
    public EmployeeDetails() {
    	
    }
    
	public EmployeeDetails(int id, String formattedname, String givenname, String birthdate, String joindate, String designation, String workshift, String weekoffs, String worktimings, String countrycode, int managerid) {
		super();
		this.id = id;
		this.formattedname = formattedname;
		this.givenname = givenname;
		this.birthdate = birthdate;
		this.joindate = joindate;
		this.designation = designation;
		this.workshift = workshift;
		this.weekoffs = weekoffs;
		this.worktimings = worktimings;
		this.countrycode = countrycode;
		this.managerid = managerid;
	}

	public int getId() {
		return id;
	}

	public String getFormattedname() {
		return formattedname;
	}

	public String getGivenname() {
		return givenname;
	}

	public String getBirthdate() {
		return birthdate;
	}

	public String getJoindate() {
		return joindate;
	}

	public String getDesignation() {
		return designation;
	}

	public String getWorkshift() {
		return workshift;
	}

	public String getWeekoffs() {
		return weekoffs;
	}

	public String getWorktimings() {
		return worktimings;
	}

	public String getCountrycode() {
		return countrycode;
	}

	public int getManagerid() {
		return managerid;
	}
    
}
