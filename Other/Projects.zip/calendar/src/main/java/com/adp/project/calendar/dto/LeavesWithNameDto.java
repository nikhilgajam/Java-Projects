package com.adp.project.calendar.dto;

public class LeavesWithNameDto {
    private int leaveid;
    private int empid;
    private String givenname;
    private int managerid;
    private String leavetype;
    private String leavestartdate;
    private String leaveenddate;
    private int noofdays;
    private String reason;
    private String comments;
    private String status;
    private String worktimings;
    private String weekoffs;
    
    public LeavesWithNameDto() {
    	
    }
    
	public LeavesWithNameDto(int leaveid, int empid, String givenname, int managerid, String leavetype, String leavestartdate, String leaveenddate, int noofdays, String reason, String comments, String status, String worktimings, String weekoffs) {
		super();
		this.leaveid = leaveid;
		this.empid = empid;
		this.givenname = givenname;
		this.managerid = managerid;
		this.leavetype = leavetype;
		this.leavestartdate = leavestartdate;
		this.leaveenddate = leaveenddate;
		this.noofdays = noofdays;
		this.reason = reason;
		this.comments = comments;
		this.status = status;
		this.worktimings = worktimings;
		this.weekoffs = weekoffs;
	}

	public int getLeaveid() {
		return leaveid;
	}

	public int getEmpid() {
		return empid;
	}

	public String getGivenname() {
		return givenname;
	}

	public int getManagerid() {
		return managerid;
	}

	public String getLeavetype() {
		return leavetype;
	}

	public String getLeavestartdate() {
		return leavestartdate;
	}

	public String getLeaveenddate() {
		return leaveenddate;
	}

	public int getNoofdays() {
		return noofdays;
	}

	public String getReason() {
		return reason;
	}

	public String getComments() {
		return comments;
	}

	public String getStatus() {
		return status;
	}

	public String getWorktimings() {
		return worktimings;
	}

	public String getWeekoffs() {
		return weekoffs;
	}
    
}
