package com.adp.project.calendar.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.adp.project.calendar.dao.LoginDetailsDao;
import com.adp.project.calendar.dto.LoginDetailsDto;
import com.adp.project.calendar.model.LoginDetails;
import com.adp.project.calendar.utils.Utils;

@Service
public class LoginDetailsServiceImpl implements LoginDetailsService{
	
	@Autowired
	LoginDetailsDao login_dao;

	@Override
	public List<LoginDetailsDto> getAll() {
		List<LoginDetails> list = login_dao.findAll();
		List<LoginDetailsDto> dto_list = new ArrayList<>();
		
		for(LoginDetails emp : list) {
			dto_list.add(Utils.loginModelToDto(emp));
		}
		
		return dto_list;
	}

}
