package com.adp.project.calendar.dto;

public class LoginDetailsDto {
    private int id;
    private String email;
    private String password;
    
    public LoginDetailsDto() {
    	
    }
    
	public LoginDetailsDto(int id, String email, String password) {
		super();
		this.id = id;
		this.email = email;
		this.password = password;
	}

	public int getId() {
		return id;
	}

	public String getEmail() {
		return email;
	}

	public String getPassword() {
		return password;
	}
    
}