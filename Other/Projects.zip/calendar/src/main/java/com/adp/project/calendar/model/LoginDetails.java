package com.adp.project.calendar.model;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "season2_batch1_team2_calendar_login_details")
public class LoginDetails {
    @Id
    private int id;
    private String email;
    private String password;
    
    public LoginDetails() {
    	
    }
    
	public LoginDetails(int id, String email, String password) {
		super();
		this.id = id;
		this.email = email;
		this.password = password;
	}

	public int getId() {
		return id;
	}

	public String getEmail() {
		return email;
	}

	public String getPassword() {
		return password;
	}
    
}