package com.adp.project.calendar.dto;

public class LeavesTableDto {
    private int leaveid;
    private int empid;
    private int managerid;
    private String leavetype;
    private String leavestartdate;
    private String leaveenddate;
    private int noofdays;
    private String reason;
    private String comments;
    private String status;
    
    public LeavesTableDto() {
    	
    }
    
	public LeavesTableDto(int leaveid, int empid, int managerid, String leavetype, String leavestartdate, String leaveenddate, int noofdays, String reason, String comments, String status) {
		super();
		this.leaveid = leaveid;
		this.empid = empid;
		this.managerid = managerid;
		this.leavetype = leavetype;
		this.leavestartdate = leavestartdate;
		this.leaveenddate = leaveenddate;
		this.noofdays = noofdays;
		this.reason = reason;
		this.comments = comments;
		this.status = status;
	}

	public int getLeaveid() {
		return leaveid;
	}

	public int getEmpid() {
		return empid;
	}

	public int getManagerid() {
		return managerid;
	}

	public String getLeavetype() {
		return leavetype;
	}

	public String getLeavestartdate() {
		return leavestartdate;
	}

	public String getLeaveenddate() {
		return leaveenddate;
	}

	public int getNoofdays() {
		return noofdays;
	}

	public String getReason() {
		return reason;
	}

	public String getComments() {
		return comments;
	}

	public String getStatus() {
		return status;
	}
    
}