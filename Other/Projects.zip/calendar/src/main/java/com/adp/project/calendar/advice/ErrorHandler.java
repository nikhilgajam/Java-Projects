package com.adp.project.calendar.advice;

import java.util.HashMap;
import java.util.Map;
import java.util.NoSuchElementException;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestControllerAdvice;

@RestControllerAdvice
@ResponseStatus(HttpStatus.BAD_REQUEST)
public class ErrorHandler {
	@ExceptionHandler(MethodArgumentNotValidException.class)
	public Map<String,String> HandleInvalidArgument(MethodArgumentNotValidException ex){
		Map<String,String> errormap= new HashMap<>();
		ex.getBindingResult().getFieldErrors().forEach(error ->{
			errormap.put(error.getField(),error.getDefaultMessage());
		});
		return errormap;
	}
	
	@ExceptionHandler(usernotfoundexception.class)
	public Map<String,String> usernotfoundhandler(usernotfoundexception ex){
		Map<String, String> errormap = new HashMap<>();
		errormap.put("error message",ex.getMessage());
		return errormap;
	}
	
	@ExceptionHandler(NoSuchElementException.class)
	public Map<String,String> nosuchfoundhandler(NoSuchElementException ex){
		Map<String, String> errormap = new HashMap<>();
		errormap.put("error message",ex.getMessage());
		return errormap;
	}

}
