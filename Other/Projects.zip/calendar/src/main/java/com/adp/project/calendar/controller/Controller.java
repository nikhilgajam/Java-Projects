package com.adp.project.calendar.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.adp.project.calendar.dto.EmployeeDetailsDto;
import com.adp.project.calendar.dto.LeavesTableDto;
import com.adp.project.calendar.dto.LeavesWithNameDto;
import com.adp.project.calendar.dto.LoginDetailsDto;
import com.adp.project.calendar.service.EmployeeDetailsService;
import com.adp.project.calendar.service.LeavesTableService;
import com.adp.project.calendar.service.LoginDetailsService;

@RestController
@RequestMapping("/calendar")
public class Controller {
	@Autowired
	EmployeeDetailsService emp_ser;
	
	@Autowired
	LeavesTableService leave_ser;
	
	@Autowired
	LoginDetailsService login_ser;
	
	
	@GetMapping("/getAllEmployees")
	@CrossOrigin("*")
	public ResponseEntity<List<EmployeeDetailsDto>> getAllEmployees() {
		return new ResponseEntity<>(emp_ser.getAll(), HttpStatus.OK);
	}
	
	@GetMapping("/getemp/{id}")
	@CrossOrigin("*")
	public ResponseEntity<EmployeeDetailsDto> getEmp(@PathVariable("id") Integer id) {
		return new ResponseEntity<>(emp_ser.getEmp(id), HttpStatus.OK);
	}
	
	@GetMapping("/getManEmps/{id}")
	@CrossOrigin("*")
	public ResponseEntity<List<EmployeeDetailsDto>> getEmpsWithManagerId(@PathVariable Integer id) {
		return new ResponseEntity<>(emp_ser.getEmpsByManagerId(id), HttpStatus.OK);
	}
	
	@GetMapping("/getAllLeaves")
	@CrossOrigin("*")
	public ResponseEntity<List<LeavesTableDto>> getAllLeaves() {
		return new ResponseEntity<>(leave_ser.getAll(), HttpStatus.OK);
	}
	
	@GetMapping("/getLeavesByManId/{id}")
	@CrossOrigin("*")
	public ResponseEntity<List<LeavesTableDto>> getLeavesByManId(@PathVariable Integer id) {
		return new ResponseEntity<>(leave_ser.getByManagerid(id), HttpStatus.OK);
	}
	
	@GetMapping("/getLeavesByManIdWithName/{id}")
	@CrossOrigin("*")
	public ResponseEntity<List<LeavesWithNameDto>> getLeavesByManIdWithName(@PathVariable Integer id) {
		return new ResponseEntity<>(leave_ser.getByManidWithName(id), HttpStatus.OK);
	}
	
	@GetMapping("/getLeavesByEmpId/{id}")
	@CrossOrigin("*")
	public ResponseEntity<List<LeavesTableDto>> getLeavesByEmpId(@PathVariable Integer id) {
		return new ResponseEntity<>(leave_ser.getByEmpid(id), HttpStatus.OK);
	}
	
//	getByEmpidWithName
	
	@GetMapping("/getLeavesByEmpIdWithName/{id}")
	@CrossOrigin("*")
	public ResponseEntity<List<LeavesWithNameDto>> getLeavesWithByEmpIdWithName(@PathVariable Integer id) {
		return new ResponseEntity<>(leave_ser.getByEmpidWithName(id), HttpStatus.OK);
	}
	
	@GetMapping("/getAllLoginDetails")
	@CrossOrigin("*")
	public ResponseEntity<List<LoginDetailsDto>> getAllLoginDetails() {
		return new ResponseEntity<>(login_ser.getAll(), HttpStatus.OK);
	}
	
}
