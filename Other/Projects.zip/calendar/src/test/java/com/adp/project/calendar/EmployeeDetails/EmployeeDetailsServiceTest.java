package com.adp.project.calendar.EmployeeDetails;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.boot.test.context.SpringBootTest;

import com.adp.project.calendar.dao.EmployeeDetailsDao;
import com.adp.project.calendar.dto.EmployeeDetailsDto;
import com.adp.project.calendar.model.EmployeeDetails;
import com.adp.project.calendar.service.EmployeeDetailsServiceImpl;

@SpringBootTest
public class EmployeeDetailsServiceTest{
	
	@Mock
	EmployeeDetailsDao emp_dao;
	@InjectMocks
	EmployeeDetailsServiceImpl emp_service;
	public List<EmployeeDetailsDto> Employee_list;
	
	@Test
	public void getAll() {
		
		List<EmployeeDetails> Employee_list = new ArrayList<>();
		Employee_list.add(new EmployeeDetails(1,"Patha Rahul","Rahul","2002-09-04","2023-09-19","member technical","Morning","6-0","10:00-18:00","IN",1));
		when(emp_dao.findAll()).thenReturn(Employee_list);
		assertEquals(1,emp_service.getAll().size());
	}
	@Test
	public void getEmpById() {
		int empid = 1;
		EmployeeDetails e = new EmployeeDetails(1,"Patha Rahul","Rahul","2002-09-04","2023-09-19","member technical","Morning","6-0","10:00-18:00","IN",1);
		when(emp_dao.findById(empid)).thenReturn(Optional.of(e));
		assertEquals(empid, emp_service.getEmp(empid).getId());
	} 
	
	@Test
	public void getByManagerId() {
		int managerid = 1;
		List<EmployeeDetails> Employee_list = new ArrayList<>();
		Employee_list.add(new EmployeeDetails(1,"Patha Rahul","Rahul","2002-09-04","2023-09-19","member technical","Morning","6-0","10:00-18:00","IN",1));
		when(emp_dao.findByManagerid(managerid)).thenReturn(Employee_list);
		assertEquals(1,emp_service.getEmpsByManagerId(managerid).size());
		
	}

}


