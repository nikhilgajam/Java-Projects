package com.adp.project.calendar;

import static org.junit.jupiter.api.Assertions.assertNotEquals;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

import com.adp.project.calendar.dto.EmployeeDetailsDto;
import com.adp.project.calendar.dto.LeavesTableDto;
import com.adp.project.calendar.dto.LeavesWithNameDto;
import com.adp.project.calendar.dto.LoginDetailsDto;
import com.adp.project.calendar.model.EmployeeDetails;
import com.adp.project.calendar.model.LeavesTable;

@SpringBootTest
class CalendarApplicationTests {

	@Test
	void contextLoads() {
	}
	
	@Test
	public void TestLoginDetailsNoargs() {
		LoginDetailsDto lg = new LoginDetailsDto();
		assertNotEquals(null, lg);
	}
	@Test
	public void TestLoginDetailsAllargs() {
		LoginDetailsDto lg = new LoginDetailsDto(1,"example@adp.com","pwd");
		assertNotEquals(null, lg);
	}
	@Test
	public void TestLeavesWithNameDtoNoArgs() {
		LeavesWithNameDto lwn = new LeavesWithNameDto();
		assertNotEquals(null, lwn);
	}
	@Test
	public void TestLeavesWithNameDtoAllArgs() {
		LeavesWithNameDto lwn = new LeavesWithNameDto(100001,511002,"rahul",511001,"Sick Leave","2023-11-21","2023-11-22",2,"Medical Reasons",null,"Requested","10:00-18:00","6-0");
		assertNotEquals(null, lwn);
	}
	@Test
	public void TestLeavesTableDtoNoArgs() {
		LeavesTableDto ltd = new LeavesTableDto(); 
		assertNotEquals(null, ltd);
	}
	@Test
	public void TestEmployeeDetailsDtoNoargs() {
		EmployeeDetailsDto edd = new EmployeeDetailsDto();
		assertNotEquals(null, edd);
	}
	@Test
	public void TestEmployeeDetailsNoargs() {
		EmployeeDetails ed = new EmployeeDetails();
		assertNotEquals(null, ed);
	}
	@Test
	public void TestLeavesTable() {
		LeavesTable lt = new LeavesTable();
		assertNotEquals(null, lt);
	}
}
