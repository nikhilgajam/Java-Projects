package com.adp.project.calendar.LoginDetails;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.boot.test.context.SpringBootTest;

import com.adp.project.calendar.dao.LoginDetailsDao;
import com.adp.project.calendar.model.LoginDetails;
import com.adp.project.calendar.service.LoginDetailsServiceImpl;

@SpringBootTest
public class LoginDetailsTest{
	@Mock
	LoginDetailsDao login_dao;
	@InjectMocks
	LoginDetailsServiceImpl login_service;
	
	
	@Test
	public void getAll() {
		List<LoginDetails> login = new ArrayList<>();
		login.add(new LoginDetails(511001,"abhinay@adp.com","abhi"));
		when(login_dao.findAll()).thenReturn(login);
		assertEquals(1,login_service.getAll().size());
		
	}
}
