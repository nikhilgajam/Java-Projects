package com.adp.project.calendar.controller;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.adp.project.calendar.dto.EmployeeDetailsDto;
import com.adp.project.calendar.dto.LeavesTableDto;
import com.adp.project.calendar.dto.LeavesWithNameDto;
import com.adp.project.calendar.dto.LoginDetailsDto;
import com.adp.project.calendar.model.LeavesTable;
import com.adp.project.calendar.service.EmployeeDetailsService;
import com.adp.project.calendar.service.LeavesTableService;
import com.adp.project.calendar.service.LoginDetailsService;

@SpringBootTest
public class ControllerTest {
	
	@Mock
	EmployeeDetailsService emp_ser;
	
	@Mock
	LeavesTableService leave_ser;
		
	@Mock
	LoginDetailsService login_ser;
	
	@InjectMocks
	Controller controller;
	
	List<EmployeeDetailsDto> EmployeeDetails;
	EmployeeDetailsDto empdetails;
	List<LeavesTableDto> leavestable;
	LeavesTableDto leave;
	List<LoginDetailsDto> logindetails;
	LoginDetailsDto login;
	List<LeavesWithNameDto> leaveswithname;
	
	@Test
	public void testGetAllEmployees() {
		EmployeeDetails = new ArrayList<>(); 
		EmployeeDetails.add(new EmployeeDetailsDto(1,"Patha Rahul","Rahul","2002-09-04","2023-09-19","member technical","Morning","6-0","10:00-18:00","IN",1));
		EmployeeDetails.add(new EmployeeDetailsDto(1,"Gajam Nikhil","Nikhil","2001-05-24","2023-09-19","member technical","Morning","6-0","10:00-18:00","IN",1));
		when(emp_ser.getAll()).thenReturn(EmployeeDetails);
		ResponseEntity<List<EmployeeDetailsDto>> res = controller.getAllEmployees();
		assertEquals(HttpStatus.OK, res.getStatusCode());
	}
	@Test
	public void testGetAllEmployeesData() {
		EmployeeDetails = new ArrayList<>(); 
		EmployeeDetails.add(new EmployeeDetailsDto(1,"Patha Rahul","Rahul","2002-09-04","2023-09-19","member technical","Morning","6-0","10:00-18:00","IN",1));
		EmployeeDetails.add(new EmployeeDetailsDto(1,"Gajam Nikhil","Nikhil","2001-05-24","2023-09-19","member technical","Morning","6-0","10:00-18:00","IN",1));
		when(emp_ser.getAll()).thenReturn(EmployeeDetails);
		ResponseEntity<List<EmployeeDetailsDto>> res = controller.getAllEmployees();
		assertEquals(2, res.getBody().size());
	}
	@Test
	public void testGetSingleEmpWithId() {
		int empid = 1;
		empdetails = new EmployeeDetailsDto(1,"Patha Rahul","Rahul","2002-09-04","2023-09-19","member technical","Morning","6-0","10:00-18:00","IN",1);
		when(emp_ser.getEmp(empid)).thenReturn(empdetails);
		ResponseEntity<EmployeeDetailsDto> res = controller.getEmp(empid);
		assertEquals(HttpStatus.OK,res.getStatusCode());
	}
	@Test
	public void testGetSingleEmpWithIdData() {
		int empid = 1;
		empdetails = new EmployeeDetailsDto(1,"Patha Rahul","Rahul","2002-09-04","2023-09-19","member technical","Morning","6-0","10:00-18:00","IN",1);
		when(emp_ser.getEmp(empid)).thenReturn(empdetails);
		ResponseEntity<EmployeeDetailsDto> res = controller.getEmp(empid);
		assertEquals(1,res.getBody().getId());
	}
	@Test
	public void testGetEmpsListWithManagerId() {
		int managerid = 1;
		EmployeeDetails = new ArrayList<>();
		EmployeeDetails.add(new EmployeeDetailsDto(1,"Patha Rahul","Rahul","2002-09-04","2023-09-19","member technical","Morning","6-0","10:00-18:00","IN",1));
		EmployeeDetails.add(new EmployeeDetailsDto(1,"Gajam Nikhil","Nikhil","2001-05-24","2023-09-19","member technical","Morning","6-0","10:00-18:00","IN",1));
		when(emp_ser.getEmpsByManagerId(managerid)).thenReturn(EmployeeDetails);
		ResponseEntity<List<EmployeeDetailsDto>> res = controller.getEmpsWithManagerId(managerid);
		assertEquals(HttpStatus.OK, res.getStatusCode());
		
	}
	@Test
	public void testGetEmpsListWithManagerIdData() {
		int managerid = 1;
		EmployeeDetails = new ArrayList<>();
		EmployeeDetails.add(new EmployeeDetailsDto(1,"Patha Rahul","Rahul","2002-09-04","2023-09-19","member technical","Morning","6-0","10:00-18:00","IN",1));
		EmployeeDetails.add(new EmployeeDetailsDto(1,"Gajam Nikhil","Nikhil","2001-05-24","2023-09-19","member technical","Morning","6-0","10:00-18:00","IN",1));
		when(emp_ser.getEmpsByManagerId(managerid)).thenReturn(EmployeeDetails);
		ResponseEntity<List<EmployeeDetailsDto>> res = controller.getEmpsWithManagerId(managerid);
		assertEquals(2,res.getBody().size());
		
	}
	@Test
	public void testGetAllLeaves() {
		List<LeavesTable> leaves = new ArrayList<>();
		leaves.add(new LeavesTable(100001,511002,511001,"Sick Leave","2023-11-21","2023-11-22",2,"Medical Reasons",null,"Requested"));
		when(leave_ser.getAll()).thenReturn(leavestable);
		ResponseEntity<List<LeavesTableDto>> res = controller.getAllLeaves();
		assertEquals(HttpStatus.OK, res.getStatusCode());
	}
	public void testGetAllLeavesData() {
		List<LeavesTable> leaves = new ArrayList<>();
		leaves.add(new LeavesTable(100001,511002,511001,"Sick Leave","2023-11-21","2023-11-22",2,"Medical Reasons",null,"Requested"));
		when(leave_ser.getAll()).thenReturn(leavestable);
		ResponseEntity<List<LeavesTableDto>> res = controller.getAllLeaves();
		assertEquals(1,res.getBody().size());
	}
	@Test
	public void testGetLeavesByManId() {
		int managerid = 511001;
		List<LeavesTable> leaves = new ArrayList<>();
		leaves.add(new LeavesTable(100001,511002,511001,"Sick Leave","2023-11-21","2023-11-22",2,"Medical Reasons",null,"Requested"));
		when(leave_ser.getByManagerid(managerid)).thenReturn(leavestable);
		ResponseEntity<List<LeavesTableDto>> res = controller.getLeavesByManId(managerid);
		assertEquals(HttpStatus.OK, res.getStatusCode());
	}
	@Test
	public void testGetLeavesByManIdIncludingName() {
		int managerid = 511001;
		leaveswithname = new ArrayList<>();
		leaveswithname.add(new LeavesWithNameDto(100001,511002,"rahul",511001,"Sick Leave","2023-11-21","2023-11-22",2,"Medical Reasons",null,"Requested","10:00-18:00","6-0"));
		when(leave_ser.getByManidWithName(managerid)).thenReturn(leaveswithname);
		ResponseEntity<List<LeavesWithNameDto>> res = controller.getLeavesByManIdWithName(managerid);
		assertEquals(HttpStatus.OK,res.getStatusCode());		
	}
	@Test
	public void testGetLeavesByManIdIncludingNameData() {
		int managerid = 511001;
		leaveswithname = new ArrayList<>();
		leaveswithname.add(new LeavesWithNameDto(100001,511002,"rahul",511001,"Sick Leave","2023-11-21","2023-11-22",2,"Medical Reasons",null,"Requested","10:00-18:00","6-0"));
		when(leave_ser.getByManidWithName(managerid)).thenReturn(leaveswithname);
		ResponseEntity<List<LeavesWithNameDto>> res = controller.getLeavesByManIdWithName(managerid);
		assertEquals(1,res.getBody().size());		
	}
	@Test
	public void testGetLeavesListByEmpId() {
		int empid = 511002;
		List<LeavesTable> leaves = new ArrayList<>();
		leaves.add(new LeavesTable(100001,511002,511001,"Sick Leave","2023-11-21","2023-11-22",2,"Medical Reasons",null,"Requested"));
		when(leave_ser.getByEmpid(empid)).thenReturn(leavestable);
		ResponseEntity<List<LeavesTableDto>> res = controller.getLeavesByEmpId(empid);
		assertEquals(HttpStatus.OK, res.getStatusCode());		
	}

	@Test
	public void testGetLeavesWithByEmpIdIncludingName() {
		int empid = 511002;
		leaveswithname = new ArrayList<>();
		leaveswithname.add(new LeavesWithNameDto(100001,511002,"rahul",511001,"Sick Leave","2023-11-21","2023-11-22",2,"Medical Reasons",null,"Requested","10:00-18:00","6-0"));
		when(leave_ser.getByEmpidWithName(empid)).thenReturn(leaveswithname);
		ResponseEntity<List<LeavesWithNameDto>> res = controller.getLeavesWithByEmpIdWithName(empid);
		assertEquals(HttpStatus.OK, res.getStatusCode());
		
	}
	@Test
	public void testGetLeavesWithByEmpIdIncludingNameData() {
		int empid = 511002;
		leaveswithname = new ArrayList<>();
		leaveswithname.add(new LeavesWithNameDto(100001,511002,"rahul",511001,"Sick Leave","2023-11-21","2023-11-22",2,"Medical Reasons",null,"Requested","10:00-18:00","6-0"));
		when(leave_ser.getByEmpidWithName(empid)).thenReturn(leaveswithname);
		ResponseEntity<List<LeavesWithNameDto>> res = controller.getLeavesWithByEmpIdWithName(empid);
		assertEquals(1,res.getBody().size());
		
	}
	@Test
	public void testGetAllLoginDetails() {
		logindetails = new ArrayList<>();
		logindetails.add(new LoginDetailsDto(1,"example@adp.com","saturday"));
		when(login_ser.getAll()).thenReturn(logindetails);
		ResponseEntity<List<LoginDetailsDto>> res = controller.getAllLoginDetails();
		assertEquals(HttpStatus.OK, res.getStatusCode());
	}
	@Test
	public void testGetAllLoginDetailsData() {
		logindetails = new ArrayList<>();
		logindetails.add(new LoginDetailsDto(1,"example@adp.com","saturday"));
		when(login_ser.getAll()).thenReturn(logindetails);
		ResponseEntity<List<LoginDetailsDto>> res = controller.getAllLoginDetails();
		assertEquals(1,res.getBody().size());
	}

}
