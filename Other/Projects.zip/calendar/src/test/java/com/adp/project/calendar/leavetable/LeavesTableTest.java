package com.adp.project.calendar.leavetable;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.boot.test.context.SpringBootTest;

import com.adp.project.calendar.dao.EmployeeDetailsDao;
import com.adp.project.calendar.dao.LeavesTableDao;
import com.adp.project.calendar.model.EmployeeDetails;
import com.adp.project.calendar.model.LeavesTable;
import com.adp.project.calendar.service.LeavesTableServiceImpl;

@SpringBootTest
public class LeavesTableTest {
	@Mock
	LeavesTableDao leaves_dao;
	
	@Mock
	EmployeeDetailsDao emp_dao;
	
	@InjectMocks
	LeavesTableServiceImpl leaves_service;
	
	@Test
	public void getAll() {
		List<LeavesTable> leaves = new ArrayList<>();
		leaves.add(new LeavesTable(100001,511002,511001,"Sick Leave","2023-11-21","2023-11-22",2,"Medical Reasons",null,"Requested"));
		when(leaves_dao.findAll()).thenReturn(leaves);
		assertEquals(1,leaves_service.getAll().size());
	}
	@Test
	public void getByManagerid() {
		int managerid = 511001;
		List<LeavesTable> leaves = new ArrayList<>();
		leaves.add(new LeavesTable(100001,511002,511001,"Sick Leave","2023-11-21","2023-11-22",2,"Medical Reasons",null,"Requested"));
		when(leaves_dao.findByManagerid(managerid)).thenReturn(leaves);
		assertEquals(1,leaves_service.getByManagerid(managerid).size());
	}
	@Test
	public void getByEmpid() {
		int empid = 511002;
		List<LeavesTable> leaves = new ArrayList<>();
		leaves.add(new LeavesTable(100001,511002,511001,"Sick Leave","2023-11-21","2023-11-22",2,"Medical Reasons",null,"Requested"));
		when(leaves_dao.findByEmpid(empid)).thenReturn(leaves);
		assertEquals(1, leaves_service.getByEmpid(empid).size());
		
	}
	@Test
	public void getByEmpidWithName() {
		int empid = 511002;
		List<LeavesTable> leaves = new ArrayList<>();
		leaves.add(new LeavesTable(100001,511002,511001,"Sick Leave","2023-11-21","2023-11-22",2,"Medical Reasons",null,"Requested"));
		List<EmployeeDetails> Employee_list = new ArrayList<>();
		Employee_list.add(new EmployeeDetails(511002,"Patha Rahul","Rahul","2002-09-04","2023-09-19","member technical","Morning","6-0","10:00-18:00","IN",511001));
		when(leaves_dao.findByEmpid(empid)).thenReturn(leaves);
		when(emp_dao.findById(empid)).thenReturn(Optional.of(Employee_list.get(0)));
		System.out.println( leaves_service.getByManagerid(empid).size());
		assertEquals(1, leaves_service.getByEmpidWithName(empid).size());		

	}
	@Test
	public void getByManidWithName() {
		int managerid = 511002;
		List<LeavesTable> leaves = new ArrayList<>();
		leaves.add(new LeavesTable(100001,511002,511001,"Sick Leave","2023-11-21","2023-11-22",2,"Medical Reasons",null,"Requested"));
		List<EmployeeDetails> Employee_list = new ArrayList<>();
		Employee_list.add(new EmployeeDetails(511002,"Patha Rahul","Rahul","2002-09-04","2023-09-19","member technical","Morning","6-0","10:00-18:00","IN",511001));
		when(leaves_dao.findByManagerid(managerid)).thenReturn(leaves);
		when(emp_dao.findById(managerid)).thenReturn(Optional.of(Employee_list.get(0)));
		assertEquals(1,leaves_service.getByManidWithName(managerid).size());
		
	}
	

}
