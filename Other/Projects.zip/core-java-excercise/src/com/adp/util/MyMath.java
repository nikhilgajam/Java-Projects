package com.adp.util;

public class MyMath {
	public static boolean isPerfectNumber(int n) {
		int sum = 0;
		for(int i=1; i<n; i++) {
			if(n%i == 0) {
				sum += i;
			}
		}
		
		if(sum == n)
			return true;
		else
			return false;
	}
	
	public static long factorial(int n) {
		long fact = 1;
		for(int i=1; i<=n; i++) {
			fact *= i;
		}
		
		return fact;
	}
	
	public static boolean isPrime(int n) {
		if(n <= 1)
			return false;
		
		for(int i=2; i<=Math.sqrt(n); i++) {
			if(n%i == 0)
				return false;
		}
		
		return true;
	}
	
	public static long sumOfPrimes(int n) {
		long sum = 0;
		for(int i=1; i<n; i++) {
			if(isPrime(i))
				sum += i;
		}
		
		return sum;
	}
	
	public static boolean isArmstrongNumber(int n) {
		String s = n + "";
		int len = s.length();
		
		int temp = n;
		
		int num, r=0;
		while(n > 0) {
			num = n%10;
			r += Math.pow(num, len);
			n /= 10;
		}
		
		if(temp == r)
			return true;
		else
			return false;
	}
	
	public static int reverseNumber(int n) {
		int num, r=0;
		while(n > 0) {
			num = n%10;
			r = r*10+num;
			n /= 10;
		}
		
		return r;
	}
	
	public static int decimalToBinary(int n) {
		String bin = Integer.toBinaryString(n);
		int bin_n = Integer.parseInt(bin);
		return bin_n;
	}
	
	public static int binaryToDecimal(int n) {
		return Integer.parseInt(n+"", 2);
	}
	
	public static int getSumOfNfibos(int n) {
		int sum = 0;
		int a=0, b=1, c=0;
		for(int i=0; i<n; i++) {
			sum += a;
			a = a+b;
			b = c;
			c = a;
		}
		
		return sum;
	}
	
	public static boolean isPalindromeNumber(int n) {
		int rev = reverseNumber(n);
		if(n == rev) {
			return true;
		}else {
			return false;
		}
	}
}
