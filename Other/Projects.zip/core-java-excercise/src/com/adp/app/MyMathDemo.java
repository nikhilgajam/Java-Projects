package com.adp.app;

import com.adp.util.MyMath;

public class MyMathDemo {

	public static void main(String[] args) {
		
		System.out.println(MyMath.isPerfectNumber(6));
		System.out.println(MyMath.factorial(3));
		System.out.println(MyMath.isPrime(11));
		System.out.println(MyMath.sumOfPrimes(10));
		System.out.println(MyMath.isArmstrongNumber(153));
		System.out.println(MyMath.reverseNumber(12345));
		System.out.println(MyMath.decimalToBinary(10));
		System.out.println(MyMath.binaryToDecimal(1010));
		System.out.println(MyMath.getSumOfNfibos(10));
		System.out.println(MyMath.isPalindromeNumber(121));
		
	}

}
