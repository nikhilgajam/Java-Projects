package com.adp.project.post.dao;

import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.adp.project.post.model.Comments;

@Repository
public interface CommentsDao extends JpaRepository<Comments, Integer>{
	public List<Comments> findByPid(int pid);
}
