package com.adp.project.post.service;

import java.util.List;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import com.adp.project.dto.CommentsDto;

@FeignClient(name="comment-service")
public interface FeignProxy {
	
	@GetMapping("/comments/{pid}")
	public List<CommentsDto> getComments(@PathVariable int pid);
	
}
