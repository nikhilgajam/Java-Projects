package com.adp.project.post;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.adp.project.dto.CommentsDto;
import com.adp.project.dto.PostsDto;
import com.adp.project.post.service.PostsService;

@RestController
@RequestMapping("/posts")
public class PostController {
	
	@Autowired
	PostsService post_ser;
	
	@GetMapping("/getAll")
	@CrossOrigin("*")
	public ResponseEntity<List<PostsDto>> getAllPosts() {
		List<PostsDto> list = post_ser.getAllPosts();
		return new ResponseEntity<>(list, HttpStatus.OK);
	}
	
	@GetMapping("/search/{title}")
	@CrossOrigin("*")
	public ResponseEntity<List<PostsDto>> getPostsByTitle(@PathVariable String title) {
		List<PostsDto> list = post_ser.searchByTitle(title);
		return new ResponseEntity<>(list, HttpStatus.OK);
	}
	
	@GetMapping("/{pid}")
	@CrossOrigin("*")
	public ResponseEntity<PostsDto> getPostById(@PathVariable int pid) {
		return new ResponseEntity<>(post_ser.searchById(pid), HttpStatus.OK);
	}
	
	@PostMapping("/add")
	@CrossOrigin("*")
	public ResponseEntity<PostsDto> addPost(@RequestBody PostsDto dto) {
		/*
		 * {
		    "author": "Nikhil",
		    "title": "How's The Universe",
		    "description": "Hi To Universe And Its Habitants"
		   }
		 */
		return new ResponseEntity<>(post_ser.addPost(dto), HttpStatus.CREATED);
	}
	
	@DeleteMapping("/delete/{pid}")
	@CrossOrigin("*")
	public ResponseEntity<String> deletePost(@PathVariable("pid") int pid) {	
		post_ser.deletePost(pid);
		return new ResponseEntity<>("Successfully Deleted", HttpStatus.OK);
	}
	
	@PutMapping("/update")
	@CrossOrigin("*")
	public ResponseEntity<PostsDto> updatePost(@RequestBody PostsDto dto) {
		return new ResponseEntity<>(post_ser.updatePost(dto), HttpStatus.OK);
	}
	
	@GetMapping("/comments/{pid}")
	@CrossOrigin("*")
	public ResponseEntity<List<CommentsDto>> getComments(@PathVariable int pid) {
		return new ResponseEntity<>(post_ser.getComments(pid), HttpStatus.OK);
	}

}
