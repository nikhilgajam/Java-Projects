package com.adp.project.dto;

import java.util.List;
import com.adp.project.post.model.Comments;
import lombok.Data;

@Data
public class PostsDto {
	private int pid;
	private String author;
	private String title;
	private String description;
//	List<Comments> comments;
}
