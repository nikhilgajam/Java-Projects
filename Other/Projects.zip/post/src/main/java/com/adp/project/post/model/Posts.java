package com.adp.project.post.model;

import java.util.List;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Table(name="season2_nikhil_post")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class Posts {
	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE)
	private int pid;
	private String author;
	private String title;
	private String description;
	
//	@OneToMany
//	@JoinColumn(name="pid")
//	List<Comments> comments;
}
