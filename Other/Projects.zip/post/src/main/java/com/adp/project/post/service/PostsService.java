package com.adp.project.post.service;

import java.util.List;

import com.adp.project.dto.CommentsDto;
import com.adp.project.dto.PostsDto;

public interface PostsService {
	public PostsDto addPost(PostsDto dto);
	public void deletePost(int pid);
	public PostsDto updatePost(PostsDto dto);
	public List<PostsDto> searchByTitle(String title);
	public List<PostsDto> getAllPosts();
	public List<CommentsDto> getComments(int pid);
	public PostsDto searchById(int pid);
}
