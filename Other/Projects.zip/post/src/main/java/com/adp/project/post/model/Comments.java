package com.adp.project.post.model;

import com.fasterxml.jackson.annotation.JsonIgnore;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Table(name="season2_nikhil_comment")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class Comments {
	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE)
	private int cid;
	private int pid;
	private String comments;
	private String commenter;
	
//	@JsonIgnore
//	@ManyToOne
//	private Posts post;
	
}
