package com.adp.project.post.service;

import java.util.List;
import com.adp.project.dto.CommentsDto;

public interface CommentsService {
	public CommentsDto addComment(CommentsDto dto);
	public void deleteComment(CommentsDto dto);
	public CommentsDto updateComment(CommentsDto dto);
	public List<CommentsDto> commentsOfPostById(int id);
}
