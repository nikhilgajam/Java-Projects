package com.adp.project.dto;

import com.adp.project.post.model.Posts;
import lombok.Data;

@Data
public class CommentsDto {
	private int pid;
	private int cid;
	private String comments;
	private String commenter;
//	private Posts post;
}
