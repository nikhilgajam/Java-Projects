package com.adp.project.post.service;

import java.util.List;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.adp.project.dto.CommentsDto;
import com.adp.project.dto.PostsDto;
import com.adp.project.post.dao.PostsDao;
import com.adp.project.post.model.Posts;

@Service
public class PostsServiceImpl implements PostsService {
	
	@Autowired
	PostsDao post_dao;
	
	@Autowired
	FeignProxy proxy;
	
	ModelMapper modelmap;
	
	public PostsServiceImpl() {
		modelmap = new ModelMapper();
	}

	@Override
	public PostsDto addPost(PostsDto dto) {
		int id = post_dao.save(modelmap.map(dto, Posts.class)).getPid();
		dto.setPid(id);
		return dto;
	}

	@Override
	public void deletePost(int pid) {
		post_dao.deleteById(pid);
	}

	@Override
	public PostsDto updatePost(PostsDto dto) {
		post_dao.save(modelmap.map(dto, Posts.class));
		return dto;
	}

	@Override
	public List<PostsDto> searchByTitle(String title) {
		return post_dao.findByTitle(title).stream().map(posts -> modelmap.map(posts, PostsDto.class)).collect(Collectors.toList());
		
	}
	
	@Override
	public PostsDto searchById(int pid) {
		return modelmap.map(post_dao.findById(pid).get(), PostsDto.class);
		
	}
	
	@Override
	public List<PostsDto> getAllPosts(){
		return post_dao.findAll().stream().map(posts -> modelmap.map(posts, PostsDto.class)).collect(Collectors.toList());
	}
	
	@Override
	public List<CommentsDto> getComments(int pid) {
		return proxy.getComments(pid);
	}

}
