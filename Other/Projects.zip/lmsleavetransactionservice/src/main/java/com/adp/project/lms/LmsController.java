package com.adp.project.lms;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.adp.project.lms.model.Employee;
import com.adp.project.lms.model.LeaveBalancesTable;
import com.adp.project.lms.model.LeaveTransaction;
import com.adp.project.lms.model.SubLeaveTransaction;
import com.adp.project.lms.model.SubLeaveUpdate;
import com.adp.project.lms.service.EmployeeService;
import com.adp.project.lms.service.LeaveBalancesTableService;
import com.adp.project.lms.service.LeaveTransactionService;
import jakarta.servlet.http.HttpServletRequest;

@RestController
@RequestMapping("/leavetransaction")
public class LmsController {
	
	@Autowired
	EmployeeService emp_ser;
	
	@Autowired
	LeaveTransactionService lt_ser;
	
	@Autowired
	LeaveBalancesTableService lb_ser;
	
	@GetMapping("/")
	public String home() {
		System.out.println(emp_ser.getAllEmployees());
		return "Leave Transaction Home";
	}
	
	@PostMapping("/getDetails/{empid}")
	@CrossOrigin("*")
	public Employee getDetails(@PathVariable Integer empid) {
		return emp_ser.getDetails(empid);
	}
	
	@PostMapping("/empApplyLeave")
	@CrossOrigin("*")
	public ResponseEntity<SubLeaveTransaction> empapp(@RequestBody SubLeaveTransaction transaction) {
		/*
		 * {
		 * 	empid: 1,
		 * 	startdate: "28-10-2023",
		 * 	enddate: "28-10-2023",
		 * 	leavecount: 1,
		 * 	leavetype: "PrivilegedLeave",
		 *  reason: "Trip"
		 * }
		 */
		int empid = transaction.getEmpid();
		String startdate = transaction.getStartdate();
		String enddate = transaction.getEnddate();
		int leavecount = transaction.getLeavecount();
		String leavetype = transaction.getLeavetype();
		String reason = transaction.getReason();
		
		lt_ser.applyLeave(empid, startdate, enddate, leavecount, leavetype, reason);
		
		return new ResponseEntity<>(transaction, HttpStatus.CREATED);
	}
	
	@PostMapping("/empCheckLeaveStatus/{empid}")
	@CrossOrigin("*")
	public ResponseEntity<List<LeaveTransaction>> empLeaveStatus(@PathVariable Integer empid){
		return new ResponseEntity<>(lt_ser.empLeaveHistory(empid), HttpStatus.OK);
	}
	
	@PostMapping("/empCheckLeaveBalances/{empid}")
	@CrossOrigin("*")
	public ResponseEntity<List<LeaveBalancesTable>> empLeaveBalances(@PathVariable Integer empid) {
		return new ResponseEntity<>(lb_ser.showLeaveBalances(empid), HttpStatus.OK);
	}
	
	@PostMapping("/managerPendingRequests/{manid}")
	@CrossOrigin("*")
	public ResponseEntity<List<LeaveTransaction>> managerPending(@PathVariable Integer manid) {
		return new ResponseEntity<>(lt_ser.showPendingLeaves(manid), HttpStatus.OK);
	}
	
	@PostMapping("/managerAcceptOrReject")
	@CrossOrigin("*")
	public ResponseEntity<SubLeaveUpdate> managerCommentsUpdate(@RequestBody SubLeaveUpdate leave) {
		/*
		 * {
		 *	leaveid: 1011,
		 *	status: "Accepted",
		 *	comments: "You may proceed"
		 * }
		 */
		int leaveid = leave.getLeaveid();
		String status = leave.getStatus();
		String comments = leave.getComments();
		
		lt_ser.acceptOrReject(leaveid, status, comments);
		
		return new ResponseEntity<>(leave, HttpStatus.CREATED);
	}
	
}
