package com.adp.project.lms.service;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Optional;
import java.util.Random;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.adp.project.lms.dao.EmployeeDao;
import com.adp.project.lms.dao.LeaveBalancesTableDao;
import com.adp.project.lms.dao.LeaveTransactionDao;
import com.adp.project.lms.model.Employee;
import com.adp.project.lms.model.LeaveBalancesTable;
import com.adp.project.lms.model.LeaveTransaction;

@Service
public class LeaveTransactionServiceImpl implements LeaveTransactionService {
	
	@Autowired
	EmployeeDao emp_dao;
	
	@Autowired
	LeaveTransactionDao lt_dao;
	
	@Autowired
	LeaveBalancesTableDao lb_dao;

	@Override
	public void applyLeave(int emp_id, String startdate, String enddate, int leavecount, String leavetype, String reason) {
		Optional<Employee> emp = emp_dao.findById(emp_id);
		
		System.out.println(emp.get());
		
		LeaveTransaction lt = new LeaveTransaction();
		lt.setLeaveid(Math.abs(new Random().nextInt()));
		lt.setEmployeeid(emp_id);
		lt.setStartdate(startdate);
		lt.setEnddate(enddate);
		lt.setLeavecount(leavecount);
		lt.setLeavetype(leavetype);
		lt.setReason(reason);
		lt.setStatus("Pending");
		lt.setComments("");
		lt.setManagerid(emp.get().getManagerid());
		
		lt_dao.save(lt);
	}
	
	public List<LeaveTransaction> showPendingLeaves(int manager_id) {
		List<LeaveTransaction> list = lt_dao.findByManagerid(manager_id);
		List<LeaveTransaction> pending_list = new ArrayList<>();
		for(LeaveTransaction lt : list) {
			if(lt.getStatus().toLowerCase().equals("pending")) {
				pending_list.add(lt);
			}
		}
		
		return pending_list;
	}

	@Override
	public void acceptOrReject(int leaveid, String status, String comments) {
		LeaveTransaction lt = lt_dao.findById(leaveid).get();
		lt.setStatus(status);
		lt.setComments(comments);
		
		if(status.equals("Rejected")) {
			lt_dao.save(lt);
			return;
		}
		
		List<LeaveBalancesTable> lb_list = lb_dao.findByEmployeeid(lt.getEmployeeid());
		LeaveBalancesTable lb = lb_list.get(0);
		
		System.out.println(lb);
		
		String leavetype = lt.getLeavetype().toLowerCase();
		
		int count = lt.getLeavecount();
		int remaining_leaves = 0;
				
		if(leavetype.equals("sickleaves")) {
			remaining_leaves = lb.getSickleaves();
		}else if(leavetype.equals("maternityleaves")) {
			remaining_leaves = lb.getMaternityleaves();
		}else if(leavetype.equals("paternityleaves")) {
			remaining_leaves = lb.getPaternityleaves();
		}else if(leavetype.equals("privilegedleaves")) {
			remaining_leaves = lb.getPrivilegedleaves();
		}
		
		int new_remaining_leaves = remaining_leaves - count;
		
		System.out.println(new_remaining_leaves);
		
		if(new_remaining_leaves >= 0) {
			if(leavetype.equals("sickleaves")) {
				lb.setSickleaves(new_remaining_leaves);
			}else if(leavetype.equals("maternityleaves")) {
				lb.setMaternityleaves(new_remaining_leaves);
			}else if(leavetype.equals("paternityleaves")) {
				lb.setPaternityleaves(new_remaining_leaves);
			}else if(leavetype.equals("privilegedleaves")) {
				lb.setPrivilegedleaves(new_remaining_leaves);
			}
			
			
			lt_dao.save(lt);
			lb_dao.save(lb);
			System.out.println("Ok");
		}else {
			return;
		}
	}

	@Override
	public List<LeaveTransaction> empLeaveHistory(int emp_id) {
		List<LeaveTransaction> list = lt_dao.findByEmployeeid(emp_id);
		return list;
	}

}
