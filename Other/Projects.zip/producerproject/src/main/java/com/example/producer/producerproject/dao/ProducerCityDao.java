package com.example.producer.producerproject.dao;

import java.util.List;

import com.example.producer.producerproject.Citydata;

public interface ProducerCityDao {
	
	public List<Citydata> getAllCitiesData();
	public Citydata getCityData(String cname);

}
