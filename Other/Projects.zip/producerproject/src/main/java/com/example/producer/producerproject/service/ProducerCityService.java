package com.example.producer.producerproject.service;

import java.util.List;

import com.example.producer.producerproject.Citydata;

public interface ProducerCityService {
	
	public List<Citydata> getAllCitiesData();
	public Citydata getCityData(String cname);

}
