package com.example.producer.producerproject;



public class Citydata {
	
	int cid;
	
	String cname;
	
	int max;
	
	int min;
	
	String airquality;
	
	public Citydata() {
		
	}

	public Citydata(int cid, String cname, int max, int min, String airquality) {
		super();
		this.cid = cid;
		this.cname = cname;
		this.max = max;
		this.min = min;
		this.airquality = airquality;
	}

	public int getCid() {
		return cid;
	}

	public void setCid(int cid) {
		this.cid = cid;
	}

	public String getCname() {
		return cname;
	}

	public void setCname(String cname) {
		this.cname = cname;
	}

	public int getMax() {
		return max;
	}

	public void setMax(int max) {
		this.max = max;
	}

	public int getMin() {
		return min;
	}

	public void setMin(int min) {
		this.min = min;
	}

	public String getAirquality() {
		return airquality;
	}

	public void setAirquality(String airquality) {
		this.airquality = airquality;
	}
	

}
