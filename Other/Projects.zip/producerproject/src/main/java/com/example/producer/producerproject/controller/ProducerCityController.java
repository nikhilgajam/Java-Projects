package com.example.producer.producerproject.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.producer.producerproject.Citydata;
import com.example.producer.producerproject.service.ProducerCityService;

@RestController
@RequestMapping("/producer")
public class ProducerCityController {
	
	@Autowired
	ProducerCityService service;
	
	@Value("${server.port}")
	String port;
	
	
	@GetMapping("/port")
	public String getPort() {
		return "Port---> "+port;
	}
	
	@GetMapping("/cities/{cname}")
	public Citydata getCityData(@PathVariable String cname) {
		return service.getCityData(cname);
	}
	
	
	@GetMapping("/cities")
	public List<Citydata> getData(){
		return service.getAllCitiesData();
	}

}
