package com.example.producer.producerproject.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.producer.producerproject.Citydata;
import com.example.producer.producerproject.dao.CityDao;

@Service
public class CityServiceImpl implements CityService{
	
	@Autowired
	CityDao dao;

	@Override
	public List<Citydata> getAllCitiesData() {
		// TODO Auto-generated method stub
		return dao.getAllCitiesData();
	}

	@Override
	public Citydata getCityData(String cname) {
		// TODO Auto-generated method stub
		return dao.getCityData(cname);
	}

}
