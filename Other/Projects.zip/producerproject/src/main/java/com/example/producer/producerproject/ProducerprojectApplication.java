package com.example.producer.producerproject;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;

@SpringBootApplication
@EnableDiscoveryClient
public class ProducerprojectApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProducerprojectApplication.class, args);
	}

}
