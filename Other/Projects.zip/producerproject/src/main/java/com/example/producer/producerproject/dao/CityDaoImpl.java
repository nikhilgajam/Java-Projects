package com.example.producer.producerproject.dao;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Repository;

import com.example.producer.producerproject.Citydata;


@Repository
public class CityDaoImpl implements CityDao{
	
	static List<Citydata> cities;
	static {
		cities = new ArrayList<>();
		cities.add(new Citydata(1001,"Hyderabad",40,30,"good"));
		cities.add(new Citydata(1002,"Chennai",45,35,"average"));
		cities.add(new Citydata(1003,"Delhi",30,20,"poor"));
	}

	@Override
	public List<Citydata> getAllCitiesData() {
		// TODO Auto-generated method stub
		return cities;
	}

	@Override
	public Citydata getCityData(String cname) {
		// TODO Auto-generated method stub
		Citydata data = null;
		boolean isfound =false;
		for(Citydata d: cities) {
			if(d.getCname().equals(cname)) {
				isfound=true;
				data = d;
				break;
			}
		}
		return data;
	}

}
