package com.example.producer.producerproject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProducerprojectApplicationTests {

	@Test
	void contextLoads() {
	}

}
