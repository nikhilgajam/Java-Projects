package com.adp.bookproject.service;

import java.util.List;

import com.adp.bookproject.dao.*;
import com.adp.bookproject.model.Book;
import com.adp.bookproject.model.Book.Category;

public class BookServiceImpl implements IBookService {
	
	IBookDao book_dao = new BookDaoImpl();

	@Override
	public List<Book> getAllBooks() {
		return book_dao.getAllBooks();
	}

	@Override
	public List<Book> addBookToList(Book book) {
		return book_dao.addBookToList(book);
	}

	@Override
	public List<Book> updateBook(Book book) {
		return book_dao.updateBook(book);
	}

	@Override
	public List<Book> getBooksByCategory(Category category) {
		return book_dao.getBooksByCategory(category);
	}

	@Override
	public List<Book> getLegacyBooks() {
		return book_dao.getLegacyBooks();
	}

	@Override
	public boolean removeBookFromList(String isbn) {
		return book_dao.removeBookFromList(isbn);
	}

}
