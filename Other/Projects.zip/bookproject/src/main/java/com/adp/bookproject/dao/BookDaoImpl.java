package com.adp.bookproject.dao;

import java.util.List;
import java.util.stream.Collectors;
import java.time.LocalDate;
import java.time.Period;
import java.util.ArrayList;

import com.adp.bookproject.model.Book;
import com.adp.bookproject.model.Book.Category;

public class BookDaoImpl implements IBookDao {
	
	private List<Book> books;
	
	public BookDaoImpl() {
		books = new ArrayList<>();
	}

	@Override
	public List<Book> getAllBooks() {
		return books;
	}

	@Override
	public List<Book> addBookToList(Book book) {
		books.add(book);
		return books;
	}

	@Override
	public List<Book> updateBook(Book book) {
		try {
			Book temp = books.stream().filter(b -> b.getIsbn().equals(book.getIsbn())).findAny().get();
			books.remove(temp);
			addBookToList(book);
			return books;
		}catch(Exception e) {
			return null;
		}
	}

	@Override
	public List<Book> getBooksByCategory(Category category) {
		List<Book> list = books.stream().filter(book -> book.getCategory().equals(category)).collect(Collectors.toList());
		return list;
	}

	@Override
	public List<Book> getLegacyBooks() {
		LocalDate current = LocalDate.now();
		List<Book> list = books.stream().filter(book -> Period.between(book.getDateOfPublish(), current).getYears() >= 15).collect(Collectors.toList());
		return list;
	}

	@Override
	public boolean removeBookFromList(String isbn) {
		try {
			Book temp = books.stream().filter(book -> book.getIsbn() == isbn).findAny().get();
			return books.remove(temp);
		}catch(Exception e) {
			return false;
		}
	}

}
