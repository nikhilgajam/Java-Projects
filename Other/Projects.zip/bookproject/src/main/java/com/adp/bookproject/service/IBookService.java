package com.adp.bookproject.service;

import com.adp.bookproject.model.Book;
import com.adp.bookproject.model.Book.Category;

import java.util.List;

public interface IBookService {
	public List<Book> getAllBooks();
    public List<Book> addBookToList(Book book);
    public List<Book> updateBook(Book book);
    public List<Book> getBooksByCategory(Category category);
    public List<Book> getLegacyBooks(); 
    public boolean removeBookFromList(String isbn);
}