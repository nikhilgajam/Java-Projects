package com.adp.bookproject.controller;

import java.time.LocalDate;
import java.util.Scanner;
import com.adp.bookproject.model.Book;
import com.adp.bookproject.model.Book.Category;
import com.adp.bookproject.service.BookServiceImpl;

public class BookMain {

	public static void main(String[] args) {
		BookServiceImpl book_service = new BookServiceImpl();
		
		book_service.addBookToList(new Book("1001", "Abdul Kalam", "Ignited Minds", 100.15, LocalDate.parse("1991-01-01"), Category.SCIENCE));
		book_service.addBookToList(new Book("1002", "Abdul Kalam", "Wings", 100.15, LocalDate.parse("1990-01-01"), Category.SCIENCE));
//		book_service.updateBook(new Book("1001", "Abdul Kalam", "Wings", 100.15, LocalDate.parse("1990-01-01"), Category.SCIENCE));
		
		Scanner scan = new Scanner(System.in);
		String display_text = "\nEnter 1 to getAllBooks\n"
				+ "Enter 2 to addBookToList\n"
				+ "Enter 3 to updateBook\n"
				+ "Enter 4 to getBooksByCategory\n"
				+ "Enter 5 to getLegacyBooks\n"
				+ "Enter 6 to removeBookFromList\n"
				+ "Enter 0 to exit program\n";
		System.out.println(display_text);
		
		try {
			while(true) {
				System.out.print("\n: ");
				int choice = scan.nextInt();
				
				if(choice == 0) {
					System.out.println("\nExiting While Loop Execution\n");
					break;
				}else if(choice == 1) {
					System.out.println("\ngetAllBooks\n");
					System.out.println(book_service.getAllBooks());
				}else if(choice == 2) {
					System.out.println("\naddBookToList\n");
					System.out.println(book_service.addBookToList(createBook()));
				}else if(choice == 3) {
					System.out.println("\nupdateBook\n");
					System.out.println(book_service.updateBook(createBook()));
				}else if(choice == 4) {
					System.out.println("\ngetBooksByCategory\n");
					System.out.print("Enter Category No 1=SCIENCE, 2=COMICS, 3=DEVOTIONAL, 4=FICTION: ");
					int category_int = Integer.parseInt(scan.next());
					
					Category category;
					switch(category_int) {
						case 1: category = Category.SCIENCE; break;
						case 2: category = Category.COMICS; break;
						case 3: category = Category.DEVOTIONAL; break;
						case 4: category = Category.FICTION; break;
						default: category = Category.SCIENCE;
					}
					
					System.out.println(book_service.getBooksByCategory(category));
				}else if(choice == 5) {
					System.out.println("\ngetLegacyBooks\n");
					System.out.println(book_service.getLegacyBooks());
				}else if(choice == 6){
					System.out.println("\nremoveBookFromList\n");
					System.out.println("Enter isbn no: ");
					String isbn = scan.next();
					System.out.println(book_service.removeBookFromList(isbn));
				}else {
					System.out.println("\nEnter a valid choice number\n");
				}
			}
		}catch(Exception e) {
			System.out.println(e);
		}
		
	}
	
	public static Book createBook() {
		Scanner scan = new Scanner(System.in);
		System.out.println("Enter Book Details");
		
		System.out.print("Enter isbn no: ");
		String isbn = scan.nextLine();
		
		System.out.print("Enter author name: ");
		String author = scan.nextLine();
		
		System.out.print("Enter book title: ");
		String title = scan.nextLine();
		
		System.out.print("Enter book cost: ");
		double cost = scan.nextDouble();
		
		System.out.print("Enter date of publish(YYYY-MM-DD): ");
		LocalDate date = LocalDate.parse(scan.next());
		
		System.out.print("Enter Category No 1=SCIENCE, 2=COMICS, 3=DEVOTIONAL, 4=FICTION: ");
		int category_int = Integer.parseInt(scan.next());
		
		Category category;
		switch(category_int) {
			case 1: category = Category.SCIENCE; break;
			case 2: category = Category.COMICS; break;
			case 3: category = Category.DEVOTIONAL; break;
			case 4: category = Category.FICTION; break;
			default: category = Category.SCIENCE;
		}
		Book book = new Book(isbn, author, title, cost, date, category);
		return book;
	}

}
