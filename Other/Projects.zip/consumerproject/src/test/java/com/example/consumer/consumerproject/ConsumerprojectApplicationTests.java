package com.example.consumer.consumerproject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ConsumerprojectApplicationTests {

	@Test
	void contextLoads() {
	}

}
