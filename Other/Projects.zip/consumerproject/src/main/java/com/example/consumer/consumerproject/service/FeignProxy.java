package com.example.consumer.consumerproject.service;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.example.consumer.consumerproject.model.CitydataDto;

@FeignClient(name="producer-service")
public interface FeignProxy {
	
	@GetMapping("/producer/cities/{cname}")
	public CitydataDto getCityData(@PathVariable String cname);
	
	@GetMapping("/producer/port")
	public String getPort();

}
