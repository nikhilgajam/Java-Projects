package com.example.consumer.consumerproject.service;

import com.example.consumer.consumerproject.model.CitydataDto;

public interface ConsumerCityService {
	public CitydataDto getCityWheather(String cname);
	public String getPort();
}
