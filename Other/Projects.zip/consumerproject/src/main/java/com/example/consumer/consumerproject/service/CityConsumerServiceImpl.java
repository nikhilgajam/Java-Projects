package com.example.consumer.consumerproject.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.example.consumer.consumerproject.model.CitydataDto;


@Service
public class CityConsumerServiceImpl implements CityConsumerService{
	
	@Autowired
	RestTemplate template;

	@Override
	public CitydataDto getCityWheather(String cname) {
		// TODO Auto-generated method stub
		return template.getForObject("http://localhost:9090/producer/cities/"+cname, CitydataDto.class);

	}

}
