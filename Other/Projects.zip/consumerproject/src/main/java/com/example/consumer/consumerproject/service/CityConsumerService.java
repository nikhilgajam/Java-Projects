package com.example.consumer.consumerproject.service;

import com.example.consumer.consumerproject.model.CitydataDto;

public interface CityConsumerService {
	public CitydataDto getCityWheather(String cname);
}
