package com.example.consumer.consumerproject.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.consumer.consumerproject.model.CitydataDto;
import com.example.consumer.consumerproject.service.ConsumerCityService;

@RestController
@RequestMapping("/consumer")
public class ConsumerCityController {
	
	ConsumerCityService service;
	
	@GetMapping("/getProducerPort")
	public String getPorts() {
		return service.getPort();
	}
	
	@GetMapping("/test")
	public String test() {
		return "consumer is tested";
	}
	
	@GetMapping("/city/{cname}")
	public CitydataDto getCityDataFromProducer(@PathVariable String cname) {
		return service.getCityWheather(cname);
	}

}
