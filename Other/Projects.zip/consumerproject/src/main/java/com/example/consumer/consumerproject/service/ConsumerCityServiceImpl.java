package com.example.consumer.consumerproject.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.example.consumer.consumerproject.model.CitydataDto;


@Service
public class ConsumerCityServiceImpl implements ConsumerCityService{
	
	@Autowired
	RestTemplate template;
	
	@Autowired
	FeignProxy proxy;
	

	@Override
	public CitydataDto getCityWheather(String cname) {
		// TODO Auto-generated method stub
		
		
		
	//return template.getForObject("http://PRODUCER-SERVICE/producer/cities/"+cname, CitydataDto.class);
		return proxy.getCityData(cname);
	}


	@Override
	public String getPort() {
		// TODO Auto-generated method stub
		//return template.getForObject("http://PRODUCER-SERVICE/producer/port", String.class);
		return proxy.getPort();
	}

}
