package com.adp.project.model;

public class Student {
	
	int htno;
	String name;
	String branch;
	int m1,m2,m3;
	int total;
	public Student() {
		
	}
	
	public Student(int htno, String name, String branch, int m1, int m2, int m3) {
		super();
		this.htno = htno;
		this.name = name;
		this.branch = branch;
		this.m1=m1;
		this.m2=m2;
		this.m3=m3;
	}

	public int getM1() {
		return m1;
	}

	public void setM1(int m1) {
		this.m1 = m1;
	}

	public int getM2() {
		return m2;
	}

	public void setM2(int m2) {
		this.m2 = m2;
	}

	public int getM3() {
		return m3;
	}

	public void setM3(int m3) {
		this.m3 = m3;
	}

	public int getTotal() {
		return total;
	}

	public void setTotal(int total) {
		this.total = total;
	}

	public int getHtno() {
		return htno;
	}
	public void setHtno(int htno) {
		this.htno = htno;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getBranch() {
		return branch;
	}
	public void setBranch(String branch) {
		this.branch = branch;
	}

	@Override
	public String toString() {
		return "Student [htno=" + htno + ", name=" + name + ", branch=" + branch + "]";
	}

	/*
	@Override
	public int compareTo(Student o) {
		// TODO Auto-generated method stub
		return  this.name.compareTo(o.getName());
	}

	*/

}
