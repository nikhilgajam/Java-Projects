package com.adp.project.controller;

import java.util.Optional;
import java.util.Scanner;
import java.util.function.Consumer;

import com.adp.project.model.Student;
import com.adp.project.service.StudentServiceImpl;

public class StudentMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		
		
		Consumer<Student> c = stu ->{
			System.out.println("Student Details ");
			System.out.println("-----------------");
			System.out.println("HtNo: "+stu.getHtno());
			System.out.println("Name: "+stu.getName());
			System.out.println("Branch: "+stu.getBranch());
			System.out.println("M1 : "+stu.getM1());
			System.out.println("M2 : "+stu.getM2());
			System.out.println("M3 : "+stu.getM3());
			System.out.println("Total : "+stu.getTotal());
			
		};
		
		StudentServiceImpl service = new StudentServiceImpl();
		//List<Student> students = service.getAllStudents();
		
		//students.forEach(c);
	
//		System.out.println("Enter student htno to delete: ");
//		int htno = sc.nextInt();
//		boolean check = service.deleteStudent(htno);
//		System.out.println(check);
		
//		boolean check = service.updateStudent(getStudentData());
//		System.out.println(check);
		
		service.calculateTotal();
		
	//	Student s = service.addStudent(getStudentData());
	//	if(s!=null)
	//		System.out.println("Student added to list");
	//	else
	//		System.out.println("not added to list");
		
	}
		
		public static Student getStudentData() {
			
			Scanner sc = new Scanner(System.in);
			System.out.println("Enter student htno");
			int htno = sc.nextInt();
			System.out.println("Enter student name");
			String name = sc.next();
			System.out.println("Enter student branch");
			String branch = sc.next();
			System.out.println("Enter m1 marks");
			int m1 = sc.nextInt();
			System.out.println("Enter m2 marks");
			int m2 = sc.nextInt();
			System.out.println("Enter m3 marks");
			int m3 = sc.nextInt();
			
			return new Student(htno,name,branch,m1,m2,m3);
		}
		/*
	//	List<Student> students = service.calculateTotal();
	//	List<Student> students = service.getAllStudents();
		//System.out.println(students);
	//	students.forEach(c);
	/*	
		
		
		System.out.println("Enter student htno to delete");
		int htno = sc.nextInt();
		boolean isDeleted = service.deleteStudent(htno);
		if(isDeleted)
		{
			System.out.println("Student data delete...");
			service.getAllStudents().forEach(System.out::println);
		}
		else
			System.out.println("Htno is invalid / not found");

	}
	
	
	*/
}
