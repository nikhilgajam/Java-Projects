package com.adp.project.dao;

import java.util.List;
import java.util.Optional;

import com.adp.project.model.Student;

public interface IStudentDao {

	public List<Student> getAllStudents();
	public Student addStudent(Student student);
	public boolean deleteStudent(int htno);
	public Optional<Student> searchStudent(int htno);
	public void calculateTotal();
	public boolean updateStudent(Student student);
}
