package com.adp.project.dao;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import com.adp.project.model.Student;

public class StudentDaoImpl implements IStudentDao {
	public List<Student> students;

	public StudentDaoImpl() {
		// students = new ArrayList<>();
		students = new ArrayList<>();
		students.add(new Student(1001, "anil", "cse", 50, 40, 70));
		students.add(new Student(1032, "kishore", "eee", 80, 83, 89));
		students.add(new Student(1027, "mahesh", "mech", 50, 49, 48));
		students.add(new Student(1008, "sureh", "cse", 35, 36, 39));
	}

	public List<Student> getAllStudents() {
		// TODO Auto-generated method stub
		return students;
	}

	public Student addStudent(Student student) {
		// TODO Auto-generated method stub
		if (students.add(student))
			return student;
		else
			return null;
	}

	public boolean deleteStudent(int htno) {
		// TODO Auto-generated method stub
		Optional<Student> student = students.stream()
				.filter(stu -> stu.getHtno()== htno)
				.findFirst();
		Student s = student.get();
		
		return students.remove(s);
	}

	public Optional<Student> searchStudent(int htno) {
		// TODO Auto-generated method stub
		return students.stream()
					.filter(student -> student.getHtno()== htno)
					.findAny();
	//	return Optional.empty();
	}

	@Override
	public void calculateTotal() {
		// TODO Auto-generated method stub

	}

	@Override
	public boolean updateStudent(Student student) {
		// TODO Auto-generated method stub
		return false;
	}

}
