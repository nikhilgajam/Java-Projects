package com.adp.project.utils;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

public class Dbconnections {
	static Connection con = null;
	static Properties props = null;
	static FileReader reader = null;
	
	static {
		
			try {
				reader = new FileReader("C:/Users/gajamnik/Downloads/Docs/Training/dbproperties.properties");
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		
			try {
				props = new Properties();
				props.load(reader);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		
	}
	
	public static Connection getConnection() {
		
		
		
		try {
			
		//	Class.forName("oracle.jdbc.driver.OracleDriver");
			Class.forName(props.getProperty("driver"));
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		String url=props.getProperty("url");
		String uid = props.getProperty("username");
		String pwd = props.getProperty("password");
		
			 try {
				con = DriverManager.getConnection(url,uid,pwd);
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		
		return con;
	}

}
