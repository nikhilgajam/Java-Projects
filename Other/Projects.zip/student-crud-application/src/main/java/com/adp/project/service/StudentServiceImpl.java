package com.adp.project.service;

import java.util.List;
import java.util.Optional;
import java.util.function.Function;
import java.util.stream.Collectors;

import com.adp.project.dao.IStudentDao;
import com.adp.project.dao.StudentJdbcDaoImpl;
import com.adp.project.model.Student;

public class StudentServiceImpl implements IStudentService {
	
	IStudentDao dao;
	
	public StudentServiceImpl() {
		dao = new StudentJdbcDaoImpl();
	}

	@Override
	public List<Student> getAllStudents() {
		// TODO Auto-generated method stub
	
		return dao.getAllStudents();
	}

	@Override
	public Student addStudent(Student student) {
		// TODO Auto-generated method stub
		return dao.addStudent(student);
	}

	@Override
	public boolean deleteStudent(int htno) {
		// TODO Auto-generated method stub
		return dao.deleteStudent(htno);
	}

	@Override
	public Optional<Student> searchStudent(int htno) {
		// TODO Auto-generated method stub
		
		return dao.searchStudent(htno);
	}

	@Override
	public void calculateTotal() {
		// TODO Auto-generated method stub
//		Function<Student,Student> f = stu -> {
//			stu.setTotal(stu.getM1()+stu.getM2()+stu.getM3());
//			return stu;
//		};
//		
//		return dao.getAllStudents().stream().map(f).collect(Collectors.toList());
		dao.calculateTotal();

	}

	@Override
	public boolean updateStudent(Student student) {
		// TODO Auto-generated method stub
		return dao.updateStudent(student);
	}

}
