package com.adp.project.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import com.adp.project.model.Student;
import com.adp.project.utils.Dbconnections;

public class StudentJdbcDaoImpl implements IStudentDao {
	
	Dbconnections connections;
	public StudentJdbcDaoImpl() {
		connections = new Dbconnections();
	}

	@Override
	public List<Student> getAllStudents() {
		// TODO Auto-generated method stub
		Connection con = null;
		Statement st = null;
		ResultSet rs = null;
		List<Student> students = new ArrayList<>();
		
		con= connections.getConnection();
		try {
			st = con.createStatement();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		String qry = "select * from batch1student";
		try {
			rs = st.executeQuery(qry);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			while(rs.next()) {
				//System.out.println(rs.getString(1)+" "+rs.getInt(2));
			Student s = new Student(rs.getInt(1),rs.getString(2),rs.getString(3),rs.getInt(4),rs.getInt(5),rs.getInt(6));
			students.add(s);
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	//	System.out.println(students);
		return students;
	}

	@Override
	public Student addStudent(Student student) {
		// TODO Auto-generated method stub
		Connection con = null;
		PreparedStatement pst = null;
		boolean isAdded=false;
		int count=0;
		String query = "insert into batch1student(htno,name,branch,m1,m2,m3) values(?,?,?,?,?,?)";
		
		con = connections.getConnection();
		try {
			
			pst = con.prepareStatement(query);
			pst.setInt(1, student.getHtno());
			pst.setString(2, student.getName());
			pst.setString(3, student.getBranch());
			pst.setInt(4, student.getM1());
			pst.setInt(5, student.getM2());
			pst.setInt(6, student.getM3());
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		try {
			count = pst.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		if(count>0)
			return student;
		else
			return null;
	}

	@Override
	public boolean deleteStudent(int htno) {
		// TODO Auto-generated method stub
		Connection con = null;
		String query = "delete from batch1student where htno = ?";
		ResultSet rs=null;
		PreparedStatement pst = null;
		Student s=null;
		try {	
			con = connections.getConnection();
			pst = con.prepareStatement(query);
			pst.setInt(1, htno);
			int count = pst.executeUpdate();
			if(count > 0)
				return true;
			else
				return false;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return false;
		}
	}

	@Override
	public Optional<Student> searchStudent(int htno) {
		// TODO Auto-generated method stub
		Connection con = null;
		String query = "select * from batch1student where htno = ?";
		ResultSet rs=null;
		PreparedStatement pst = null;
		Student s=null;
		con = connections.getConnection();
		try {
			//con=
			pst = con.prepareStatement(query);
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		try {
			pst.setInt(1, htno);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			rs = pst.executeQuery();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		try {
			while(rs.next()) {
				//System.out.println(rs.getString(1)+" "+rs.getInt(2));
			s = new Student(rs.getInt(1),rs.getString(2),rs.getString(3),rs.getInt(4),rs.getInt(5),rs.getInt(6));
			
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return Optional.of(s);
	}

	@Override
	public void calculateTotal() {
		// TODO Auto-generated method stub
		Connection con = null;
		String query = "update batch1student set total=? where htno = ?";
		ResultSet rs=null;
		Statement st = null;
		PreparedStatement pst = null;
		Student s=null;
		try {
			String qry = "select * from batch1student";
			con = connections.getConnection();
			pst = con.prepareStatement(query);
			st = con.createStatement();
			
			rs = st.executeQuery("select * from batch1student");
			
			while(rs.next()) {
				int htno = rs.getInt(1);
				int total = rs.getInt(4) + rs.getInt(5) + rs.getInt(6);
				pst.setInt(1, total);
				pst.setInt(2, htno);
				pst.executeUpdate();
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Override
	public boolean updateStudent(Student student) {
		// TODO Auto-generated method stub
		Connection con = null;
		String query = "update batch1student set htno = ?, name = ?, branch = ?, m1 = ?, m2 = ?, m3 = ? where htno = ?";
		ResultSet rs=null;
		PreparedStatement pst = null;
		Student s=null;
		try {	
			con = connections.getConnection();
			pst = con.prepareStatement(query);
			pst.setInt(1, student.getHtno());
			pst.setString(2, student.getName());
			pst.setString(3, student.getBranch());
			pst.setInt(4, student.getM1());
			pst.setInt(5, student.getM2());
			pst.setInt(6, student.getM3());
			pst.setInt(7, student.getHtno());
			int count = pst.executeUpdate();
			if(count <= 0) {
				new StudentJdbcDaoImpl().addStudent(student);
			}
			
			return true;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return false;
		}
	}

}
