import javax.servlet.http.*;
import javax.servlet.*;
import java.io.*;

public class User4 extends HttpServlet{

	public void doGet(HttpServletRequest req, HttpServletResponse res){
		try{
			res.setContentType("text/html");
			PrintWriter out = res.getWriter();
			
			String username = req.getParameter("username");
			String password = req.getParameter("password");
			
			Cookie c = new Cookie(username, password);
			res.addCookie(c);
			
			out.print("<h1>User 4</h1><form method='get' action='oupt'>");
			out.print("Click Submit Button To See All Usernames And Passwords<br><input type='submit'>");
			out.print("</form>");
			
		}catch(Exception e){
			System.out.println(e);
		}
	}{
		
	}

}
