import javax.servlet.http.*;
import javax.servlet.*;
import java.io.*;

public class Output extends HttpServlet{

	public void doGet(HttpServletRequest req, HttpServletResponse res){
		try{
			
			res.setContentType("text/html");
			PrintWriter out = res.getWriter();
			
			Cookie ck[] = req.getCookies();
			
			out.print("<h1>All Usernames And Password: </h1>");
			for(int i=0; i<ck.length; i++){
				out.println("User " + (i+1) + ":<br>");
				out.println("Username: " + ck[i].getName() + "<br>");
				out.println("Password: " + ck[i].getValue() + "<br><br>");
			}
			
		}catch(Exception e){
			System.out.println(e);
		}
	}{
		
	}

}
