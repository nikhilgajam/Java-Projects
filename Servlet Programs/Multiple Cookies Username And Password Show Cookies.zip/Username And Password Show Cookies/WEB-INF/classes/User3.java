import javax.servlet.http.*;
import javax.servlet.*;
import java.io.*;

public class User3 extends HttpServlet{

	public void doGet(HttpServletRequest req, HttpServletResponse res){
		try{
			res.setContentType("text/html");
			PrintWriter out = res.getWriter();
			
			String username = req.getParameter("username");
			String password = req.getParameter("password");
			
			out.print("<h1>User 4</h1><form method='get' action='u4'>");
			out.print("Name: <input type='text' name='username'><br>");
			out.print("Password: <input type='password' name='password'><br>");
			out.print("<input type='submit'>");
			out.print("</form>");
			
			Cookie c = new Cookie(username, password);
			res.addCookie(c);
			
		}catch(Exception e){
			System.out.println(e);
		}
	}{
		
	}

}
