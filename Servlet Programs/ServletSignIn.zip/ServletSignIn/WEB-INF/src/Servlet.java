import javax.servlet.http.*;
import javax.servlet.*;
import java.io.*;

public class Servlet extends HttpServlet{
	public void doGet(HttpServletRequest req, HttpServletResponse res){
		try{
			res.setContentType("text/html");
			PrintWriter pw = res.getWriter();
			String username = req.getParameter("userName");
			String password = req.getParameter("password");
			pw.println("<html><body>");
			pw.println("Hello " + username + " Welcome to my blog");
			pw.println("Your password is: " + password);
			pw.println("</body></html>");
			pw.close();
		}catch(Exception e){
			e.printStackTrace();
		}
	}
}
