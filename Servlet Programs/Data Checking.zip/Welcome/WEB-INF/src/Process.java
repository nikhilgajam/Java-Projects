import javax.servlet.http.*;
import javax.servlet.*;
import java.io.*;

public class Process extends HttpServlet{

	public void doPost(HttpServletRequest req, HttpServletResponse res){
		try{
			res.setContentType("text/html");
			PrintWriter out = res.getWriter();
			
			String name = req.getParameter("name");
			String age_str = req.getParameter("age");
			
			int age = Integer.parseInt(age_str);
			if(age < 18){
				out.println("<h1>You are not authorized to visit this site</h1>");
			}else{
				out.println("<h1>Welcome to this page</h1>");
			}
			
		}catch(Exception e){
			System.out.println(e);
		}
	}{
		
	}

}
