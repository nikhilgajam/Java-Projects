import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;

public class Param extends HttpServlet{

    public void doGet(HttpServletRequest req, HttpServletResponse res){
        
        try{
            
            res.setContentType("text/html");
            PrintWriter out = res.getWriter();

            String username = req.getParameter("username");
            String password = req.getParameter("password");

            out.print("Welcome " + username + " Your Password is: " + password);

        }catch(Exception e){
            System.out.println(e);
        }

    }

}
