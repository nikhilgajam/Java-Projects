import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;

public class Hello extends HttpServlet{

    public void doGet(HttpServletRequest req, HttpServletResponse res){
        
        try{
            res.setContentType("text/html");
            PrintWriter out = res.getWriter();
            out.println("Hello World");
        }catch(Exception e){
            System.out.println(e);
        }

    }

}
