import re

a = open("games.html", "r")
b = open("AllGamesData", "w")

raw = a.read()

start = 0
end = 0

i = 0

while True:
    start = raw.find('<div class="down-rite">', end+1)
    end = raw.find('<div class="format-file">', start)
    x = re.sub(" {2,}", "", raw[start:end]).replace("\n", "")

    #print(x)

    size = x[x.find('">')+2:x.find('</div>')].strip()
    url = "archive.org" + x[x.find('" href="/')+8:x.find('.zip">')+4].strip()
    title = x[x.find('.zip">')+6:x.find('.zip<span class')].strip()

    save_str = title + " [" + size + "B] : " + url + "\n"

    #print()
    #print(save_str, "\n")

    b.write(save_str)

    if start == -1 or end == -1:  # If string is not found then break the loop
        break

a.close()
b.close()
